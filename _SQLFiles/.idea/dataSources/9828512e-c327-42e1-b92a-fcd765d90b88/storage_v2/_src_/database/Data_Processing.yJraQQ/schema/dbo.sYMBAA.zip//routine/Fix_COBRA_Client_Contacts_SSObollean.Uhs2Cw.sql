-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Fix_COBRA_Client_Contacts_SSObollean]

AS
BEGIN



Select 0,'[VERSION],2.0'
 union
select distinct 1,'[CLIENTCONTACTUPDATE],oClientName='+isnull(c.ClientName,'')+',oContactType='+isnull(cc.ContactType,'')+',oFirstName='+isnull(cc.FirstName,'')+',oLastName='
       +isnull(cc.LastName,'')+',FirstName='+isnull(cc.FirstName,'')+',LastName='+isnull(cc.LastName,'')+',Email='+isnull(cc.Email,'')+',AllowSSO=false,Active=false'
   from [SalesForce_COBRA].[dbo].ClientContact as cc
  join [SalesForce_COBRA].[dbo].Client as c
    on c.ClientID = cc.ClientID
  left
  join (select distinct clientid,[ClientDeactivationDate] from [SalesForce_COBRA].[dbo].[ClientProcess]) as cp
    on c.ClientID =  cp.clientID
 where RegistrationDate is null---only for unregistered
   and RegistrationCode is not null---no date but have a code you are officially unregistered
   and cc.active = 1
   and [ClientDeactivationDate] is null
   and lastname not like '%zINACTIVE%'
   --and firstname like 'M%'
   ---and allowSSO = 0 ?

 union

select distinct 2,'[CLIENTCONTACTINSERT],oClientName='+isnull(c.ClientName,'')+',oContactType='+isnull(cc.ContactType,'')+',FirstName='+isnull(cc.FirstName,'')
       +',LastName='+isnull(cc.LastName,'')+',ContactType='+isnull(cc.ContactType,'')+',Email='+replace(isnull(cc.Email,''),'@','_1@')+',Phone='+isnull(cc.phone,'')+',Extension='+isnull(cc.PhoneExtension,'')
	   +',Phone2 ='+isnull(cc.Phone2,'')+',Extension2='+isnull(cc.Phone2Extension,'')+',Fax='+isnull(cc.fax,'')+',AddressSameAsPrimary=FALSE,Address1='+isnull(cc.Address1,'')
	   +',Address2='+isnull(cc.Address2,'')+',City='+isnull(cc.city,'')+',StateOrProvince='+isnull(cc.state,'')
	   +',PostalCode='+isnull(cc.PostalCode,'')+',AllowSSO=TRUE,SSOIdentifier='+isnull(cc.SSOIdentifier,'')
  from [SalesForce_COBRA].[dbo].ClientContact as cc
  join [SalesForce_COBRA].[dbo].Client as c
    on c.ClientID = cc.ClientID
  left
  join (select distinct clientid,[ClientDeactivationDate] from [SalesForce_COBRA].[dbo].[ClientProcess]) as cp
    on c.ClientID =  cp.clientID
 where RegistrationDate is null---only for unregistered
   and RegistrationCode is not null---no date but have a code you are officially unregistered
   and cc.active = 1
   and [ClientDeactivationDate] is null
   and lastname not like '%zINACTIVE%'
    --and firstname like 'M%'
   --and allowSSO = 0


 union

select distinct  3,'[CLIENTCONTACTUPDATE],oClientName='+isnull(c.ClientName,'')+',oContactType='+isnull(cc.ContactType,'')+',oFirstName='+isnull(cc.FirstName,'')+',oLastName='
       +isnull(cc.LastName,'')+',oEmail='+replace(isnull(cc.Email,''),'@','_1@')+',FirstName='+isnull(cc.FirstName,'')+',LastName='+isnull(cc.LastName,'')+',ContactType='+isnull(cc.ContactType,'')+',Email='+isnull(cc.Email,'')+',AllowSSO=true,Active=true'
   from [SalesForce_COBRA].[dbo].ClientContact as cc
  join [SalesForce_COBRA].[dbo].Client as c
    on c.ClientID = cc.ClientID
  left
  join (select distinct clientid,[ClientDeactivationDate] from [SalesForce_COBRA].[dbo].[ClientProcess]) as cp
    on c.ClientID =  cp.clientID
 where RegistrationDate is null---only for unregistered
   and RegistrationCode is not null---no date but have a code you are officially unregistered
   and cc.active = 1
   and [ClientDeactivationDate] is null
   and lastname not like '%zINACTIVE%'
    --and firstname like 'M%'
   ---and allowSSO = 0 ?
order by 1,2 desc

END
go

