create view Header_list_own as select * from FTP_Source_Folders;
go

