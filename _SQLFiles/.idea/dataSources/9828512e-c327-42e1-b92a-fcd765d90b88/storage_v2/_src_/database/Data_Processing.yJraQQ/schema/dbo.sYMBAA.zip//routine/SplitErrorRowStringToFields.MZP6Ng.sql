CREATE function dbo.SplitErrorRowStringToFields( @csvString nvarchar(max) )
    RETURNS @t table
               (
               row_type      nvarchar(100),
               bencode       nvarchar(100),
               employee_id   nvarchar(100),
               plan_id       nvarchar(100),
               start_date    nvarchar(100),
               end_date      nvarchar(100),
               error_code    nvarchar(100),
               error_message nvarchar(500),
               dummy         nvarchar(100)
               )
    begin
        
        declare @field_id int;
        declare @field_value nvarchar(max);
        --
        declare @row_type nvarchar(100);
        declare @bencode nvarchar(100);
        declare @employee_id nvarchar(100);
        declare @plan_id nvarchar(100);
        declare @start_date nvarchar(100);
        declare @end_date nvarchar(100);
        declare @error_code nvarchar(100);
        declare @error_message nvarchar(500);
        declare @dummy nvarchar(100);
        --
        DECLARE db_cursor CURSOR FOR
            SELECT *
            FROM
                dbo.CsvSplit1( @csvString , ',' );
        
        OPEN db_cursor
        FETCH NEXT FROM db_cursor INTO @field_id, @field_value;
        
        WHILE @@FETCH_STATUS = 0
            BEGIN
                if @field_id = 1
                    set @row_type = @field_value;
                if @field_id = 2
                    set @bencode = @field_value;
                if @field_id = 3
                    set @employee_id = @field_value;
                if @field_id = 4
                    set @plan_id = @field_value;
                if @field_id = 5
                    set @start_date = @field_value;
                if @field_id = 6
                    set @end_date = @field_value;
                if @field_id = 7
                    set @error_code = @field_value;
                if @field_id = 8
                    set @error_message = @field_value;
                if @field_id = 9
                    set @dummy = @field_value;
                /**/
                FETCH NEXT FROM db_cursor INTO @field_id, @field_value;
            END
        
        CLOSE db_cursor
        DEALLOCATE db_cursor
        
        insert into @t(
--                       error_row,
                      row_type,
                      bencode,
                      employee_id,
                      plan_id,
                      start_date,
                      end_date,
                      error_code,
                      error_message,
                      dummy
        )
        select
         /*   @csvString
          ,*/ @row_type
          , @bencode
          , @employee_id
          , @plan_id
          , @start_date
          , @end_date
          , @error_code
          , @error_message
          , @dummy;
        
        RETURN
    end
go

