CREATE function dbo.getFileLogId(
    @filePathWithoutExtension varchar(200) ) returns int
    as
    begin
        declare @fileLogId int = null;
        
        if @filePathWithoutExtension is null or rtrim( ltrim( @filePathWithoutExtension ) )=''
            begin
                return 0;
            end
        
        /* take last id for filename (wihout path or extension*/
        select top 1
            @fileLogId = fileLogId
        from
            dbo.file_processing_log
        where
             originalFileName like concat( @filePathWithoutExtension , '%' )
          or newFileName like concat( @filePathWithoutExtension , '%' )
        order by
            fileLogId desc;
        
        if @fileLogId is not null and @fileLogId <> 0
            begin
                return @fileLogId;
            end
        else
            begin
                return 0;
            end
        
        return @fileLogId
    end
go

