CREATE procedure [dbo].[Data_Processing_track_new_ftp_errors] as
begin
    /* insert new error codes and messages into dbo_tracked_errors_local setting crm, processing and control flags*/
    INSERT into dbo_tracked_errors_local (
                                         Error_code,
                                         error_message,
                                         crm,
                                         processing,
                                         control
    )
    SELECT distinct
        wf.[Error_code]
      , wf.[error_message]
      , 0
      , 255
      , 255
    FROM
       [dbo].[error_log_results_withmbi] as wf
            left join dbo_tracked_errors_local as te
                      on wf.error_code = te.Error_code
    where
        te.error_code is null;
    
    /* insert new errors  into dbo_tracked_errors_local setting crm, processing and control flags*/
    INSERT INTO [dbo].[dbo_error_log_results_workflow_local]
    (
        [mbi_file_name]
    ,   [error_row]
    ,   [error_code]
    ,   [error_message]
    ,   [error_row_num]
    ,   mbi_row_num
    ,   [mbi_line]
    ,   [CRM_Check]
    ,   [Proc_Check]
    ,   [Archive_Check]
    ,   [updated_by]
    ,   [updated_timestamp]
    ,   EmployerId
    ,   EmployeeID
    ,   DependentID
    ,   PlanId
    ,   [CRM]
    ,   [row_type]
    )
    SELECT distinct
        d.[mbi_file_name]
      , d.[error_row]
      , d.[error_code]
      , d.[error_message]
      , d.[error_row_num]
      , d.mbi_row_num
      , d.[mbi_line]
      , 0
      , 0
      , 0
      , ''
      , getdate( )
      , d.EmployerId
      , d.EmployeeID
      , d.DependentID
      , d.PlanId
      , d.CRM
      , d.row_type
    FROM
       [dbo].[error_log_results_withmbi_with_CRM] as d
            left join [dbo].[dbo_error_log_results_workflow_local] wfl
                      on wfl.mbi_file_name = d.mbi_file_name and wfl.error_row_num = d.error_row_num
    WHERE
        /*          d.error_row is null
              and*/
            d.error_code in (
                                select
                                    error_code
                                from
                                    dbo_tracked_errors_local
                            )
      and   wfl.mbi_file_name is null
      and   wfl.error_row_num is null;
    
    /* update crm*/
    UPDATE[dbo].[dbo_error_log_results_workflow_local]
    set
        CRM = replace( c.crm , '""' , '' )
    FROM
       [dbo].[dbo_error_log_results_workflow_local] as l
            JOIN [dbo].[CRM_List] as c
                on l.EmployerId = c.bencode;
    
    -- exec [dbo].[Alegeus_ErrorLog_refreshsuccess_alert]

end;
go

