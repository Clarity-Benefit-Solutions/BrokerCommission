CREATE view vw_file_processing_log
as
    select
        fileLogId
      , platform
      , fileId
      , folderName
      , templateType
      , ICType
      , toFTP
      , bencode
      , originalFileName
      , originalFullPath
      , newFileName
      , newFileFullPath
      , created_at
      , originalFileUploadedOn
      , dbo.fileLogHasError( fileLogId ) ProcessingErrorCount
    from
        file_processing_log h
go

