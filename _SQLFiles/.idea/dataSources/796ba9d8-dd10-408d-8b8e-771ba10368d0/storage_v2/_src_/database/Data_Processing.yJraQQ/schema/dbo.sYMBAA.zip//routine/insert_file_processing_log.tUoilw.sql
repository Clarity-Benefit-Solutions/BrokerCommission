CREATE procedure dbo.insert_file_processing_log(
                                              @platform nvarchar(50),
                                              @fileLogId int output,
                                              @fileId nvarchar(10),
                                              @folderName nvarchar(400),
                                              @templateType nvarchar(50),
                                              @ICType nvarchar(50),
                                              @toFTP nvarchar(10),
                                              @bencode varchar(50),
                                              @originalFileName nvarchar(200),
                                              @originalFullPath nvarchar(200),
                                              @originalFileUploadedOn nvarchar(50),
                                              @newFileName nvarchar(200),
                                              @newFileFullPath nvarchar(200),
                                              @fileLogTaskId int output,
                                              @processingTask nvarchar(50),
                                              @processingTaskOutcome nvarchar(20),
                                              @processingTaskOutcomeDetails nvarchar(500) ) as
begin
    
    SET NOCOUNT ON
    /* if fileLogId = 0 or processingTask = 'New', we will insert into main and detail tables
       else we will insert only into the detailed table
    */
    
    if @fileLogId is null or @fileLogId = 0 or @processingTask = 'New'
        begin
            set @fileLogId = 0;
            
            if rtrim( ltrim( @originalFileUploadedOn ) ) = ''
                begin
                    set @originalFileUploadedOn = null;
                end
            
            insert into dbo.file_processing_log (
                                                platform,
                                                fileId,
                                                folderName,
                                                templateType,
                                                ICType,
                                                toFTP,
                                                bencode,
                                                originalFileName,
                                                originalFullPath,
                                                originalFileUploadedOn,
                                                newFileName,
                                                newFileFullPath
            
            )
            values (
                   @platform,
                   @fileId,
                   @folderName,
                   @templateType,
                   @ICType,
                   @toFTP,
                   @bencode,
                   @originalFileName,
                   @originalFullPath,
                   @originalFileUploadedOn,
                   @newFileName,
                   @newFileFullPath
                   );
            
            /**/
            set @fileLogId = SCOPE_IDENTITY( );
        end
    
    /* no insert into header table, only into detail table*/
    insert into dbo.file_processing_tasks_log(
                                             fileLogId,
                                             fileId,
                                             processingTask,
                                             processingTaskOutcome,
                                             processingTaskOutcomeDetails,
                                             originalFileName,
                                             originalFullPath,
                                             newFileName,
                                             newFileFullPath
    )
    values (
           @fileLogId,
           @fileId,
           @processingTask,
           @processingTaskOutcome,
           @processingTaskOutcomeDetails,
           @originalFileName,
           @originalFullPath,
           @newFileName,
           @newFileFullPath
           );
    
    /* return the header PK */
    select
        @fileLogId;
end;
go

