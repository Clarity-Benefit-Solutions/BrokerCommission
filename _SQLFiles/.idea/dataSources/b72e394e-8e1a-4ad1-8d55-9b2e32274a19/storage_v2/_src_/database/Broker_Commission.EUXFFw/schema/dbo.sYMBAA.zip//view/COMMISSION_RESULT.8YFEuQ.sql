CREATE VIEW [dbo].[COMMISSION_RESULT]
    AS
        WITH
            CTE_RESULT AS
                (
                    SELECT *
                    FROM
                        [dbo].[COMMISSION_RESULT_NAME0]
                    UNION
                    SELECT *
                    FROM
                        [dbo].[COMMISSION_RESULT_NAME1]
                    UNION
                    SELECT *
                    FROM
                        [dbo].[COMMISSION_RESULT_NAME2]
                    UNION
                    SELECT *
                    FROM
                        [dbo].[COMMISSION_RESULT_NAME3]
                    UNION
                    SELECT *
                    FROM
                        [dbo].[COMMISSION_RESULT_NAME4]
                    UNION
                    SELECT *
                    FROM
                        [dbo].[COMMISSION_RESULT_NAME5]
                    UNION
                    SELECT *
                    FROM
                        [dbo].[COMMISSION_RESULT_NAME6]
                    UNION
                    SELECT *
                    FROM
                        [dbo].[VW_STATEMENT_DETAILS_ADD]
                
                )
            /**/
        SELECT DISTINCT
            A.*
        FROM
            CTE_RESULT AS A
                LEFT JOIN [dbo].[SENT_INVOICE] AS B ON RTRIM( LTRIM( A.[Num] ) ) = RTRIM( LTRIM( B.[INVOICE_NUM] ) )
        WHERE
            B.[INVOICE_NUM] IS NULL
go

