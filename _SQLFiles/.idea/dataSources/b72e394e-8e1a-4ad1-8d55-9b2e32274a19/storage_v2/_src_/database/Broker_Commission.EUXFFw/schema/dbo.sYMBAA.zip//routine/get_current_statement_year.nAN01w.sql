create 
 function get_current_statement_year( ) returns int as
begin
    declare @value int;
    
    select top 1
        @value = year
    from
        dbo.STATEMENT_HEADER;
    
    return isnull( @value , 0 );
end
go

