create

    function get_total_processed_this_period_NOTGOOD(
    @header_id int ) returns numeric(18, 2) as
begin
    declare @amount numeric;
    --      total both [COMMISSION_PAID] + [OPEN_BALANCE] as that would be waht we sent out for the poeriod in question
    select
        @amount = sum( TOTAL_PRICE )
    from
        [dbo].[STATEMENT_DETAILS]
    where
          HEADER_ID = @header_id
      and line_payment_status = 'paid';
    
    return isnull( @amount , 0 );
end
go

