CREATE PROCEDURE [dbo].[SP_CALC_STATEMENT_LINE_PAYMENT_STATUS]
@month nvarchar(30),
@year int
AS
BEGIN
    select
        '';
end;
go

