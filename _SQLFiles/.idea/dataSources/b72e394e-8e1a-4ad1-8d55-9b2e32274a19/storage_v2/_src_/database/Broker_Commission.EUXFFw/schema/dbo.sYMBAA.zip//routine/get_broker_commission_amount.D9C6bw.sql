create function get_broker_commission_amount( @broker_id int ) returns numeric as
begin
    declare @amount numeric;
    
    select
        @amount = sum( [COMMISSION AMOUNT] )
    from
        dbo.[COMMISSION_RESULT]
    where
        BROKER_ID = @broker_id;
    
    return isnull( @amount , 0 );
end
go

