CREATE VIEW [dbo].[COMMISSION_SUMMARY]
    AS
        SELECT
            --DISTINCT
            RT.[BROKER_ID]
          , RT.[BROKER_NAME]
          , RT.PAYLOCITY_ID
          , dbo.get_broker_commission_amount( RT.BROKER_ID )
                TOTAL
        FROM
            [dbo].[COMMISSION_RESULT] AS RT
        GROUP BY
            RT.[BROKER_ID]
          , RT.[BROKER_NAME]
          , RT.PAYLOCITY_ID
go

