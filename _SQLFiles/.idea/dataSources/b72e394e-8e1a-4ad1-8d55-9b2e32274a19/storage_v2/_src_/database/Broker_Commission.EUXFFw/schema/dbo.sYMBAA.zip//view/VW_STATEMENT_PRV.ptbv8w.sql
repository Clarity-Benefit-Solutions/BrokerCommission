CREATE VIEW [dbo].[VW_STATEMENT_PRV]
AS
    (
    SELECT
        [dbo].[STATEMENT_HEADER].[HEADER_ID]
      , [dbo].[STATEMENT_DETAILS].[STATUS] PID
      , [dbo].[STATEMENT_HEADER].[MONTH]
      , [dbo].[STATEMENT_HEADER].[YEAR]
      , [dbo].[STATEMENT_HEADER].[BROKER_ID]
      , [dbo].[STATEMENT_HEADER].[BROKER_NAME]
      , [dbo].[STATEMENT_HEADER].[FLAG]
      , [dbo].[STATEMENT_HEADER].[STATEMENT_TOTAL]
      , [dbo].[STATEMENT_HEADER].[Change_Date]
      , [dbo].[STATEMENT_DETAILS].[QB_CLIENT_NAME]
      , [dbo].[STATEMENT_DETAILS].[CLIENT_NAME]
      , [dbo].[STATEMENT_DETAILS].[QB_FEE]
      , [dbo].[STATEMENT_DETAILS].[FEE_MEMO]
      , [dbo].[STATEMENT_DETAILS].[QUANTITY]
      , [dbo].[STATEMENT_DETAILS].[COMMISSION_RATE]
      , [dbo].[STATEMENT_DETAILS].[UNIT]
      , [dbo].[STATEMENT_DETAILS].[SALES_PRICE]
      , [dbo].[STATEMENT_DETAILS].[TOTAL_PRICE]
      , [dbo].[STATEMENT_DETAILS].[OPEN_BALANCE]
      , [dbo].[STATEMENT_DETAILS].[START_DATE]
      , [dbo].[STATEMENT_DETAILS].[BROKER_STATUS]
    FROM
        [dbo].[STATEMENT_HEADER]
            LEFT JOIN
            [dbo].[STATEMENT_DETAILS] ON [dbo].[STATEMENT_HEADER].HEADER_ID = [dbo].[STATEMENT_DETAILS].HEADER_ID
    
    UNION
    
    SELECT
        [dbo].[STATEMENT_HEADER].[HEADER_ID]
      , '' PID
      , [dbo].[STATEMENT_HEADER].[MONTH]
      , [dbo].[STATEMENT_HEADER].[YEAR]
      , [dbo].[STATEMENT_HEADER].[BROKER_ID]
      , [dbo].[STATEMENT_HEADER].[BROKER_NAME]
      , [dbo].[STATEMENT_HEADER].[FLAG]
      , [dbo].[STATEMENT_HEADER].[STATEMENT_TOTAL]
      , [dbo].[STATEMENT_HEADER].[Change_Date]
      , ''
      , ''
      , ''
      , ''
      , 0
      , 0
      , ''
      , 0
      , 0
      , 0
      , ''
      , ''
    FROM
        [dbo].[STATEMENT_HEADER]
    WHERE
        [dbo].[STATEMENT_HEADER].STATEMENT_TOTAL = 0
        
        )
go

