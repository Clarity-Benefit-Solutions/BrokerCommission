create view Header_list_all as select * from FTP_Source_Folders;
go

