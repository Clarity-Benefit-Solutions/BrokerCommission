CREATE PROCEDURE [dbo].[build_auto_ftp_batfile]

AS
BEGIN

---truncate table [dbo].[ftp_auto_batfile]


INSERT INTO [dbo].[ftp_auto_batfile]
           ([batfile_code])
Select 'move /y "G:\FTP\To_Alegeus_FTP_Holding\*' + [find_autoftp_file] + '.*" "G:\FTP\To_Alegeus_FTP_Holding\AutomaticFTP"'
from [dbo].[ftp_autofile_list]
END
go

