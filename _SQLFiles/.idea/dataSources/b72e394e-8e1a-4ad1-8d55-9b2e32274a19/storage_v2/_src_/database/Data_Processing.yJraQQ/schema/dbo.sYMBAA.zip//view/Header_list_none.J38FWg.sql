create view Header_list_none as select * from FTP_Source_Folders;
go

