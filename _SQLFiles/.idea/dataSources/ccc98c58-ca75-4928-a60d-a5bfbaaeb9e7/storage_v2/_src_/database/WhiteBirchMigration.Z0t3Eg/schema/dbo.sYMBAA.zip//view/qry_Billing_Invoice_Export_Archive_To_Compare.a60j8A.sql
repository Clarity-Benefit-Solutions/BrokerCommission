CREATE VIEW [dbo].[qry_Billing Invoice Export Archive To Compare]
    AS
        /* compare billing export archive for current billing period
        */
        SELECT
            [tbl_Billing Invoice Export Archive].[Billing Group]
          , [tbl_Billing Invoice Export Archive].[Employer Name]
          , [tbl_Billing Invoice Export Archive].[Employer Key]
          , [tbl_Billing Invoice Export Archive].[System Employer Key]
          , [tbl_Billing Invoice Export Archive].[Broker Code]
          , [tbl_Billing Invoice Export Archive].[Broker Name]
          , [tbl_Billing Invoice Export Archive].[Billing Code]
          , [tbl_Billing Invoice Export Archive].[Billing Code QB]
          , [tbl_Billing Invoice Export Archive].[Billing Description]
          , [tbl_Billing Invoice Export Archive].[Billing Unit Count]
          , [tbl_Billing Invoice Export Archive].[Billing Unit Rate]
          , [tbl_Billing Invoice Export Archive].[Billing Amount]
          , [tbl_Billing Invoice Export Archive].[Invoice Number]
          , [tbl_Billing Invoice Export Archive].[Invoice Date]
          , [tbl_Billing Invoice Export Archive].[Invoice Due Date]
          , [tbl_Billing Invoice Export Archive].terms
          , [tbl_Billing Invoice Export Archive].[Customer Message]
          , [tbl_Billing Invoice Export Archive].[Billing Period]
          , [tbl_Billing Invoice Export Archive].[Bill To]
          , [tbl_Billing Invoice Export Archive].[KEY_MM Monthly Minimum]
          , [tbl_Billing Invoice Export Archive].[Monthly Min Billing Flg]
          , [tbl_Billing Invoice Export Archive].[Monthly Min Billing Amount]
          , [tbl_Billing Invoice Export Archive].[Calculated Billing Amount]
          , [tbl_Billing Invoice Export Archive].[Employer Billing Number]
          , [tbl_Billing Invoice Export Archive].[GL Receivable Account]
          , [tbl_Billing Invoice Export Archive].[GL Expense Account]
          , [tbl_Billing Invoice Export Archive].[To Print]
          , [tbl_Billing Invoice Export Archive].[To Email]
        FROM
            [tbl_Billing Invoice Export Archive]
                INNER JOIN [tbl_Invoice Date Table] ON [tbl_Billing Invoice Export Archive].[Billing Period] =
                                                       [tbl_Invoice Date Table].[Billing Period To Compare]
go

