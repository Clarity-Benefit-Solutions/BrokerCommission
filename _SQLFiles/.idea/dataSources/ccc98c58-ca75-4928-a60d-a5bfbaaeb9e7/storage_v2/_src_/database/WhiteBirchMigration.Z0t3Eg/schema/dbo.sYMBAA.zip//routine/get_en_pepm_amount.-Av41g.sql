CREATE FUNCTION get_en_pepm_amount(
    @EmployerName nvarchar(255),
    @OrgEmployerName nvarchar(255) ) RETURNS money
    BEGIN
        DECLARE @ret money;
        SELECT
            @ret = SUM( t.[Billing Amount] )
        FROM
            dbo.[tbl_Billing Invoice Export All QuickBooks] t
        WHERE
              t.[Employer Name] = @EmployerName
           AND ISNULL( t.[Original Employer Name] , '' ) = ISNULL( @OrgEmployerName , '' )
          AND t.[Billing Code] IN ('ENPEPM');
        
        IF @ret IS NULL
            BEGIN
                SET @ret = 0
            END
        
        RETURN @ret
    END
go

