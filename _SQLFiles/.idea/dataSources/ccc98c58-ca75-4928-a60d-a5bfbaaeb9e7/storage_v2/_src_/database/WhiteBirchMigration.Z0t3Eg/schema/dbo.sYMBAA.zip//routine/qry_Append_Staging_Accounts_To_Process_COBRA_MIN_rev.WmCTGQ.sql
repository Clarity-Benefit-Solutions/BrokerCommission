CREATE PROCEDURE dbo.[QRY_APPEND STAGING ACCOUNTS TO PROCESS COBRA MIN REV] AS
    /* inserts EMPCTL records matching
 Process = 1 AND [COBRA_MONTHLY MINIMUM FLG] = 1
into Process */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_PROCESS TABLE] (
                                     process,
                                     [EMPLOYER NAME],
                                     [EMPLOYER KEY],
                                     [BILLING GROUP],
                                     [SYSTEM EMPLOYER CODE],
                                     [EMPLOYER BILLING NUMBER],
                                     [BROKER CODE],
                                     [PARTICIPANT ID],
                                     [FIRST NAME],
                                     [LAST NAME],
                                     [ACCOUNT TYPE],
                                     [PLAN NAME],
                                     [PLAN START DATE],
                                     [PLAN END DATE],
                                     [PARTICIPANT STATUS],
                                     [ALLOW CLAIMS IMPORT],
                                     uniquekeyparticipant,
                                     uniquekeyaccount,
                                     uniquekeybillingaccount,
                                     [MONTHLY MINIMUM AMOUNT],
                                     [BILLING CODE],
                                     [PAID BY BROKER FLG],
                                     [PAID BY BROKER PERCENT],
                                     [PAID BY EMPLOYER FLG],
                                     [PAID BY EMPLOYER PERCENT],
                                     [MONTHLY MINIMUM FLG],
                                     [PEPM COUNT]
        )
        SELECT
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , '' [PARTICIPANT ID]
          , '' [FIRST NAME]
          , '' [LAST NAME]
          , '' [ACCOUNT TYPE]
          , '' [FSA_PLAN NAME]
          , '' [PLAN START DATE DT]
          , '' [PLAN END DATE DT]
          , '' [PARTICIPANT STATUS]
          , '' [ALLOW CLAIMS IMPORT]
          , '' uniquekeyparticipant
          , '' uniquekeyparticipantaccounts
          , ([TBL_EMPLOYER CONTROL].[EMPLOYER KEY] + 'COBRAMIN') uniquekeybillingaccount
          , [TBL_EMPLOYER CONTROL].[COBRA_MONTHLY MINIMUM AMOUNT]
          , 'COBRA MIN' [COBRA_BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY BROKER FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY BROKER PERCENT]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY EMPLOYER FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY EMPLOYER PERCENT]
          , [TBL_EMPLOYER CONTROL].[COBRA_MONTHLY MINIMUM FLG]
          , '1' [GENERAL BILLING COUNT]
        FROM
            [TBL_EMPLOYER CONTROL]
        WHERE
            ((([TBL_EMPLOYER CONTROL].process) = 1) AND (([TBL_EMPLOYER CONTROL].[COBRA_MONTHLY MINIMUM FLG]) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

