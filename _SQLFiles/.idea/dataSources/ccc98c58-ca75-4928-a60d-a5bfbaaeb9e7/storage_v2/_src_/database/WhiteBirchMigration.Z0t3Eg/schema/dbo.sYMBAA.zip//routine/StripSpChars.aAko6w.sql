CREATE FUNCTION [dbo].[StripSpChars](
    @string nvarchar(max) ) RETURNS nvarchar(max) AS
    BEGIN
        /* migrated Access fn to strip spoecial chars*/
        DECLARE @lngctr bigint;
        DECLARE @intchar bigint;
        DECLARE @value nvarchar(max) = ''
        SET @lngctr = 0;
        WHILE @lngctr < LEN( @string ) BEGIN
            SET @lngctr = @lngctr + 1;
            SET @intchar = ASCII( SUBSTRING( @string , @lngctr , 1 ) );
            IF @intchar BETWEEN 48 AND 57 OR @intchar BETWEEN 97 AND 122 OR @intchar = 32 OR @intchar BETWEEN 65 AND 90
                BEGIN
                    SET @value = @value + CHAR( @intchar );
                END;
        END;
        RETURN @value;
    END
go

