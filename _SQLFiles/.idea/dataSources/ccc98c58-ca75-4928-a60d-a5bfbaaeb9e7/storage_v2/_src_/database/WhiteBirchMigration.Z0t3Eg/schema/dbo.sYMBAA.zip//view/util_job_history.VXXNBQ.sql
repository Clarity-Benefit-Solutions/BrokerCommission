CREATE VIEW util_job_history
    AS
        SELECT
            [sJOB].[job_id] [JobID]
          , [sJOB].[name] [JobName]
          , [step_id]
          , activity.stop_execution_date
          , activity.job_history_id
          , CASE
                WHEN [sJOBH].[run_date] IS NULL OR [sJOBH].[run_time] IS NULL THEN NULL
                ELSE CAST( CAST( [sJOBH].[run_date] AS char(8) ) + ' ' +
                           STUFF( STUFF( RIGHT( '000000' + CAST( [sJOBH].[run_time] AS varchar(6) ) , 6 ) ,
                                         3 , 0 , ':' ) , 6 , 0 , ':' ) AS datetime )
            END [LastRunDateTime]
          , CASE [sJOBH].[run_status]
                WHEN 0 THEN 'Failed'
                WHEN 1 THEN 'Succeeded'
                WHEN 2 THEN 'Retry'
                WHEN 3 THEN 'Canceled'
                WHEN 4 THEN 'Running' -- In Progress
            END [LastRunStatus]
        
        FROM
            [msdb].[dbo].[sysjobs] AS [sJOB]
                LEFT JOIN (
                              SELECT
                                  [job_id]
                                , [run_date]
                                , [run_time]
                                , [run_status]
                                , [run_duration]
                                , [message]
                                , [step_id]
                                , ROW_NUMBER( )
                                          OVER ( PARTITION BY [job_id] ORDER BY [run_date] DESC, [run_time] DESC ) rownumber
                              FROM
                                  [msdb].[dbo].[sysjobhistory]
                              WHERE
                                  [step_id] = 0
                          ) AS [sJOBH] ON [sJOB].[job_id] = [sJOBH].[job_id] AND [sJOBH].[RowNumber] = 1
                /**/
                LEFT JOIN msdb.dbo.sysjobactivity activity ON activity.job_id = sjob.job_id
go

