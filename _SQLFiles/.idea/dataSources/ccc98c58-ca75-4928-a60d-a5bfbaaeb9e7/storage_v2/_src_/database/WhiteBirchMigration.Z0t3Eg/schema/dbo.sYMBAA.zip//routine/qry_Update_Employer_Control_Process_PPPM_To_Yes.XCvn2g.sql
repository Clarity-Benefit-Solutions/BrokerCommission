CREATE PROCEDURE dbo.[QRY_UPDATE EMPLOYER CONTROL PROCESS PPPM TO YES] AS
    /* update EmpCtl set all Process = 1 for BillGrpsToProcess.[Billing Group]) = 'PPPM')  */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_EMPLOYER CONTROL]
        SET
            [TBL_EMPLOYER CONTROL].process = 1
        FROM
            [TBL_BILLING GROUPS TO PROCESS]
                INNER JOIN [TBL_EMPLOYER CONTROL] ON [TBL_BILLING GROUPS TO PROCESS].[BILLING GROUP] =
                                                     [TBL_EMPLOYER CONTROL].[BILLING GROUP PROCESS]
        WHERE
            ((([TBL_BILLING GROUPS TO PROCESS].[BILLING GROUP]) = 'PPPM' /*embmerge*/ AND
              ([Employer Name] LIKE dbo.get_employers_to_process_name_filter( ) /* embmerge end*/
                  OR [Employer Name] IN (
                                            SELECT
                                                [Employer Name]
                                            FROM
                                                _EmployerNamesToProcess
                                            WHERE
                                                _EmployerNamesToProcess.Process = 1
                                        )
                  )
                ));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

