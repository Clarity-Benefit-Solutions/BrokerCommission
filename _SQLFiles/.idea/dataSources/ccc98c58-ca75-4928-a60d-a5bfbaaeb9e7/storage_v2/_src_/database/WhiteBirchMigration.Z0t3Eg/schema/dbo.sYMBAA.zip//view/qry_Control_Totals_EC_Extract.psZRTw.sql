CREATE VIEW [dbo].[qry_Control Totals EC Extract]
    AS
        /* Count EC Import  by ClientName   by [Employer Id], [Account Type Code], [Account Status]*/
        SELECT
            [tbl_Staging EC Extract].[Employer Id]
          , [tbl_Staging EC Extract].[Account Type Code]
          , [tbl_Staging EC Extract].[Account Status]
          , COUNT( [tbl_Staging EC Extract].uniquekeyaccounts ) countofuniquekeyaccounts
        FROM
            [tbl_Staging EC Extract]
        GROUP BY
            [tbl_Staging EC Extract].[Employer Id]
          , [tbl_Staging EC Extract].[Account Type Code]
          , [tbl_Staging EC Extract].[Account Status]
go

