CREATE PROCEDURE [dbo].[util_test_job](
    @loopCount integer, @loopDelay integer = 1) AS
BEGIN
    DECLARE @loopNo int;
    DECLARE @loopDelay2 nvarchar(10);
    SET @loopNo = 0;
    SET @loopDelay2 =concat( '00:00:' , @loopDelay);
    BEGIN TRY
        /* loop indeifnitely */
        WHILE 1 = 1 BEGIN
            
            WAITFOR DELAY @loopDelay2;
            SET @loopNo = @loopNo + 1;
            IF @loopNo > @loopCount
                BEGIN
                    BREAK;
                END
            CONTINUE
        
        END
        
        SELECT
           concat( 'Looped for ' , @loopDelay * @loopCount , ' Seconds');
    
    END TRY BEGIN CATCH
        DECLARE @errno varchar(500) = ERROR_NUMBER( )
        DECLARE @errmsg varchar(2000) = ERROR_MESSAGE( )
        DECLARE @errstate varchar(200) = ERROR_STATE( )
        
        EXEC dbo.db_throw_error 50001 , 'util_test_job' , @errmsg;
    
    END CATCH
END
go

