CREATE VIEW [dbo].[qry_Bundle Billing Qualified Records Count]
    AS
        /* count of all process records for bundle*/
        SELECT
            [qry_Bundle Billing Qualified Records].[Employer Name]
          , [qry_Bundle Billing Qualified Records].[Employer Key]
          , [qry_Bundle Billing Qualified Records].[BND_BILLING CODE]
          , [qry_Bundle Billing Qualified Records].[BND_BUNDLE BILL FLG]
          , [qry_Bundle Billing Qualified Records].[BND_BUNDLE BILL QUAL]
          , COUNT( [qry_Bundle Billing Qualified Records].count ) countofcount
        FROM
            [qry_Bundle Billing Qualified Records]
        GROUP BY
            [qry_Bundle Billing Qualified Records].[Employer Name]
          , [qry_Bundle Billing Qualified Records].[Employer Key]
          , [qry_Bundle Billing Qualified Records].[BND_BILLING CODE]
          , [qry_Bundle Billing Qualified Records].[BND_BUNDLE BILL FLG]
          , [qry_Bundle Billing Qualified Records].[BND_BUNDLE BILL QUAL]
go

