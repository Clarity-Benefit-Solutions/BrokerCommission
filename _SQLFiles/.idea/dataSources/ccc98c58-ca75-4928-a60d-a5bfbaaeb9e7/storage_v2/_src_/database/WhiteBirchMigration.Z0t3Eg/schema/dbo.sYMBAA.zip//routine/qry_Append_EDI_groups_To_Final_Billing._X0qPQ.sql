CREATE PROCEDURE dbo.[	qry_Append EDI groups To Final Billing	] AS

BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        -- ALTER  PROCEDURE [	qry_Append EDI groups To Final Billing	] AS
        INSERT
            INTO [tbl_Final EDI Billing Group Counts] (
                                                      clientname,
                                                      [Alternate ER ID]
        )
        SELECT
            [tbl_EDI Source Clients Master].clientname
          , [tbl_EDI Source Clients Master].clientalternate
        FROM
            [tbl_EDI Source Clients Master]
        GROUP BY
            [tbl_EDI Source Clients Master].clientname
          , [tbl_EDI Source Clients Master].clientalternate;;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = ERROR_NUMBER( ), @errmessage varchar(max) = ERROR_MESSAGE( ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

