CREATE PROCEDURE [dbo].[__imp_tables_from_portal] AS
BEGIN
    DECLARE @msg1 nvarchar(max)
    
    EXEC dbo._imp_bs_employees_from_portal;
    EXEC dbo._imp_cp_clients_from_portal;
    EXEC dbo._imp_en_employees_from_portal;
    EXEC dbo._imp_sf_accounts_from_portal;
    EXEC dbo._imp_wc_employers_from_portal;
    EXEC dbo._imp_if_participant_billing_from_portal;
    
    SET @msg1 = CONCAT( '**LOG** ' , '__imp_tables_from_portal' , ' FINISHED' );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT

END;
go

