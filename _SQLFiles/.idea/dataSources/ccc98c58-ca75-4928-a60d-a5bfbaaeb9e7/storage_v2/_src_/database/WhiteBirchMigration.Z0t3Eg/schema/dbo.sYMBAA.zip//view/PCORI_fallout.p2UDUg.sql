CREATE VIEW [dbo].[PCORI_fallout]
    AS
        /*   missing table PCORI2020 - ??*/
        SELECT DISTINCT
            pcori2020.bencode
          , pcori2020.client
        FROM
            pcori2020
                LEFT JOIN [x_QuickBooks Pro Invoice Import_PCORI]
                          ON pcori2020.bencode = [x_QuickBooks Pro Invoice Import_PCORI].[Employer Key]
        WHERE
            ((([x_QuickBooks Pro Invoice Import_PCORI].[Employer Key]) IS NULL))
go

