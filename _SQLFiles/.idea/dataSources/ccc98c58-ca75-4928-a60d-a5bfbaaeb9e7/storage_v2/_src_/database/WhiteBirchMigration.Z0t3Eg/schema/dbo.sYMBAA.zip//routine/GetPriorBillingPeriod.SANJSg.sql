CREATE FUNCTION dbo.getpriorbillingperiod(
    @monthsago int = -1 ) RETURNS nvarchar(50) AS
    /* simulate missing Access fn */
    BEGIN
        DECLARE @datevalue nvarchar(50) = NULL;
        DECLARE @datecastvalue date = NULL;
        SET @datevalue = dbo.getcurrentbillingperiod( @monthsago + 1 );
        SET @datecastvalue = CAST( @datevalue AS date );
        RETURN FORMAT( DATEADD( MONTH , @monthsago , @datecastvalue ) , 'MMMM yyyy' );
    
    END
go

