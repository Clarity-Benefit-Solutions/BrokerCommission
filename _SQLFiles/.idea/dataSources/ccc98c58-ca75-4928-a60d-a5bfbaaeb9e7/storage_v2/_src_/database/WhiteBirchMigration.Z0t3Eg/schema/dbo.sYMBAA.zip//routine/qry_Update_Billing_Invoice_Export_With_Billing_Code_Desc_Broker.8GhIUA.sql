CREATE PROCEDURE dbo.[QRY_UPDATE BILLING INVOICE EXPORT WITH BILLING CODE DESC BROKER] AS
    /* update InvExp set [Billing Description], [Billing Code QB] from AcTypeBillingCode joined by [Billing Code], for  [PAID BY BROKER FLG]) = 1*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_BILLING INVOICE EXPORT]
        SET
            [TBL_BILLING INVOICE EXPORT].[BILLING DESCRIPTION] = [TBL_ACCOUNT TYPE BILLING CODES].[BILLING CODE DESCRIPTION]
          , [TBL_BILLING INVOICE EXPORT].[BILLING CODE QB]     =[TBL_ACCOUNT TYPE BILLING CODES].[QB BILLING ITEM CODE]
        FROM
            [TBL_BILLING INVOICE EXPORT]
                INNER JOIN [TBL_ACCOUNT TYPE BILLING CODES] ON [TBL_ACCOUNT TYPE BILLING CODES].[BILLING CODE] =
                                                               [TBL_BILLING INVOICE EXPORT].[BILLING CODE]
        WHERE
            ((([TBL_BILLING INVOICE EXPORT].[PAID BY BROKER FLG]) = 1));
        
        /* sumeet - added 2021-07-10 update process table not needed as billing des and billing code QB fields do not exist */
        /*  UPDATE [tbl_Process Table]
           SET
              [BILLING DESCRIPTION] = [TBL_ACCOUNT TYPE BILLING CODES].[BILLING CODE DESCRIPTION]
             ,[BILLING CODE QB]     =[TBL_ACCOUNT TYPE BILLING CODES].[QB BILLING ITEM CODE]
           FROM
               [TBL_BILLING INVOICE EXPORT]
                   INNER JOIN [TBL_ACCOUNT TYPE BILLING CODES] ON [TBL_ACCOUNT TYPE BILLING CODES].[BILLING CODE] =
                                                                  [TBL_BILLING INVOICE EXPORT].[BILLING CODE]
           WHERE
               ((([TBL_BILLING INVOICE EXPORT].[PAID BY BROKER FLG]) = 1));*/
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

