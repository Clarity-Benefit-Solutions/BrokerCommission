CREATE PROCEDURE dbo.[QRY_UPDATE STAGING COBRA LETTERS WITH CLIENTID] AS
    /* update CobraLetters set [ClientCode]=  CobraClientList.[ClientAlternate] joined on ClientName */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_STAGING COBRA LETTERS SUMMARY]
        SET
            [TBL_STAGING COBRA LETTERS SUMMARY].clientcode = dbo.TRIM( [TBL_STAGING COBRA CLIENT LIST].[CLIENTALTERNATE] )
        FROM
            [TBL_STAGING COBRA CLIENT LIST]
                INNER JOIN [TBL_STAGING COBRA LETTERS SUMMARY] ON [TBL_STAGING COBRA CLIENT LIST].clientname =
                                                                  [TBL_STAGING COBRA LETTERS SUMMARY].clientname;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

