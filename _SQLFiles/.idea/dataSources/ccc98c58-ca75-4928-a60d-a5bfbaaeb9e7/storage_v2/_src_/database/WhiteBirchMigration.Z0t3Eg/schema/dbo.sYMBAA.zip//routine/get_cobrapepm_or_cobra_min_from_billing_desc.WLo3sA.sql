CREATE FUNCTION dbo.get_cobrapepm_or_cobra_min_from_billing_desc(
    @BillingCode nvarchar(255), @BillingDesc nvarchar(255)) RETURNS nvarchar(255) AS
    BEGIN
        DECLARE @RetVal nvarchar(255);
        SET @RetVal = CONCAT( @BillingCode , '-' , @BillingDesc )
        
        IF @BillingCode LIKE '%COBRA' OR @BillingDesc LIKE '%COBRA'
            BEGIN
                SET @RetVal = 'COBRA'
            END
        ELSE
            IF @BillingCode LIKE '%COBRA MIN' OR @BillingDesc LIKE '%COBRA MIN'
                BEGIN
                    SET @RetVal = 'COBRA MIN'
                END
        
        RETURN @RetVal
    
    END
go

