CREATE PROCEDURE dbo.[QRY_APPEND MONTHLY MINIMUM TRNPKG TO MIN CONVERSION TBL] AS
    /* inserts all EMpCTL matching [TRN_MONTHLY MINIMUM FLG] = 1) into [TBL_MONTHLY MINIMUM CONVERSION]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_MONTHLY MINIMUM CONVERSION] (
                                                  [EMPLOYER NAME],
                                                  [EMPLOYER KEY],
                                                  [BILLING GROUP],
                                                  [EMPLOYER BILLING NUMBER],
                                                  [BROKER CODE],
                                                  [BILLING CODE],
                                                  [KEY_MM MONTHLY MINIMUM],
                                                  [MONTHLY MIN BILLING CODE],
                                                  [BILLING DESCRIPTION],
                                                  [MONTHLY MINIMUM FLG],
                                                  [MONTHLY MINIMUM AMOUNT],
                                                  [BILLING UNIT COUNT],
                                                  [BILLING UNITE RATE]
        )
        SELECT
            [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , 'TRN Monthly Min' [BILLING CODE]
          , 'Transit Monthly Minimum Fee' [KEY_MM MONTHLY MINIMUM]
          , 'Transit Monthly Minimum Fee' [MONTHLY MIN BILLING CODE]
          , 'Transit Monthly Minimum Fee' [BILLING DESCRIPTION]
          , 1 [MONTHLY MIN BILLING FLG]
          , [TBL_EMPLOYER CONTROL].[TRN_MONTHLY MINIMUM AMOUNT]
          , '1' [BILLING UNIT COUNT]
          , ([TBL_EMPLOYER CONTROL].[TRN_MONTHLY MINIMUM AMOUNT]) [BILLING UNIT RATE]
        FROM
            [TBL_EMPLOYER CONTROL]
        GROUP BY
            [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_EMPLOYER CONTROL].[TRN_MONTHLY MINIMUM AMOUNT]
          , ([TBL_EMPLOYER CONTROL].[TRN_MONTHLY MINIMUM AMOUNT])
          , [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[TRN_MONTHLY MINIMUM FLG]
        HAVING
            ((([TBL_EMPLOYER CONTROL].process) = 1) AND (([TBL_EMPLOYER CONTROL].[TRN_MONTHLY MINIMUM FLG]) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

