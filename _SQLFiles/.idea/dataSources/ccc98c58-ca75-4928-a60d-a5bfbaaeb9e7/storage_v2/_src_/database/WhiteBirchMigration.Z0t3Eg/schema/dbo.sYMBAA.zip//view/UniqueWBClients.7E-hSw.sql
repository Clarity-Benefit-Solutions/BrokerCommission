CREATE VIEW [dbo].[UniqueWBClients]
    AS
        /* list unique clients in InvExp*/
        SELECT DISTINCT
            [tbl_Billing Invoice Export All QuickBooks].[Employer Name]
          , [tbl_Billing Invoice Export All QuickBooks].[Employer Key]
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
go

