CREATE PROCEDURE dbo.[QRY_APPEND EMPLOYER ACH CREDITS TO FINAL BILLING GENERAL] AS
    /* inserts all EmpCtl union EmpACHCredits into InvExp*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT] (
                                              [BILLING GROUP],
                                              [SYSTEM EMPLOYER KEY],
                                              [EMPLOYER NAME],
                                              [EMPLOYER KEY],
                                              [EMPLOYER BILLING NUMBER],
                                              [BROKER CODE],
                                              [BILLING CODE],
                                              [BILLING UNIT COUNT],
                                              [BILLING UNIT RATE],
                                              [CALCULATED BILLING AMOUNT],
                                              [BILLING AMOUNT]
        )
        SELECT
                      [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          ,           [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          ,           [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          ,           [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          ,           [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          ,           [TBL_EMPLOYER CONTROL].[BROKER CODE]
          ,           [TBL_EMPLOYER ACH CREDITS].[QB BILLING CODE]
          ,           '1' [BILLING UNIT COUNT]
          ,           [TBL_EMPLOYER ACH CREDITS].[CREDIT AMOUNT]
          , /*Format*/([TBL_EMPLOYER ACH CREDITS].[CREDIT AMOUNT]/*, 'Fixed'*/) [CALCULATED BILLING AMOUNT]
          , /*Format*/([TBL_EMPLOYER ACH CREDITS].[CREDIT AMOUNT]/*, 'Fixed'*/) [BILLING AMOUNT]
        FROM
            [TBL_EMPLOYER ACH CREDITS]
                INNER JOIN [TBL_EMPLOYER CONTROL]
                           ON [TBL_EMPLOYER ACH CREDITS].[EMPLOYER KEY] = [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
        GROUP BY
                      [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          ,           [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          ,           [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          ,           [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          ,           [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          ,           [TBL_EMPLOYER CONTROL].[BROKER CODE]
          ,           [TBL_EMPLOYER ACH CREDITS].[QB BILLING CODE]
          ,           [TBL_EMPLOYER ACH CREDITS].[CREDIT AMOUNT]
          , /*Format*/([TBL_EMPLOYER ACH CREDITS].[CREDIT AMOUNT]/*, 'Fixed'*/)
          ,           [TBL_EMPLOYER CONTROL].process
        HAVING
            ((([TBL_EMPLOYER CONTROL].process) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

