CREATE PROCEDURE dbo.[QRY_APPEND STAGING ACCOUNTS TO PROCESS SPM] AS
    /* inserts EMPCTL records matching
       [SPM_PEPM FLG]) = 1
    into Process */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_PROCESS TABLE] (
                                     process,
                                     [EMPLOYER NAME],
                                     [EMPLOYER KEY],
                                     [BILLING GROUP],
                                     [SYSTEM EMPLOYER CODE],
                                     [EMPLOYER BILLING NUMBER],
                                     [BROKER CODE],
                                     [PARTICIPANT ID],
                                     division,
                                     [FIRST NAME],
                                     [LAST NAME],
                                     [ACCOUNT TYPE],
                                     [PLAN NAME],
                                     [PLAN START DATE],
                                     [PLAN END DATE],
                                     [PARTICIPANT STATUS],
                                     [ALLOW CLAIMS IMPORT],
                                     uniquekeyparticipant,
                                     uniquekeyaccount,
                                     uniquekeybillingaccount,
                                     [BILLING CODE],
                                     [PEPM FLG],
                                     [PEPM AMOUNT],
                                     [MONTHLY MINIMUM FLG],
                                     [MONTHLY MINIMUM AMOUNT],
                                     [PAID BY BROKER FLG],
                                     [PAID BY BROKER PERCENT],
                                     [PAID BY EMPLOYER FLG],
                                     [PAID BY EMPLOYER PERCENT]
        )
        SELECT
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_SPMBYACAREPORT DISTICT RECORDS].memberid
          , '' division
          , [TBL_SPMBYACAREPORT DISTICT RECORDS].[FIRST NAME]
          , [TBL_SPMBYACAREPORT DISTICT RECORDS].[LAST NAME]
          , [TBL_SPMBYACAREPORT DISTICT RECORDS].[ACCOUNT TYPE]
          , ([TBL_SPMBYACAREPORT DISTICT RECORDS].[ACCOUNT TYPE]) [PLAN NAME]
          , '' [PLAN START DATE]
          , '' [PLAN END DATE]
          , '' [PARTICIPANT STATUS]
          , '' [ALLOW CLAIMS IMPORT]
          , [TBL_SPMBYACAREPORT DISTICT RECORDS].uniquekey
          , ([TBL_SPMBYACAREPORT DISTICT RECORDS].[UNIQUEKEY]) uniquekeyaccount
          , ([TBL_SPMBYACAREPORT DISTICT RECORDS].[CLIENTALTERNATE] + [TBL_SPMBYACAREPORT DISTICT RECORDS].[MEMBERID] +
             [TBL_EMPLOYER CONTROL].[SPM_BILLING CODE]) uniquekeybillingaccount
          , [TBL_EMPLOYER CONTROL].[SPM_BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[SPM_PEPM FLG]
          , [TBL_EMPLOYER CONTROL].[SPM_PEPM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[SPM_MONTHLY MINIMUM FLG]
          , [TBL_EMPLOYER CONTROL].[SPM_MONTHLY MINIMUM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[SPM_PAID BY BROKER FLG]
          , [TBL_EMPLOYER CONTROL].[SPM_PAID BY BROKER PERCENT]
          , [TBL_EMPLOYER CONTROL].[SPM_PAID BY EMPLOYER FLG]
          , [TBL_EMPLOYER CONTROL].[SPM_PAID BY EMPLOYER PERCENT]
        FROM
            [TBL_EMPLOYER CONTROL]
                INNER JOIN [TBL_SPMBYACAREPORT DISTICT RECORDS] ON ([TBL_EMPLOYER CONTROL].[SPM_BILLING CODE] =
                /* embmerge - need to trim as it has leading and trailing spaces*/
                                                                    dbo.TRIM( [TBL_SPMBYACAREPORT DISTICT RECORDS].[ACCOUNT TYPE] )) AND
                                                                   (/*EMBMerge*/ /*[TBL_EMPLOYER CONTROL].[EMPLOYER KEY]*/
                                                                           [TBL_SPMBYACAREPORT DISTICT RECORDS].clientalternate IN
                                                                           ([TBL_EMPLOYER CONTROL].[Employer Key Ben Admin],
                                                                            [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]))
        GROUP BY
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_SPMBYACAREPORT DISTICT RECORDS].memberid
          , [TBL_SPMBYACAREPORT DISTICT RECORDS].[FIRST NAME]
          , [TBL_SPMBYACAREPORT DISTICT RECORDS].[LAST NAME]
          , [TBL_SPMBYACAREPORT DISTICT RECORDS].[ACCOUNT TYPE]
          , ([TBL_SPMBYACAREPORT DISTICT RECORDS].[ACCOUNT TYPE])
          , [TBL_SPMBYACAREPORT DISTICT RECORDS].uniquekey
          , ([TBL_SPMBYACAREPORT DISTICT RECORDS].[UNIQUEKEY])
          , ([TBL_SPMBYACAREPORT DISTICT RECORDS].[CLIENTALTERNATE] + [TBL_SPMBYACAREPORT DISTICT RECORDS].[MEMBERID] +
             [TBL_EMPLOYER CONTROL].[SPM_BILLING CODE])
          , [TBL_EMPLOYER CONTROL].[SPM_BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[SPM_PEPM FLG]
          , [TBL_EMPLOYER CONTROL].[SPM_PEPM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[SPM_MONTHLY MINIMUM FLG]
          , [TBL_EMPLOYER CONTROL].[SPM_MONTHLY MINIMUM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[SPM_PAID BY BROKER FLG]
          , [TBL_EMPLOYER CONTROL].[SPM_PAID BY BROKER PERCENT]
          , [TBL_EMPLOYER CONTROL].[SPM_PAID BY EMPLOYER FLG]
          , [TBL_EMPLOYER CONTROL].[SPM_PAID BY EMPLOYER PERCENT]
        HAVING
            ((([TBL_EMPLOYER CONTROL].process) = 1) AND (([TBL_EMPLOYER CONTROL].[SPM_PEPM FLG]) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

