CREATE FUNCTION get_alegeus_pepm_amount(
    @EmployerName nvarchar(255),
    @OrgEmployerName nvarchar(255),
    @CodePrefix nvarchar(255) ) RETURNS money
    BEGIN
        DECLARE @ret money;
        
        IF @CodePrefix = 'FSA'
            BEGIN
                SET @CodePrefix = 'MED';
            END
        /**/
        SELECT
            @ret = SUM( t.[Billing Amount] )
        FROM
            dbo.[tbl_Billing Invoice Export All QuickBooks] t
        WHERE
              t.[Employer Name] = @EmployerName
          AND ISNULL( t.[Original Employer Name] , '' ) = ISNULL( @OrgEmployerName , '' )
          AND t.[Billing Code] IN (@CodePrefix);
        
        IF @ret IS NULL
            BEGIN
                SET @ret = 0
            END
        
        RETURN @ret
    END
go

