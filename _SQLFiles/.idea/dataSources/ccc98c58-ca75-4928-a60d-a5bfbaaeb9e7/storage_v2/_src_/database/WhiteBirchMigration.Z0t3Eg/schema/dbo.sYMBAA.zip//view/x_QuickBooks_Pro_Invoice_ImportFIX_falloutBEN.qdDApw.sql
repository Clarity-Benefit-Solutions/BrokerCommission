CREATE VIEW [dbo].[x_QuickBooks Pro Invoice ImportFIX_falloutBEN]
    AS
        /* find null employer names  join by  QBSpelling*/
        
        SELECT DISTINCT
            insertonly_monthlyfix.*
        FROM
            insertonly_monthlyfix
                LEFT JOIN [x_QuickBooks Pro Invoice ImportFIX]
                          ON insertonly_monthlyfix.qbspelling = [x_QuickBooks Pro Invoice ImportFIX].[Employer Key]
        WHERE
            ((([x_QuickBooks Pro Invoice ImportFIX].[Employer Name]) IS NULL))
go

