CREATE PROCEDURE [dbo].[QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES] AS
BEGIN
    
    DECLARE @msg1 nvarchar(max)
    DECLARE @rowno int = 0
    DECLARE @continue int = 0
    /**/
    
    DECLARE @employer_name nvarchar(500);
    DECLARE @org_employer_name nvarchar(500);
    DECLARE @cobra_mm money;
    DECLARE @cobra_pepm money;
    DECLARE @benadm_mm money;
    DECLARE @benadm_pepm money;
    DECLARE @en_mm money;
    DECLARE @en_pepm money;
    /**/
    DECLARE @fsa_mm money;
    DECLARE @fsa_pepm money;
    DECLARE @hra_mm money;
    DECLARE @hra_pepm money;
    DECLARE @hsa_mm money;
    DECLARE @hsa_pepm money;
    DECLARE @trn_mm money;
    DECLARE @trn_pepm money;
    
    SET @continue = 1
    
    DECLARE db_cursor CURSOR FOR
        SELECT
            [Employer Name]
          , [Original Employer Name]
          , COBRA_MM
          , COBRA_PEPM
          , BENADMIN_MM
          , BENADMIN_PEPM
          , EN_MM
          , EN_PEPM
          , FSA_MM
          , FSA_PEPM
          , HRA_MM
          , HRA_PEPM
          , HSA_MM
          , HSA_PEPM
          , TRN_MM
          , TRN_PEPM
        FROM
            [QRY_BILLING INVOICE EXPORT QUICK BOOKS GET MM PEPM Totals]
        ORDER BY
            [Employer Name]
          , [Original Employer Name];
    
    EXEC db_log_message 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' , ' OPENING CURSOR' ,
         'INFO';
    
    /* update org employer name where null */
    UPDATE dbo.[tbl_Billing Invoice Export All QuickBooks]
    SET
        [Original Employer Name] = [Employer Name]
    WHERE
        RTRIM( LTRIM( ISNULL( [Original Employer Name] , '' ) ) ) = '';
    
    /**/
    OPEN db_cursor
    /**/
    
    WHILE @continue = 1 BEGIN
        FETCH NEXT FROM db_cursor INTO
            @employer_name, @org_employer_name
            , @cobra_mm, @cobra_pepm
            , @benadm_mm, @benadm_pepm
            , @en_mm, @en_pepm
            , @fsa_mm, @fsa_pepm
            , @hra_mm, @hra_pepm
            , @hsa_mm, @hsa_pepm
            , @trn_mm, @trn_pepm;
        /**/
        IF @@FETCH_STATUS <> 0
            BEGIN
                SET @continue = 0
                BREAK
            END
        /**/
        
        SET @rowno = @rowno + 1;
        BEGIN TRY
            SET @msg1 = CONCAT( '#RowNo ' , @rowno , 'Processing Emp: ' , @employer_name , ', Org Emp: ' ,
                                @org_employer_name , ', COBRA MM: ' , @cobra_mm , ', COBRA PEPM: ' , @cobra_pepm ,
                                ', BENADM MM: ' , @benadm_mm , ', BENADM PEPM: ' , @benadm_pepm
                )
            
            EXEC db_log_message 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' , @msg1 , 'INFO';
            
            /*COBRA*/
            IF @cobra_pepm <> 0 OR @cobra_mm <> 0
                BEGIN
                    IF @cobra_pepm >= @cobra_mm AND @cobra_pepm <> 0
                        BEGIN
                            SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                @org_employer_name , ' Removing cobra MM' , ', COBRA MM: ' , @cobra_mm ,
                                                ', COBRA PEPM: ' , @cobra_pepm )
                            EXEC db_log_message 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                 @msg1 , 'INFO';
                            --
                            UPDATE [tbl_Billing Invoice Export All QuickBooks]
                            SET
                                ToDelete     = 1,
                                DeleteReason = 'REMDUPSQB: Removing cobra MM'
                            WHERE
                                  [Employer Name] = @employer_name
                              AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                              AND [Billing Code] = 'COBRA MIN';
                        END
                    ELSE
                        IF @cobra_pepm < @cobra_mm AND @cobra_pepm <> 0
                            BEGIN
                                SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                    @org_employer_name , ' Removing cobra PEPM' , ', COBRA MM: ' ,
                                                    @cobra_mm , ', COBRA PEPM: ' , @cobra_pepm )
                                EXEC db_log_message
                                     'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                     @msg1 , 'INFO';
                                --
                                UPDATE [tbl_Billing Invoice Export All QuickBooks]
                                SET
                                    ToDelete     = 1,
                                    DeleteReason = 'REMDUPSQB: Removing cobra PEPM'
                                WHERE
                                      [Employer Name] = @employer_name
                                  AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                                  AND [Billing Code] = 'COBRA';
                            END
                END
            
            /*BENADM*/
            IF @benadm_pepm <> 0 OR @benadm_mm <> 0
                BEGIN
                    IF @benadm_pepm >= @benadm_mm AND @benadm_pepm <> 0
                        BEGIN
                            SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                @org_employer_name , ' Removing BENADM MM' , ', BENADM MM: ' ,
                                                @benadm_mm , ', BENADM PEPM: ' , @benadm_pepm )
                            EXEC db_log_message 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                 @msg1 , 'INFO';
                            --
                            UPDATE [tbl_Billing Invoice Export All QuickBooks]
                            SET
                                ToDelete     = 1,
                                DeleteReason = 'REMDUPSQB: Removing BENADM MM'
                            WHERE
                                  [Employer Name] = @employer_name
                              AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                              AND [Billing Code] IN ('BENADMIN MIN', 'ENBENADMIN');
                        END
                    ELSE
                        --
                        IF @benadm_pepm < @benadm_mm AND @benadm_mm <> 0
                            BEGIN
                                SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                    @org_employer_name , ' Removing BENADM PEPM' , ', BENADM MM: ' ,
                                                    @benadm_mm , ', BENADM PEPM: ' , @benadm_pepm )
                                EXEC db_log_message
                                     'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                     @msg1 , 'INFO';
                                
                                UPDATE [tbl_Billing Invoice Export All QuickBooks]
                                SET
                                    ToDelete     = 1,
                                    DeleteReason = 'REMDUPSQB: Removing BENADM PEPM'
                                WHERE
                                      [Employer Name] = @employer_name
                                  AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                                  AND [Billing Code] IN ('BENADMBE', 'BENADMNBE', 'ENPEPM');
                            END
                END
            
            /*             /*EN*/
                         IF @en_pepm <> 0 OR @en_mm <> 0
                             BEGIN
                                 IF @en_pepm >= @en_mm AND @en_pepm <> 0
                                     BEGIN
                                         SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                             @org_employer_name , ' Removing en MM' , ', en MM: ' ,
                                                             @en_mm , ', en PEPM: ' , @en_pepm )
                                         EXEC db_log_message 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                              @msg1 , 'INFO';
                                         --
                                         UPDATE [tbl_Billing Invoice Export All QuickBooks]
                                         SET
                                             ToDelete     = 1,
                                             DeleteReason = 'REMDUPSQB: Removing en MM'
                                         WHERE
                                               [Employer Name] = @employer_name
                                           AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                                           AND [Billing Code] = 'ENBENADMIN';
                                     END
                                 ELSE
                                     --
                                     IF @en_pepm < @en_mm AND @en_mm <> 0
                                         BEGIN
                                             SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                                 @org_employer_name , ' Removing en PEPM' , ', en MM: ' ,
                                                                 @en_mm , ', en PEPM: ' , @en_pepm )
                                             EXEC db_log_message
                                                  'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                                  @msg1 , 'INFO';

                                             UPDATE [tbl_Billing Invoice Export All QuickBooks]
                                             SET
                                                 ToDelete     = 1,
                                                 DeleteReason = 'REMDUPSQB: Removing en PEPM'
                                             WHERE
                                                   [Employer Name] = @employer_name
                                               AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                                               AND [Billing Code] IN ('ENPEPM');
                                         END
                             END*/
            
            /*FSA*/
            IF @FSA_pepm <> 0 OR @FSA_mm <> 0
                BEGIN
                    IF @FSA_pepm >= @FSA_mm AND @FSA_pepm <> 0
                        BEGIN
                            SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                @org_employer_name , ' Removing FSA MM' , ', FSA MM: ' , @FSA_mm ,
                                                ', FSA PEPM: ' , @FSA_pepm )
                            EXEC db_log_message 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                 @msg1 , 'INFO';
                            --
                            UPDATE [tbl_Billing Invoice Export All QuickBooks]
                            SET
                                ToDelete     = 1,
                                DeleteReason = 'REMDUPSQB: Removing FSA MM'
                            WHERE
                                  [Employer Name] = @employer_name
                              AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                              AND [Billing Code] LIKE (CONCAT( 'FSA' , ' ' , 'Monthly Min' ));
                        END
                    ELSE
                        IF @FSA_pepm < @FSA_mm AND @FSA_pepm <> 0
                            BEGIN
                                SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                    @org_employer_name , ' Removing FSA PEPM' , ', FSA MM: ' ,
                                                    @FSA_mm , ', FSA PEPM: ' , @FSA_pepm )
                                EXEC db_log_message
                                     'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                     @msg1 , 'INFO';
                                --
                                UPDATE [tbl_Billing Invoice Export All QuickBooks]
                                SET
                                    ToDelete     = 1,
                                    DeleteReason = 'REMDUPSQB: Removing FSA PEPM'
                                WHERE
                                      [Employer Name] = @employer_name
                                  AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                                  AND [Billing Code] IN ('FSA', 'MED');
                            END
                END
            
            /*HRA*/
            IF @HRA_pepm <> 0 OR @HRA_mm <> 0
                BEGIN
                    IF @HRA_pepm >= @HRA_mm AND @HRA_pepm <> 0
                        BEGIN
                            SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                @org_employer_name , ' Removing HRA MM' , ', HRA MM: ' , @HRA_mm ,
                                                ', HRA PEPM: ' , @HRA_pepm )
                            EXEC db_log_message 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                 @msg1 , 'INFO';
                            --
                            UPDATE [tbl_Billing Invoice Export All QuickBooks]
                            SET
                                ToDelete     = 1,
                                DeleteReason = 'REMDUPSQB: Removing HRA MM'
                            WHERE
                                  [Employer Name] = @employer_name
                              AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                              AND [Billing Code] LIKE (CONCAT( 'HRA' , ' ' , 'Monthly Min' ));
                        END
                    ELSE
                        IF @HRA_pepm < @HRA_mm AND @HRA_pepm <> 0
                            BEGIN
                                SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                    @org_employer_name , ' Removing HRA PEPM' , ', HRA MM: ' ,
                                                    @HRA_mm , ', HRA PEPM: ' , @HRA_pepm )
                                EXEC db_log_message
                                     'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                     @msg1 , 'INFO';
                                --
                                UPDATE [tbl_Billing Invoice Export All QuickBooks]
                                SET
                                    ToDelete     = 1,
                                    DeleteReason = 'REMDUPSQB: Removing HRA PEPM'
                                WHERE
                                      [Employer Name] = @employer_name
                                  AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                                  AND [Billing Code] = 'HRA';
                            END
                END
            
            /*HSA*/
            IF @HSA_pepm <> 0 OR @HSA_mm <> 0
                BEGIN
                    IF @HSA_pepm >= @HSA_mm AND @HSA_pepm <> 0
                        BEGIN
                            SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                @org_employer_name , ' Removing HSA MM' , ', HSA MM: ' , @HSA_mm ,
                                                ', HSA PEPM: ' , @HSA_pepm )
                            EXEC db_log_message 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                 @msg1 , 'INFO';
                            --
                            UPDATE [tbl_Billing Invoice Export All QuickBooks]
                            SET
                                ToDelete     = 1,
                                DeleteReason = 'REMDUPSQB: Removing HSA MM'
                            WHERE
                                  [Employer Name] = @employer_name
                              AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                              AND [Billing Code] LIKE (CONCAT( 'HSA' , ' ' , 'Monthly Min' ));
                        END
                    ELSE
                        IF @HSA_pepm < @HSA_mm AND @HSA_pepm <> 0
                            BEGIN
                                SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                    @org_employer_name , ' Removing HSA PEPM' , ', HSA MM: ' ,
                                                    @HSA_mm , ', HSA PEPM: ' , @HSA_pepm )
                                EXEC db_log_message
                                     'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                     @msg1 , 'INFO';
                                --
                                UPDATE [tbl_Billing Invoice Export All QuickBooks]
                                SET
                                    ToDelete     = 1,
                                    DeleteReason = 'REMDUPSQB: Removing HSA PEPM'
                                WHERE
                                      [Employer Name] = @employer_name
                                  AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                                  AND [Billing Code] = 'HSA';
                            END
                END
            
            /*TRN*/
            IF @TRN_pepm <> 0 OR @TRN_mm <> 0
                BEGIN
                    IF @TRN_pepm >= @TRN_mm AND @TRN_pepm <> 0
                        BEGIN
                            SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                @org_employer_name , ' Removing TRN MM' , ', TRN MM: ' , @TRN_mm ,
                                                ', TRN PEPM: ' , @TRN_pepm )
                            EXEC db_log_message 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                 @msg1 , 'INFO';
                            --
                            UPDATE [tbl_Billing Invoice Export All QuickBooks]
                            SET
                                ToDelete     = 1,
                                DeleteReason = 'REMDUPSQB: Removing TRN MM'
                            WHERE
                                  [Employer Name] = @employer_name
                              AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                              AND [Billing Code] LIKE (CONCAT( 'TRN' , ' ' , 'Monthly Min' ));
                        END
                    ELSE
                        IF @TRN_pepm < @TRN_mm AND @TRN_pepm <> 0
                            BEGIN
                                SET @msg1 = CONCAT( ' --- Emp: ' , @employer_name , ', Org Emp: ' ,
                                                    @org_employer_name , ' Removing TRN PEPM' , ', TRN MM: ' ,
                                                    @TRN_mm , ', TRN PEPM: ' , @TRN_pepm )
                                EXEC db_log_message
                                     'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                                     @msg1 , 'INFO';
                                --
                                UPDATE [tbl_Billing Invoice Export All QuickBooks]
                                SET
                                    ToDelete     = 1,
                                    DeleteReason = 'REMDUPSQB: Removing TRN PEPM'
                                WHERE
                                      [Employer Name] = @employer_name
                                  AND ISNULL( [Original Employer Name] , '' ) = ISNULL( @org_employer_name , '' )
                                  AND [Billing Code] = 'PKGTRN';
                            END
                END
            
            /**/
        END TRY BEGIN CATCH
            SET @msg1 = CONCAT( @rowno , ' - ' , 'ERROR: ' , ERROR_MESSAGE( ) , ' FOR RECORD ' , @msg1 );
            EXEC db_log_error 50001 , 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' , @msg1 ,
                 'ERROR';
        END CATCH
        
        /**/
    END
    /* while*/
    
    SELECT *
    FROM
        dbo.[tbl_Billing Invoice Export All QuickBooks]
    WHERE
          ToDelete = 1
      AND DeleteReason LIKE '%REMDUPS%'
    
    ORDER BY
        [Employer Name]
      , [Original Employer Name]
      , [Billing Code]
    
    /**/
    CLOSE db_cursor
    DEALLOCATE db_cursor
    
    /**/
    
    SET @msg1 = CONCAT( '**LOG** ' , 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                        ' FINISHED ROW COUNT: ' , @rowno );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT
    
    /* remove duplicated codes from process backup all and backup export to match invoices */
    EXEC [dbo].[QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES FROM PROCESS AND BACKUP];

END
go

