CREATE VIEW vw_utils_compare_qb_process_backup_reporting AS
    SELECT
        '2 BACKUP EXP' TableName
      , t.[Employer Name]
      , ISNULL( t.[ORIGINAL EMPLOYER NAME] , t.[Employer Name] ) [ORIGINAL EMPLOYER NAME]
      , t.[ACTUAL_BILLING CODE] [Billing Code]
      , t.[PEPM]
      , t.[PEPM AMOUNT]
      , t.[BILLING CODE] [Billing Code QB]
      , t.[Billing Description]
      , t.[Billing Group Process]
      , t.ToDelete
      , t.[BND_BILLING CODE]
      , t.[PEPM Flg]
      , t.Division
      , t.[Employer Key]
      , t.[Last Name]
      , t.[First Name]
      , t.[Participant Status]
      , t.[Participant Term Date]
    FROM
        [TBL_BACKUP REPORTING EXPORT TABLE] t
    WHERE
          1 = 1
      AND ISNULL( t.ToDelete , 0 ) <> 1
    UNION ALL
    /* inv by emp name*/
    SELECT
        '3 INV QB' TableName
      , t.[Employer Name]
      , ISNULL( t.[ORIGINAL EMPLOYER NAME] , t.[Employer Name] ) [ORIGINAL EMPLOYER NAME]
      , t.[BILLING CODE]
      , t.[Billing Unit Count]
      , t.[Billing Amount]
      , t.[Billing Code QB]
      , t.[Billing Description]
      , t.[Billing Group Process]
      , t.ToDelete
      , NULL
      , NULL
      , NULL
      , t.[Employer Key]
      , NULL
      , NULL
      , NULL
      , NULL
    
    FROM
        dbo.[tbl_Billing Invoice Export All QuickBooks] t
    WHERE
          1 = 1
      AND ISNULL( t.ToDelete , 0 ) <> 1
go

