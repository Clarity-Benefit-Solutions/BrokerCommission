CREATE VIEW [dbo].[qry_Report Division Billing Groups]
    AS
        /* count EmplCtl records for DIVISION billing group   */
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[System Employer Code]
          , [tbl_Employer Control].process
        FROM
            [tbl_Employer Control]
        WHERE
            ((([tbl_Employer Control].[Billing Group]) LIKE '%Division%'))
go

