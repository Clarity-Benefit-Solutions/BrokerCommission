CREATE VIEW [dbo].[qry_Report Final Billing Compare Prior-Current]
    AS
        /* compare inv items units and amounts prior and current for billing period 'November 2018' ?? WHY?*/
        SELECT
            [tbl_Billing Invoice Export].[Employer Key]
          , [tbl_Billing Invoice Export].[Employer Name]
          , [tbl_Billing Invoice Export].[Billing Code QB]
          , ([tbl_Billing Invoice Export].[Billing Period]) [Current Billing Period]
          , ([tbl_Billing Invoice Export].[Billing Unit Count]) [Current Billing Unit Count]
          , ([tbl_Billing Invoice Export Archive].[Billing Unit Count]) [Prior Billing Unit Count]
          , ([tbl_Billing Invoice Export].[Billing Unit Count] -
             [tbl_Billing Invoice Export Archive].[Billing Unit Count]) [Unit Count Difference]
          , ([tbl_Billing Invoice Export].[Billing Amount]) [Current Billing Amount]
          , ([tbl_Billing Invoice Export Archive].[Billing Amount]) [Prior Billing Amount]
          , ([tbl_Billing Invoice Export].[Billing Amount] -
             [tbl_Billing Invoice Export Archive].[Billing Amount]) [Billing Amount Difference]
        FROM
            [tbl_Billing Invoice Export]
                RIGHT JOIN [tbl_Billing Invoice Export Archive] ON ([tbl_Billing Invoice Export].[Billing Code QB] =
                                                                    [tbl_Billing Invoice Export Archive].[Billing Code QB]) AND
                                                                   ([tbl_Billing Invoice Export].[Employer Name] =
                                                                    [tbl_Billing Invoice Export Archive].[Employer Name])
        WHERE
            (((([tbl_Billing Invoice Export Archive].[Billing Period])) = 'November 2018'))
go

