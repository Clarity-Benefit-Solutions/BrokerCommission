CREATE FUNCTION get_employers_to_process_name_filter() RETURNS nvarchar(255) AS
    
    BEGIN
        RETURN '%';
        /*
        City of Red
        'BioStem Technologies, Inc.'
        'Venatore LLC'
        'Acordis International Corp'
        'Naval Continuing Care dba Fleet Landing'
        'TST Tactical Defense Solutions'
        '%'
         */
    END
go

