CREATE VIEW [dbo].[qry_Termination Management]
    AS
        /* list EmplCtl records for billing group '%term%''*/
        SELECT
            [tbl_Employer Control].notes
          , [tbl_Employer Control].recordid
          , [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].[ALLProcess YES]
          , [tbl_Employer Control].[ALLProcess NO]
          , [tbl_Employer Control].process
          , [tbl_Employer Control].[QB Client Type]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[Employer Status]
          , [tbl_Employer Control].[Employer Effective Date]
          , [tbl_Employer Control].[Employer Term Date]
        FROM
            [tbl_Employer Control]
        WHERE
            ((([tbl_Employer Control].[Billing Group]) LIKE '%term%'))
go

