CREATE  PROCEDURE [dbo].[_process_6_division_all] AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        BEGIN/*clear procedure cache - very important when debugging!*/
            DBCC FREEPROCCACHE
            
            
            /*     */
            EXEC [dbo].[_process_4_1_clear_temp_trn_tables]
            /*     */
            EXEC [dbo].[_process_4_1_fix_trn_tables]
            
            /*     */
            EXEC [dbo].[qry_Update Employer Control Process All To No];
            EXEC [dbo].[qry_Update Employer Control Process DIVISION To Yes];
            
            /*     */
            EXEC [dbo].[_process_append_all_non_bnd_to_process]
            
            /*     */
            EXEC [dbo].[_process_append_all_to_monthly_min]
            
            /*     */
            EXEC [dbo].[_process_update_divisions];
            
            /*     */
            EXEC [dbo].[_process_billing_all_non_bnd] 0;
            
            /*     */
            EXEC [dbo].[_process_update_min_conv_table];
            
            /*     */
            EXEC [dbo].[_process_update_billing_and_append_to_QB] 1 , 0 , 0 , 'DIVISION';;
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

