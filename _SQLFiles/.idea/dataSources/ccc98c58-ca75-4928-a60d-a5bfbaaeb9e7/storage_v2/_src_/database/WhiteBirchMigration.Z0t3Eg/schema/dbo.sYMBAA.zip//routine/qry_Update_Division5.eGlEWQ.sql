CREATE PROCEDURE dbo.[QRY_UPDATE DIVISION5] AS
    /* update Process set [Employer Billing Number] =  EmpCtl.[Employer Billing Number] joined on [Billing Group] and Employer Name]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_PROCESS TABLE]
        SET
            [TBL_PROCESS TABLE].[EMPLOYER BILLING NUMBER] = [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
        FROM
            [TBL_PROCESS TABLE]
                INNER JOIN [TBL_EMPLOYER CONTROL]
                           ON ([TBL_PROCESS TABLE].[BILLING GROUP] = [TBL_EMPLOYER CONTROL].[BILLING GROUP]) AND
                              ([TBL_PROCESS TABLE].[EMPLOYER NAME] = [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]);
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

