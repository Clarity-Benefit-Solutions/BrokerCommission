CREATE VIEW [dbo].[Reprocess_List_Check_select]
    AS
        /* list EmplCtl records marked for reprocess by Clientname*/
        SELECT
            [tbl_Employer Control].process
          , reprocesslist.client_name
          , [tbl_Employer Control].[Billing Group]
        FROM
            reprocesslist
                INNER JOIN [tbl_Employer Control] ON reprocesslist.client_name = [tbl_Employer Control].[Employer Name]
go

