CREATE VIEW [dbo].[Find duplicates Employee ID In tbl_Process Table]
    AS
        /* find all Process records with duplicated UniqueKeyBundleBilling  */
        SELECT
            [tbl_Process Table].[Participant ID]
          , [tbl_Process Table].uniquekeyparticipant
          , [tbl_Process Table].process
          , [tbl_Process Table].[Billing Group]
          , [tbl_Process Table].[Employer Name]
          , [tbl_Process Table].[Employer Key]
          , [tbl_Process Table].[Employer Billing Number]
          , [tbl_Process Table].[System Employer Code]
          , [tbl_Process Table].[Broker Code]
          , [tbl_Process Table].[Broker Name]
          , [tbl_Process Table].[First Name]
          , [tbl_Process Table].[Last Name]
          , [tbl_Process Table].[Account Type]
          , [tbl_Process Table].[Plan Name]
          , [tbl_Process Table].[Plan Start Date]
          , [tbl_Process Table].[Plan End Date]
          , [tbl_Process Table].[Participant Status]
          , [tbl_Process Table].[Enrollment Amount]
          , [tbl_Process Table].[Contribution Amount]
          , [tbl_Process Table].[Coverage Tier]
          , [tbl_Process Table].[Allow Claims Import]
          , [tbl_Process Table].uniquekeybundlebilling
          , [tbl_Process Table].uniquekeyaccount
          , [tbl_Process Table].uniquekeybillingaccount
          , [tbl_Process Table].[BILLING CODE]
          , [tbl_Process Table].[PEPM FLG]
          , [tbl_Process Table].[PEPM COUNT]
          , [tbl_Process Table].[PEPM AMOUNT]
          , [tbl_Process Table].[Key_MM Monthly Minimum]
          , [tbl_Process Table].[MONTHLY MINIMUM FLG]
          , [tbl_Process Table].[MONTHLY MINIMUM AMOUNT]
          , [tbl_Process Table].[BND_BILLING CODE]
          , [tbl_Process Table].[BND_BUNDLE BILL FLG]
          , [tbl_Process Table].[BND_BUNDLE RATE AMOUNT]
          , [tbl_Process Table].[BND_BUNDLE BILL QUAL]
          , [tbl_Process Table].[FLAT RATE FLG]
          , [tbl_Process Table].[FLAT RATE AMOUNT]
          , [tbl_Process Table].[PAID BY BROKER FLG]
          , [tbl_Process Table].[PAID BY BROKER PERCENT]
          , [tbl_Process Table].[PAID BY EMPLOYER FLG]
          , [tbl_Process Table].[PAID BY EMPLOYER PERCENT]
          , [tbl_Process Table].[COBRA_Letter Type]
          , [tbl_Process Table].[COBRA_PER NOTICE FLG]
          , [tbl_Process Table].[COBRA_PER NOTICE AMOUNT]
          , [tbl_Process Table].[COBRA_Notice Bill Amount]
          , [tbl_Process Table].[COBRA_Notice Count]
          , [tbl_Process Table].[COBRA_PEPM Count]
          , [tbl_Process Table].[LAST BILLED DATE]
          , [tbl_Process Table].[GENERAL BILLING CODE]
          , [tbl_Process Table].[GENERAL KEY_MM]
          , [tbl_Process Table].[GENERAL BILLING FLG]
          , [tbl_Process Table].[GENERAL BILLING COUNT]
          , [tbl_Process Table].[GENERAL BILLING RATE]
          , [tbl_Process Table].[GENERAL BILLING AMOUNT]
        FROM
            [tbl_Process Table]
        WHERE
            ((([tbl_Process Table].uniquekeybundlebilling) IN (
                                                                  SELECT
                                                                      [UniqueKeyBundleBilling]
                                                                  FROM
                                                                      [tbl_Process Table] AS tmp
                                                                  GROUP BY
                                                                      [UniqueKeyBundleBilling]
                                                                  HAVING
                                                                      COUNT( * ) > 1
                                                              )) AND
             (([tbl_Process Table].[BND_BILLING CODE]) IS NOT NULL) AND
             (([tbl_Process Table].[BND_BUNDLE BILL FLG]) = 1))
go

