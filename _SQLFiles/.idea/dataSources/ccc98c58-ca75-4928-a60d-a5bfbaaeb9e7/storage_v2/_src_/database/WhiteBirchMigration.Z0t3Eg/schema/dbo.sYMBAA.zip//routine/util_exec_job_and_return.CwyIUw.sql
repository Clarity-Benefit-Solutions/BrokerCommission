CREATE PROCEDURE [dbo].[util_exec_job_and_return](
                                                @job_name nvarchar(500),
                                                @out_starttime datetime OUTPUT ) AS
BEGIN
    BEGIN TRY
        
        DECLARE @msg nvarchar(max);
        DECLARE @starttime datetime;
        
        SET @starttime = GETDATE( );
        -- deduct 15 seconds so we cAN GET LOGS
        SET @starttime = DATEADD( SECOND , -5 , @starttime )
        SELECT
            @out_starttime = @starttime;
        --         SELECT
        --             @OUT_starttime = @starttime;
        
        /* execute the job*/
        EXEC msdb.dbo.sp_start_job @job_name = @job_name;
        
        -- Check exit code
        SELECT
                @msg = 'REQUESTED START of Job: ' + @job_name + ' AT: ' + CAST( @starttime AS nvarchar )
        
        --
        EXEC dbo.db_log_message 'util_exec_job_and_return' , @msg , 'WARN' , 0;
    
    END TRY BEGIN CATCH
        DECLARE @errno varchar(500) = ERROR_NUMBER( )
        DECLARE @errmsg varchar(2000) = ERROR_MESSAGE( )
        DECLARE @errstate varchar(200) = ERROR_STATE( )
        
        EXEC dbo.db_throw_error 50001 , @job_name , @errmsg;
    
    END CATCH
END
go

