CREATE PROCEDURE dbo.[QRY_APPEND PROCESS TBL TO PROCESS TBL ALL BACKUP] AS
    /* inserts all Process records into Processbackup */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_PROCESS TABLE ALL BACKUP] (
                                                process,
                                                [BILLING GROUP],
                                                [EMPLOYER NAME],
                                                [ORIGINAL EMPLOYER NAME],
                                                [EMPLOYER KEY],
                                                [EMPLOYER BILLING NUMBER],
                                                [SYSTEM EMPLOYER CODE],
                                                [BROKER CODE],
                                                [BROKER NAME],
                                                [DIVISION BILLING KEY],
                                                division,
                                                [PARTICIPANT ID],
                                                [FIRST NAME],
                                                [LAST NAME],
                                                [ACCOUNT TYPE],
                                                [PLAN NAME],
                                                [PLAN START DATE],
                                                [PLAN END DATE],
                                                [PARTICIPANT STATUS],
                                                [PARTICIPANT TERM DATE],
                                                [ENROLLMENT AMOUNT],
                                                [CONTRIBUTION AMOUNT],
                                                [COVERAGE TIER],
                                                [ALLOW CLAIMS IMPORT],
                                                uniquekeyparticipant,
                                                uniquekeyaccount,
                                                uniquekeybundlebilling,
                                                uniquekeybillingaccount,
                                                [BILLING CODE],
                                                [PEPM FLG],
                                                [PEPM COUNT],
                                                [PEPM AMOUNT],
                                                [KEY_MM MONTHLY MINIMUM],
                                                [MONTHLY MINIMUM FLG],
                                                [MONTHLY MINIMUM AMOUNT],
                                                [BND_BILLING CODE],
                                                [BND_BUNDLE BILL FLG],
                                                [BND_BUNDLE RATE AMOUNT],
                                                [BND_BUNDLE BILL QUAL],
                                                [FLAT RATE FLG],
                                                [FLAT RATE AMOUNT],
                                                [PAID BY BROKER FLG],
                                                [PAID BY BROKER PERCENT],
                                                [PAID BY EMPLOYER FLG],
                                                [PAID BY EMPLOYER PERCENT],
                                                [COBRA_LETTER TYPE],
                                                [COBRA_PER NOTICE FLG],
                                                [COBRA_PER NOTICE AMOUNT],
                                                [COBRA_NOTICE BILL AMOUNT],
                                                [COBRA_NOTICE COUNT],
                                                [COBRA_PEPM COUNT],
                                                [LAST BILLED DATE],
                                                [GENERAL BILLING CODE],
                                                [GENERAL KEY_MM],
                                                [GENERAL BILLING FLG],
                                                [GENERAL BILLING COUNT],
                                                [GENERAL BILLING RATE],
                                                [GENERAL BILLING AMOUNT]
        )
        SELECT
            [TBL_PROCESS TABLE].process
          , [TBL_PROCESS TABLE].[BILLING GROUP]
          , [TBL_PROCESS TABLE].[EMPLOYER NAME]
          , [TBL_PROCESS TABLE].[ORIGINAL EMPLOYER NAME]
          , [TBL_PROCESS TABLE].[EMPLOYER KEY]
          , [TBL_PROCESS TABLE].[EMPLOYER BILLING NUMBER]
          , [TBL_PROCESS TABLE].[SYSTEM EMPLOYER CODE]
          , [TBL_PROCESS TABLE].[BROKER CODE]
          , [TBL_PROCESS TABLE].[BROKER NAME]
          , [TBL_PROCESS TABLE].[DIVISION BILLING KEY]
          , [TBL_PROCESS TABLE].division
          , [TBL_PROCESS TABLE].[PARTICIPANT ID]
          , [TBL_PROCESS TABLE].[FIRST NAME]
          , [TBL_PROCESS TABLE].[LAST NAME]
          , [TBL_PROCESS TABLE].[ACCOUNT TYPE]
          , [TBL_PROCESS TABLE].[PLAN NAME]
          , [TBL_PROCESS TABLE].[PLAN START DATE]
          , [TBL_PROCESS TABLE].[PLAN END DATE]
          , [TBL_PROCESS TABLE].[PARTICIPANT STATUS]
          , [TBL_PROCESS TABLE].[PARTICIPANT TERM DATE]
          , [TBL_PROCESS TABLE].[ENROLLMENT AMOUNT]
          , [TBL_PROCESS TABLE].[CONTRIBUTION AMOUNT]
          , [TBL_PROCESS TABLE].[COVERAGE TIER]
          , [TBL_PROCESS TABLE].[ALLOW CLAIMS IMPORT]
          , [TBL_PROCESS TABLE].uniquekeyparticipant
          , [TBL_PROCESS TABLE].uniquekeyaccount
          , [TBL_PROCESS TABLE].uniquekeybundlebilling
          , [TBL_PROCESS TABLE].uniquekeybillingaccount
          , [TBL_PROCESS TABLE].[BILLING CODE]
          , [TBL_PROCESS TABLE].[PEPM FLG]
          , [TBL_PROCESS TABLE].[PEPM COUNT]
          , [TBL_PROCESS TABLE].[PEPM AMOUNT]
          , [TBL_PROCESS TABLE].[KEY_MM MONTHLY MINIMUM]
          , [TBL_PROCESS TABLE].[MONTHLY MINIMUM FLG]
          , [TBL_PROCESS TABLE].[MONTHLY MINIMUM AMOUNT]
          , [TBL_PROCESS TABLE].[BND_BILLING CODE]
          , [TBL_PROCESS TABLE].[BND_BUNDLE BILL FLG]
          , [TBL_PROCESS TABLE].[BND_BUNDLE RATE AMOUNT]
          , [TBL_PROCESS TABLE].[BND_BUNDLE BILL QUAL]
          , [TBL_PROCESS TABLE].[FLAT RATE FLG]
          , [TBL_PROCESS TABLE].[FLAT RATE AMOUNT]
          , [TBL_PROCESS TABLE].[PAID BY BROKER FLG]
          , [TBL_PROCESS TABLE].[PAID BY BROKER PERCENT]
          , [TBL_PROCESS TABLE].[PAID BY EMPLOYER FLG]
          , [TBL_PROCESS TABLE].[PAID BY EMPLOYER PERCENT]
          , [TBL_PROCESS TABLE].[COBRA_LETTER TYPE]
          , [TBL_PROCESS TABLE].[COBRA_PER NOTICE FLG]
          , [TBL_PROCESS TABLE].[COBRA_PER NOTICE AMOUNT]
          , [TBL_PROCESS TABLE].[COBRA_NOTICE BILL AMOUNT]
          , [TBL_PROCESS TABLE].[COBRA_NOTICE COUNT]
          , [TBL_PROCESS TABLE].[COBRA_PEPM COUNT]
          , [TBL_PROCESS TABLE].[LAST BILLED DATE]
          , [TBL_PROCESS TABLE].[GENERAL BILLING CODE]
          , [TBL_PROCESS TABLE].[GENERAL KEY_MM]
          , [TBL_PROCESS TABLE].[GENERAL BILLING FLG]
          , [TBL_PROCESS TABLE].[GENERAL BILLING COUNT]
          , [TBL_PROCESS TABLE].[GENERAL BILLING RATE]
          , [TBL_PROCESS TABLE].[GENERAL BILLING AMOUNT]
        FROM
            [TBL_PROCESS TABLE];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

