CREATE VIEW [dbo].[tbl_Staging COBRA Client List Without Matching tbl_Employer Cont]
    AS
        /* list EmplCtl records not found but present in Cobra import*/
        SELECT
            [tbl_Staging COBRA Client List].clientgroupname
          , [tbl_Staging COBRA Client List].clientname
          , [tbl_Staging COBRA Client List].clientalternate
          , [tbl_Staging COBRA Client List].billingstartdate
        FROM
            [tbl_Staging COBRA Client List]
                LEFT JOIN [tbl_Employer Control]
                          ON [tbl_Staging COBRA Client List].[ClientAlternate] = [tbl_Employer Control].[Employer Key]
        WHERE
            ((([tbl_Employer Control].[Employer Key]) IS NULL))
go

