CREATE VIEW [dbo].[PCORI_active]
    AS
        /* records from QBClients also present in  PCORI2020 on BenCode  */
        SELECT DISTINCT
            pcori2020.*
        FROM
            clarity_qb_customers
                INNER JOIN pcori2020 ON clarity_qb_customers.customfieldbencode = pcori2020.bencode
go

