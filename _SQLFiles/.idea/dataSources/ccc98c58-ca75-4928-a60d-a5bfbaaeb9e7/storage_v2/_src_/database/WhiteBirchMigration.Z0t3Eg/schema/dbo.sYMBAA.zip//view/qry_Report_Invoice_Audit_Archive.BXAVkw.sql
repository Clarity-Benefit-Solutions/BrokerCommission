CREATE VIEW [dbo].[qry_Report Invoice Audit Archive]
    AS
        /* Audit PRIOR inv items by BillingGroup , Employer, invoice number */
        SELECT
            [tbl_Billing Invoice Export Archive].[Billing Period]
          , [tbl_Billing Invoice Export Archive].[Employer Name]
          , [tbl_Billing Invoice Export Archive].[Employer Key]
          , [tbl_Billing Invoice Export Archive].[Billing Code]
          , [tbl_Billing Invoice Export Archive].[Billing Description]
          , SUM( [tbl_Billing Invoice Export Archive].[Billing Unit Count] ) [SumOfBilling Unit Count]
          , [tbl_Billing Invoice Export Archive].[Billing Unit Rate]
          , SUM( [tbl_Billing Invoice Export Archive].[Billing Amount] ) [SumOfBilling Amount]
        FROM
            [tbl_Employer Control]
                INNER JOIN [tbl_Billing Invoice Export Archive]
                           ON /*EMBMerge*/ /*[TBL_EMPLOYER CONTROL].[EMPLOYER KEY]*/
/*EMBMerge end*/ 
    [tbl_Billing Invoice Export Archive].[Employer Key] IN
    ([TBL_EMPLOYER CONTROL].[Employer Key Ben Admin], [TBL_EMPLOYER CONTROL].[EMPLOYER KEY])
    GROUP BY
    [tbl_Billing Invoice Export Archive].[Billing Period]
    , [tbl_Billing Invoice Export Archive].[Employer Name]
    , [tbl_Billing Invoice Export Archive].[Employer Key]
    , [tbl_Billing Invoice Export Archive].[Billing Code]
    , [tbl_Billing Invoice Export Archive].[Billing Description]
    , [tbl_Billing Invoice Export Archive].[Billing Unit Rate]
    , [tbl_Employer Control].process
    HAVING
    ((([tbl_Employer Control].process) = 1))
go

