CREATE PROCEDURE [dbo].[_process_4_1_clear_final_trn_tables_once] AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        BEGIN
            /*clear procedure cache - very important when debugging!*/
            DBCC FREEPROCCACHE
            
            TRUNCATE TABLE dbo.[tbl_Billing Invoice Export]
            TRUNCATE TABLE dbo.[tbl_Billing Invoice Export All QuickBooks]
            TRUNCATE TABLE dbo.[TBL_BACKUP REPORTING EXPORT TABLE]
            
            EXEC dbo.[qry_Truncate Billing Invoice Export All QuickBooks];
            EXEC dbo.[qry_Truncate tbl_Process Table ALL Backup];
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

