CREATE VIEW [dbo].[qry_Report Rate LPF]
    AS
        /* get FSA fields from EmplCtl records EXCEPT for billing group 'EMB'*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].process
          , [tbl_Employer Control].[QB Client Type]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[Employer Effective Date]
          , [tbl_Employer Control].[Employer Term Date]
          , [tbl_Employer Control].[BROKER CODE]
          , [tbl_Employer Control].[LPF_Account Type]
          , [tbl_Employer Control].[LPF_Plan Name]
          , [tbl_Employer Control].[LPF_BILLING CODE]
          , [tbl_Employer Control].[LPF_PEPM FLG]
          , [tbl_Employer Control].[LPF_PEPM AMOUNT]
          , [tbl_Employer Control].[LPF_MONTHLY MINIMUM FLG]
          , [tbl_Employer Control].[LPF_MONTHLY MINIMUM AMOUNT]
          , [tbl_Employer Control].[LPF_FLAT RATE FLG]
          , [tbl_Employer Control].[LPF_FLAT RATE AMOUNT]
          , [tbl_Employer Control].[LPF_PAID BY BROKER FLG]
          , [tbl_Employer Control].[LPF_PAID BY BROKER PERCENT]
          , [tbl_Employer Control].[LPF_PAID BY EMPLOYER FLG]
          , [tbl_Employer Control].[LPF_PAID BY EMPLOYER PERCENT]
        FROM
            [tbl_Employer Control]
        WHERE
            /* sumeet: EMBMERGE*/
            /*       ((([tbl_Employer Control].[Billing Group]) NOT LIKE '%EMB%'))  */
            [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN FLG] <> 1
go

