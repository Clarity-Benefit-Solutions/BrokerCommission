CREATE VIEW [dbo].[x_QuickBooks Pro Credit Memo Import]
    AS
        /* Liat all InvExp records for [Billing Code QB]) =
              'Alegeus ACH Error Credit') */
        SELECT
            [tbl_Billing Invoice Export All QuickBooks].[Employer Name]
          , [tbl_Billing Invoice Export All QuickBooks].[Employer Key]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Code QB]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Description]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Unit Count]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Unit Rate]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Amount]
          , [tbl_Billing Invoice Export All QuickBooks].[Invoice Number]
          , [tbl_Billing Invoice Export All QuickBooks].[Invoice Date]
          , [tbl_Billing Invoice Export All QuickBooks].[Invoice Due Date]
          , [tbl_Billing Invoice Export All QuickBooks].terms
          , [tbl_Billing Invoice Export All QuickBooks].[Customer Message]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Period]
          , [tbl_Billing Invoice Export All QuickBooks].[GL Receivable Account]
          , [tbl_Billing Invoice Export All QuickBooks].[GL Expense Account]
          , [tbl_Billing Invoice Export All QuickBooks].[To Email]
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
        WHERE
            ((([tbl_Billing Invoice Export All QuickBooks].[Billing Code QB]) = 'Alegeus ACH Error Credit'))
go

