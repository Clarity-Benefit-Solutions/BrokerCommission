CREATE VIEW [dbo].[qry_Report EDI_4 Debit Card Counts]
    AS
        /* count Employers, and sumof NewCards and Replacement Cards from DebitCard import table */
        SELECT
            COUNT( [tbl_Staging EDI_4 Debit Card Summery].[Employer Name] ) [CountOfEmployer Name]
          , SUM( [tbl_Staging EDI_4 Debit Card Summery].[New Card Count] ) [SumOfNew Card Count]
          , SUM( [tbl_Staging EDI_4 Debit Card Summery].[Replacement Card Count] ) [SumOfReplacement Card Count]
        FROM
            [tbl_Staging EDI_4 Debit Card Summery]
go

