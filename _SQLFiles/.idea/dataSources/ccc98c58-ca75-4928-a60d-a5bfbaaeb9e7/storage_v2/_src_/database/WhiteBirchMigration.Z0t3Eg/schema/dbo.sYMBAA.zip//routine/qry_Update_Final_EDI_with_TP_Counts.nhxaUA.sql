CREATE PROCEDURE dbo.[qry_Update Final EDI with TP Counts] AS

BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        -- ALTER PROCEDURE [qry_Update Final EDI with TP Counts] AS
        UPDATE [tbl_Final EDI Billing Group Counts]
        SET
            [TP Count] = [tbl_QB TP Count].[CountOfSSN]
        FROM
            [tbl_QB TP Count]
                INNER JOIN [tbl_Final EDI Billing Group Counts] ON [tbl_QB TP Count].[Alternate ER ID] =
                                                                   [tbl_Final EDI Billing Group Counts].[Alternate ER ID];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

