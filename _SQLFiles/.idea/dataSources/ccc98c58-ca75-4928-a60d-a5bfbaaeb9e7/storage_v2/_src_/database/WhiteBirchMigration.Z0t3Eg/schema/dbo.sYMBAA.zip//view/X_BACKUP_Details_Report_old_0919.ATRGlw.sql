CREATE VIEW [dbo].[X_BACKUP Details Report old 0919]
    AS
        /* Liat all backup process records */
        SELECT
            [tbl_Process Table All Backup].[Billing Group]
          , [tbl_Process Table All Backup].[Employer Key]
          , [tbl_Process Table All Backup].[Employer Name]
          , [tbl_Process Table All Backup].[Backup Invoice Number]
          , [tbl_Process Table All Backup].[BILLING CODE]
          , ([tbl_Process Table All Backup].[Plan Name]) [Billing Description]
          , [tbl_Process Table All Backup].division
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , [tbl_Process Table All Backup].[PEPM COUNT]
          , [tbl_Process Table All Backup].[PEPM AMOUNT]
        FROM
            [tbl_Process Table All Backup]
        GROUP BY
            [tbl_Process Table All Backup].[Billing Group]
          , [tbl_Process Table All Backup].[Employer Key]
          , [tbl_Process Table All Backup].[Employer Name]
          , [tbl_Process Table All Backup].[Backup Invoice Number]
          , [tbl_Process Table All Backup].[BILLING CODE]
          , ([tbl_Process Table All Backup].[Plan Name])
          , [tbl_Process Table All Backup].division
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , [tbl_Process Table All Backup].[PEPM COUNT]
          , [tbl_Process Table All Backup].[PEPM AMOUNT]
          , [tbl_Process Table All Backup].uniquekeyparticipant
        HAVING
            ((([tbl_Process Table All Backup].[Billing Group]) NOT LIKE '%Bundle%'))
go

