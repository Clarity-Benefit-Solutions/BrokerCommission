CREATE VIEW [dbo].[BillTrustXML_EMB]
    AS
        /* select BillTrustXML records for EMB */
        SELECT
            dbo.stripspchars( [c1] ) expr1
          , billtrust_autopayxml_emb.accountype
          , dbo.stripspchars( [c1] ) expr2
          , IIF( [account number] <> '0' AND [Account number] <> 'Check Client' AND [Account number] <> 'Unknown' ,
                 [bank name] , '' ) bankname
          , IIF( [account number] <> '0' AND [Account number] <> 'Check Client' AND [Account number] <> 'Unknown' ,
                 [routing number] , '' ) routingnumber
          , IIF( [account number] <> '0' AND [Account number] <> 'Check Client' AND [Account number] <> 'Unknown' ,
                 [account number] , '' ) accountnumber
          , billtrust_autopayxml_emb.autopay
          , billtrust_autopayxml_emb.autopaythresh
          , billtrust_autopayxml_emb.designatedpayment
          , billtrust_autopayxml_emb.acct_num
          , billtrust_autopayxml_emb.[Email 1]
          , billtrust_autopayxml_emb.sendpaper
          , billtrust_autopayxml_emb.emailnotify
          , billtrust_autopayxml_emb.emailconfirm
          , billtrust_autopayxml_emb.password
          , billtrust_autopayxml_emb.managedaccount
        FROM
            billtrust_autopayxml_emb
go

