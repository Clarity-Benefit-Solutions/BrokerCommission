CREATE VIEW [dbo].[qry_Report COBRA Client List Unmatched Employer Control]
    AS
        /* list CobraClients with no record in  EmplCtl by EmpKey */
        SELECT
            [tbl_Staging COBRA Client List].clientgroupname
          , [tbl_Staging COBRA Client List].clientalternate
          , [tbl_Staging COBRA Client List].clientname
          , [tbl_Staging COBRA Client List].billingstartdate
          , [tbl_Staging COBRA Client List].ein
          , [tbl_Staging COBRA Client List].clientdivisionname
          , [tbl_Staging COBRA Client List].clientid
          , [tbl_Staging COBRA Client List].clientdivisionid
          , [tbl_Staging COBRA Client List].active
          , [tbl_Staging COBRA Client List].deactivationdate
          , [tbl_Staging COBRA Client List].divisionname
          , [tbl_Employer Control].[Employer Key]
        FROM
            [tbl_Employer Control]
                RIGHT JOIN [tbl_Staging COBRA Client List] ON /*EMBMerge*/ /*[TBL_EMPLOYER CONTROL].[EMPLOYER KEY]*/
                    [tbl_Staging COBRA Client List].clientalternate IN
                    ([TBL_EMPLOYER CONTROL].[Employer Key Ben Admin], [TBL_EMPLOYER CONTROL].[EMPLOYER KEY])
            
            /*EMBMerge end*/
        WHERE
            ((([tbl_Employer Control].[Employer Key]) IS NULL))
go

