CREATE PROCEDURE dbo.[QRY_APPEND ALL INVOICE MONTHLY MIN TO ALL PROCESS TBL] AS
    /* inserts all InvExp rows matching '%Monthly Minimum Fee%' to ProcessBackup */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_PROCESS TABLE ALL BACKUP] (
                                                [BILLING GROUP],
                                                [EMPLOYER NAME],
                                                [EMPLOYER KEY],
                                                [SYSTEM EMPLOYER CODE],
                                                [BROKER CODE],
                                                [BROKER NAME],
                                                [BILLING CODE],
                                                [PLAN NAME],
                                                [PEPM COUNT],
                                                [PEPM AMOUNT],
                                                [PAID BY BROKER FLG],
                                                [KEY_MM MONTHLY MINIMUM],
                                                [EMPLOYER BILLING NUMBER]
        )
        SELECT
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING GROUP]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER NAME]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER KEY]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[SYSTEM EMPLOYER KEY]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BROKER CODE]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BROKER NAME]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING CODE]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING DESCRIPTION]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING UNIT COUNT]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING AMOUNT]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[PAID BY BROKER FLG]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[KEY_MM MONTHLY MINIMUM]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER BILLING NUMBER]
        FROM
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
        WHERE
            ((([TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING CODE QB]) LIKE '%Monthly Minimum Fee%'));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

