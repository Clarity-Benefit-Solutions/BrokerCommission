CREATE VIEW [qry_Count QB Detail]
    AS
        SELECT
            COUNT( [tbl_QBACADETAILREPORT Staging].ssn ) countofssn
        FROM
            [tbl_QBACADETAILREPORT Staging]
                INNER JOIN [tbl_Final EDI Billing Group Counts] ON [tbl_QBACADETAILREPORT Staging].[Alternate ER ID] =
                                                                   [tbl_Final EDI Billing Group Counts].[Alternate ER ID]
        WHERE
            ((([tbl_QBACADETAILREPORT Staging].status) = 'TP' OR
              ([tbl_QBACADETAILREPORT Staging].status) = 'TE'))
        GROUP BY
            [tbl_QBACADETAILREPORT Staging].[Alternate ER ID]
go

