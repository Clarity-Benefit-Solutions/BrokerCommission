CREATE TRIGGER dbo.[bu tbl_Employer Control]
    ON [tbl_Employer Control]
    AFTER UPDATE
    AS
BEGIN
    UPDATE [tbl_Employer Control]
    SET
        [Updated At] = GETDATE( )
    WHERE
            recordid IN (
                      SELECT DISTINCT
                          recordid
                      FROM
                          Inserted
                  );
END
go

