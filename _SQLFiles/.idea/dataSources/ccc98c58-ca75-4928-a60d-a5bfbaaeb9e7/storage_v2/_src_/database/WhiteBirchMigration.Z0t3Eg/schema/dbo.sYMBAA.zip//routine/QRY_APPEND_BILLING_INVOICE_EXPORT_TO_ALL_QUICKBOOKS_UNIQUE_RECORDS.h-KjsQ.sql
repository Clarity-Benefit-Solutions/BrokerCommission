CREATE PROCEDURE dbo.[QRY_APPEND BILLING INVOICE EXPORT TO ALL QUICKBOOKS UNIQUE RECORDS] AS
    /* inseerts all records into a temp table (TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS NON UNIQUE) , deletes all records, and inserts only unique records back into invexpqb*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        /*delete from temp*/
        TRUNCATE TABLE [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS NON UNIQUE];
        /*insert into temp */
        INSERT INTO [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS NON UNIQUE]
        SELECT *
        FROM
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS];
        
        /*delete from dest*/
        TRUNCATE TABLE [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS];
        /*insert unique only into dest from temp */
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS] (
                                                               [Billing Group]
                                                             , [Employer Name]
                                                             , [Employer Key]
                                                             , [System Employer Key]
                                                             , [Broker Code]
                                                             , [Broker Name]
                                                             , [Billing Code]
                                                             , [Billing Code QB]
                                                             , [Billing Description]
                                                             , [Billing Unit Count]
                                                             , [Billing Unit Rate]
                                                             , [Billing Amount]
                                                             , [Invoice Number]
                                                             , [Invoice Date]
                                                             , [Invoice Due Date]
                                                             , terms
                                                             , [Customer Message]
                                                             , [Billing Period]
                                                             , [Bill To]
                                                             , [PAID BY BROKER FLG]
                                                             , [KEY_MM Monthly Minimum]
                                                             , [Monthly Min Billing Flg]
                                                             , [Monthly Min To Delete]
                                                             , [Monthly Min Billing Amount]
                                                             , [Calculated Billing Amount]
                                                             , [Employer Billing Number]
                                                             , [GL Receivable Account]
                                                             , [GL Expense Account]
                                                             , [To Print]
                                                             , [To Email]
                                                             , [Original Employer Name]
                                                             , processed_group
                                                             , [Billing Group Process]
                                                             , RecordID
        )
        SELECT
            [Billing Group]
          , [Employer Name]
          , [Employer Key]
          , [System Employer Key]
          , [Broker Code]
          , [Broker Name]
          , [Billing Code]
          , [Billing Code QB]
          , [Billing Description]
          , [Billing Unit Count]
          , [Billing Unit Rate]
          , [Billing Amount]
          , [Invoice Number]
          , [Invoice Date]
          , [Invoice Due Date]
          , terms
          , [Customer Message]
          , [Billing Period]
          , [Bill To]
          , [PAID BY BROKER FLG]
          , [KEY_MM Monthly Minimum]
          , [Monthly Min Billing Flg]
          , [Monthly Min To Delete]
          , [Monthly Min Billing Amount]
          , [Calculated Billing Amount]
          , [Employer Billing Number]
          , [GL Receivable Account]
          , [GL Expense Account]
          , [To Print]
          , [To Email]
          , [Original Employer Name]
          , processed_group
          , [Billing Group Process]
          , RecordID
        
        FROM
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS NON UNIQUE]
        WHERE
            /* sumeet 2021-03-07 isnull is essential elzsxe it skips all nulls in [Billing Code QB] */
              ISNULL( [Billing Code QB] , '' ) <> 'Alegeus ACH Error Credit'
          AND dbo.isnotblank( [Invoice Number] ) = 1
            /*exclude some invalid calculations leading to duplicated line items*/
          AND [Billing Unit Count] <> 0
          AND [Billing Unit Rate] <> 0
          AND [Billing Amount] <> 0
            /* embmerge - remove duplicate line items*/
          AND rowid IN
              (
                  SELECT
                      MIN( rowid )
                  FROM
                      /* sumeet: 2021-09-26 ensure same item is not billed to BROKER and Employer 0- is happening for Setup fees for PPM and others*/ /* sumeet: 2021-09-26 ensure same item is not billed to BROKER and Employer 0- is happening for Setup fees for PPM and others*/
                      [qry_tbl_billing invoice export all quickbooks non unique 2] n
                      /* sumeet: 2021-09-26 END*/
                  WHERE
                      /* take only onw row for broker or employer billed service*/
                      n.RowNum = 1
                  GROUP BY
                      [Original Employer Name]
                    , [Billing Code]
                    , [Billing Unit Count]
                    , [Billing Unit Rate]
              )
        
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
        /* also make backup reporting export unique*/
        EXEC dbo.[QRY BACKUP REPORTING EXPORT UNIQUE RECORDS];
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END ;
go

