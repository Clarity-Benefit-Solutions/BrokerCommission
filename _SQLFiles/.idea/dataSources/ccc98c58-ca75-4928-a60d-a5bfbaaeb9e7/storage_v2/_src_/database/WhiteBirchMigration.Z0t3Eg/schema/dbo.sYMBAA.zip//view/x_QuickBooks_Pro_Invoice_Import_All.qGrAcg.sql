CREATE VIEW [dbo].[x_QuickBooks Pro Invoice Import All] AS
    /*  exclude all BillingCodeQB = 'Alegeus ACH Error Credit' */
    SELECT
        RecordID
      , [Billing Group Process]
      , PROCESSED_GROUP
      , [Employer Name]
      , [Employer Key]
      , [Billing Code QB]
      , [Billing Description]
      , [Billing Unit Count]
      , [Billing Unit Rate]
      , [Billing Amount]
      , [Invoice Number]
      , [Invoice Date]
      , [Invoice Due Date]
      , terms
      , [Customer Message]
      , [Billing Period]
      , [GL Receivable Account]
      , [GL Expense Account]
      , [To Email]
      , rowid
    FROM
        dbo.[tbl_Billing Invoice Export All QuickBooks]
    WHERE
          [Billing Unit Count] <> 0
      AND [Billing Unit Rate] <> 0
      AND [Billing Amount] <> 0
      AND ISNULL( ToDelete , 0 ) <> 1
go

