CREATE PROCEDURE dbo.[QRY_UPDATE BILLING INVOICE EXPORT WITH INVOICE DETAIL] AS
    /* update InvExp set BillingPeriod cols from  [TBL_INVOICE DATE TABLE] */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_BILLING INVOICE EXPORT]
        SET
            [TBL_BILLING INVOICE EXPORT].[INVOICE DATE]     = ([TBL_INVOICE DATE TABLE].[INVOICE DATE])
          , [TBL_BILLING INVOICE EXPORT].[INVOICE DUE DATE] = ([TBL_INVOICE DATE TABLE].[INVOICE DUE DATE])
          , [TBL_BILLING INVOICE EXPORT].[CUSTOMER MESSAGE] = ([TBL_INVOICE DATE TABLE].[INVOICE CUSTOMER MESSAGE])
          , [TBL_BILLING INVOICE EXPORT].terms              = ([TBL_INVOICE DATE TABLE].[INVOICE TERMS])
          , [TBL_BILLING INVOICE EXPORT].[BILLING PERIOD]   = ([TBL_INVOICE DATE TABLE].[BILLING PERIOD])
          , [TBL_BILLING INVOICE EXPORT].[TO PRINT]         = ([TBL_INVOICE DATE TABLE].[TO PRINT])
          , [TBL_BILLING INVOICE EXPORT].[TO EMAIL]         = ([TBL_INVOICE DATE TABLE].[TO EMAIL])
        FROM
            [TBL_INVOICE DATE TABLE];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

