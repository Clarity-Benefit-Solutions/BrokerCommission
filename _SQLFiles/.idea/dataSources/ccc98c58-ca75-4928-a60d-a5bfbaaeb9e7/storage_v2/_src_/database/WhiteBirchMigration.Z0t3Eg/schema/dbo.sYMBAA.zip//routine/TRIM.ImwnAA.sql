CREATE FUNCTION dbo.trim(
    @string nvarchar(max) ) RETURNS nvarchar(max) AS
    /* simulate missing Access fn */
    BEGIN
        RETURN LTRIM( RTRIM( @string ) )
    END
go

