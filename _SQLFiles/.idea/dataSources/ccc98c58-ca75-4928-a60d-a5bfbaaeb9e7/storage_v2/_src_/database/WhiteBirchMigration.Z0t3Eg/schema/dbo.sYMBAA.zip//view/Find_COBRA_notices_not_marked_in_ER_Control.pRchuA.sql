CREATE VIEW [dbo].[Find COBRA notices not marked in ER Control]
    AS
        /* join EmployerControl clients with imported CobraLetters on EmployerKey   */
        SELECT
            [tbl_Staging COBRA Letters Summary].clientcode
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[COBRA_NOTICE BILLING CODE]
          , [tbl_Employer Control].[COBRA_PER NOTICE FLG]
          , [tbl_Employer Control].[COBRA_PER NOTICE FLG AMOUNT]
        FROM
            [tbl_Staging COBRA Letters Summary]
                INNER JOIN [tbl_Employer Control]
                           ON [tbl_Staging COBRA Letters Summary].clientcode = [tbl_Employer Control].[Employer Key]
        GROUP BY
            [tbl_Staging COBRA Letters Summary].clientcode
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[COBRA_NOTICE BILLING CODE]
          , [tbl_Employer Control].[COBRA_PER NOTICE FLG]
          , [tbl_Employer Control].[COBRA_PER NOTICE FLG AMOUNT]
go

