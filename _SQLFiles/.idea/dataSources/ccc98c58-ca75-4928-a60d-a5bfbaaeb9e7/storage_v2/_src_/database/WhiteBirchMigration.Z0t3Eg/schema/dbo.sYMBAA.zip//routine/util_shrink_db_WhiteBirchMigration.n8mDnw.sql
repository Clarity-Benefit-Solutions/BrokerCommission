CREATE PROCEDURE util_shrink_db_whitebirchmigration AS
BEGIN
    ALTER DATABASE [WhiteBirchMigration] SET RECOVERY SIMPLE;
    CHECKPOINT;
    
    CHECKPOINT; -- run twice to ensure file wrap-around
    
    DBCC SHRINKFILE ('WhiteBirchMigration_log', 200); -- unit is set in MBs
    
    ALTER DATABASE [WhiteBirchMigration] SET RECOVERY FULL;

END
go

