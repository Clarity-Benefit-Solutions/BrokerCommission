CREATE PROCEDURE dbo.[QRY_UPDATE STAGING_EDI_5_FORMATTING PLANENDDATE DT] AS
    /* update Edi5PlanDocRpt set [Plan End Date dt] = parsed [Plan End Date]   */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT]
        SET
            [TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].[PLAN END DATE DT] =
                    SUBSTRING( [TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].[PLAN END DATE] , 5 , 2 ) + '/' +
                    RIGHT( [TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].[PLAN END DATE] , 2 ) + '/' +
                    LEFT( [TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].[PLAN END DATE] , 4 );
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

