CREATE FUNCTION dbo.cdate(
    @string nvarchar(100) ) RETURNS date AS
    /* simulate missing Access fn */
    BEGIN
        DECLARE @datestr nvarchar(200) = NULL;
        DECLARE @datevalue date = NULL;
        
        SET @datestr = SUBSTRING( @string , 5 , 2 ) + '/' + RIGHT( @string , 2 ) + '/' + LEFT( @string , 4 )
        
        SET @datevalue = ISNULL( TRY_CAST( @datestr AS date ) , NULL );
        
        RETURN @datevalue;
    END
go

