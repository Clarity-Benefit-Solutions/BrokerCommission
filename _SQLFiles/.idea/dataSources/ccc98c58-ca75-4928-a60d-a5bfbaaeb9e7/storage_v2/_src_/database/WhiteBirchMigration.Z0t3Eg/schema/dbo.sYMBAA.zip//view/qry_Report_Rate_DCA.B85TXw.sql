CREATE VIEW [dbo].[qry_Report Rate DCA]
    AS
        /* get DCA fields from EmplCtl records EXCEPT for billing group 'EMB''*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].process
          , [tbl_Employer Control].[QB Client Type]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[Employer Effective Date]
          , [tbl_Employer Control].[Employer Term Date]
          , [tbl_Employer Control].[BROKER CODE] /*,
       [tbl_Employer Control].[DCA_Account Type],
       [tbl_Employer Control].[DCA_Plan Name],
       [tbl_Employer Control].[DCA_BILLING CODE],
       [tbl_Employer Control].[DCA_PEPM FLG],
       [tbl_Employer Control].[DCA_PEPM AMOUNT],
       [tbl_Employer Control].[DCA_MONTHLY MINIMUM FLG],
       [tbl_Employer Control].[DCA_MONTHLY MINIMUM AMOUNT],
       [tbl_Employer Control].[DCA_FLAT RATE FLG],
       [tbl_Employer Control].[DCA_FLAT RATE AMOUNT],
       [tbl_Employer Control].[DCA_PAID BY BROKER FLG],
       [tbl_Employer Control].[DCA_PAID BY BROKER PERCENT],
       [tbl_Employer Control].[DCA_PAID BY EMPLOYER FLG],
       [tbl_Employer Control].[DCA_PAID BY EMPLOYER PERCENT]*/
        FROM
            [tbl_Employer Control]
        WHERE
            /* sumeet: EMBMERGE*/
            /*    ((([tbl_Employer Control].[Billing Group]) NOT LIKE '%EMB%'))*/
            [BEN_BEN ADMIN FLG] <> 1
go

