CREATE PROCEDURE dbo.[qry_Update Final EDI with Final Billible Counts Calc] AS

BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        -- ALTER PROCEDURE [qry_Update Final EDI with Final Billible Counts Calc] AS
        UPDATE [tbl_Final EDI Billing Group Counts]
        SET
            [tbl_Final EDI Billing Group Counts].[Final Billable Counts] = ISNULL(
                        ISNULL( [NPM Count] , 0 ) - ISNULL( [TE Count] , 0 ) - ISNULL( [TP Count] , 0 ) , 0 );
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

