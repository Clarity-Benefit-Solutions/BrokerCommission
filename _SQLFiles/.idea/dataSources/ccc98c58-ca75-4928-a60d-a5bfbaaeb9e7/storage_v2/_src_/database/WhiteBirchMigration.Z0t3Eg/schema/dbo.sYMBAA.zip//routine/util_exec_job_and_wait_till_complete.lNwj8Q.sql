CREATE PROCEDURE [dbo].[util_exec_job_and_wait_till_complete](
    @job_name nvarchar(500) ) AS
BEGIN
    BEGIN TRY
        
        -- Wait for job to finish
        DECLARE @job_history_id AS int = NULL
        DECLARE @stop_execution_date AS datetime2 = NULL
        DECLARE @step_id AS int = NULL
        DECLARE @lastrunstatus AS nvarchar(500) = NULL
        DECLARE @msg AS nvarchar(max) = NULL
        DECLARE @starttime datetime2 = GETDATE( );
        
        SET @msg = 'Starting Job: ' + @job_name + '';
        EXEC dbo.db_log_message 'util_exec_job_and_wait_till_complete' , @msg , 'INFO' , 0;
        
        /* execute the job*/
        EXEC msdb.dbo.sp_start_job @job_name = @job_name;
        
        /* loop indeifnitely */
        WHILE 1 = 1 BEGIN
            /* if we get an id, job has finished */
            SELECT TOP 1
                @job_history_id = job_history_id
              , @stop_execution_date = stop_execution_date
              , @step_id = step_id
              , @lastrunstatus = lastrunstatus
            FROM
                util_job_history
            WHERE
                  jobname = @job_name
              AND stop_execution_date > @starttime
            ORDER BY
                [JobName]
              , stop_execution_date DESC;
            
            /* inform job is running*/
            IF @job_history_id IS NULL
                BEGIN
                    SET @msg = 'Waiting: Job: ' + @job_name + ' is still running. Waiting 10 secs';
                    EXEC dbo.db_log_message 'util_exec_job_and_wait_till_complete' , @msg , 'INFO' , 0;
                    --
                    WAITFOR DELAY '00:00:10'
                    CONTINUE
                END
            ELSE
                BEGIN
                    IF @lastrunstatus = 'Succeeded'
                        BEGIN
                            SET @msg = 'FINISHED: Job: ' + @job_name + ' job_history_id ' +
                                       CAST( @job_history_id AS varchar(200) );
                            EXEC dbo.db_log_message 'util_exec_job_and_wait_till_complete' , @msg , 'INFO' , 0;
                        END
                    ELSE
                        BEGIN
                            EXEC dbo.db_throw_error 50001 , @job_name ,
                                 'Job Failed Or Cancelled. Please check the logs for details'
                        END
                    BREAK
                END
        END
        -- Check exit code
        SELECT
                @msg = 'FINISHED. Job: ' + @job_name + ' Time taken: ' +
                       CAST( DATEDIFF( SECOND , @starttime , GETDATE( ) ) AS nvarchar ) + ' secs. Exit Code: ' +
                       CAST( history.run_status AS nvarchar )
        FROM
            msdb.dbo.sysjobhistory history
        WHERE
            history.instance_id = @job_history_id
        --
        EXEC dbo.db_log_message 'util_exec_job_and_wait_till_complete' , @msg , 'WARN' , 0;
    
    END TRY BEGIN CATCH
        DECLARE @errno varchar(500) = ERROR_NUMBER( )
        DECLARE @errmsg varchar(2000) = ERROR_MESSAGE( )
        DECLARE @errstate varchar(200) = ERROR_STATE( )
        
        EXEC dbo.db_throw_error @errno , @job_name , @errmsg;
    
    END CATCH
END
go

