CREATE PROCEDURE dbo.[qry_Update Employer Ctl Fix NONBEN_NONBEN ADMIN BILLING CODE] AS

BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        /* if dbo.[UPDATEITEMLINE] was run multiple times, fix NONBEN_NONBEN ADMIN BILLING CODE */
        UPDATE [TBL_EMPLOYER CONTROL]
        SET
            [TBL_EMPLOYER CONTROL].[NONBEN_NONBEN ADMIN BILLING CODE] = REPLACE( [NONBEN_NONBEN ADMIN BILLING CODE] ,
                                                                                 'Web Benefits' , 'Web Benefit' )
        WHERE
            ((([TBL_EMPLOYER CONTROL].[EMPLOYER NAME]) LIKE '%DIOCESE OF TRENTON%'));
        UPDATE [TBL_EMPLOYER CONTROL]
        SET
            [TBL_EMPLOYER CONTROL].[NONBEN_NONBEN ADMIN BILLING CODE] = REPLACE( [NONBEN_NONBEN ADMIN BILLING CODE] ,
                                                                                 'Web Benefit NBEs' , 'Web Benefit' )
        WHERE
            ((([TBL_EMPLOYER CONTROL].[EMPLOYER NAME]) LIKE '%DIOCESE OF TRENTON%'));
        UPDATE [TBL_EMPLOYER CONTROL]
        SET
            [TBL_EMPLOYER CONTROL].[NONBEN_NONBEN ADMIN BILLING CODE] = REPLACE( [NONBEN_NONBEN ADMIN BILLING CODE] ,
                                                                                 'Web Benefit NBEs' , 'Web Benefit' )
        WHERE
            ((([TBL_EMPLOYER CONTROL].[EMPLOYER NAME]) LIKE '%DIOCESE OF TRENTON%'));
        UPDATE [TBL_EMPLOYER CONTROL]
        SET
            [TBL_EMPLOYER CONTROL].[NONBEN_NONBEN ADMIN BILLING CODE] = REPLACE( [NONBEN_NONBEN ADMIN BILLING CODE] ,
                                                                                 'Web Benefit NBE' , 'Web Benefit' )
        WHERE
            ((([TBL_EMPLOYER CONTROL].[EMPLOYER NAME]) LIKE '%DIOCESE OF TRENTON%'));
        UPDATE [TBL_EMPLOYER CONTROL]
        SET
            [TBL_EMPLOYER CONTROL].[NONBEN_NONBEN ADMIN BILLING CODE] = REPLACE( [NONBEN_NONBEN ADMIN BILLING CODE] ,
                                                                                 'Web Benefit NBE' , 'Web Benefit' )
        WHERE
            ((([TBL_EMPLOYER CONTROL].[EMPLOYER NAME]) LIKE '%DIOCESE OF TRENTON%'));
        UPDATE [TBL_EMPLOYER CONTROL]
        SET
            [TBL_EMPLOYER CONTROL].[NONBEN_NONBEN ADMIN BILLING CODE] = REPLACE( [NONBEN_NONBEN ADMIN BILLING CODE] ,
                                                                                 'Web Benefits' , 'Web Benefit' )
        WHERE
            ((([TBL_EMPLOYER CONTROL].[EMPLOYER NAME]) LIKE '%DIOCESE OF TRENTON%'));
        
        /* fix [NONBEN_NONBEN ADMIN BILLING CODE] code only for DIOCESE OF TRENTON*/
        UPDATE [TBL_EMPLOYER CONTROL]
        SET
            [TBL_EMPLOYER CONTROL].[NONBEN_NONBEN ADMIN BILLING CODE] = REPLACE( [NONBEN_NONBEN ADMIN BILLING CODE] ,
                                                                                 'Web Benefit' , 'Web Benefits NBE' )
          , [TBL_EMPLOYER CONTROL].[NONBEN_NONBEN ADMIN PEPM AMOUNT]  = 0.75
        WHERE
            ((([TBL_EMPLOYER CONTROL].[EMPLOYER NAME]) LIKE '%DIOCESE OF TRENTON%'));
        
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

