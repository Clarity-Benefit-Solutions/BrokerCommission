CREATE PROCEDURE dbo.[ADD PCORIFEE LINES] AS
    /* invalid : pcorifees table is missing !!!*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS] (
                                                             [BILLING GROUP],
                                                             [EMPLOYER NAME],
                                                             [EMPLOYER KEY],
                                                             [SYSTEM EMPLOYER KEY],
                                                             [BROKER CODE],
                                                             [BROKER NAME],
                                                             [BILLING CODE],
                                                             [BILLING CODE QB],
                                                             [BILLING DESCRIPTION],
                                                             [BILLING UNIT COUNT],
                                                             [BILLING UNIT RATE],
                                                             [BILLING AMOUNT],
                                                             [INVOICE NUMBER],
                                                             [INVOICE DATE],
                                                             [INVOICE DUE DATE],
                                                             terms,
                                                             [CUSTOMER MESSAGE],
                                                             [BILLING PERIOD],
                                                             [BILL TO],
                                                             [PAID BY BROKER FLG],
                                                             [KEY_MM MONTHLY MINIMUM],
                                                             [MONTHLY MIN BILLING FLG],
                                                             [MONTHLY MIN BILLING AMOUNT],
                                                             [CALCULATED BILLING AMOUNT],
                                                             [EMPLOYER BILLING NUMBER],
                                                             [GL RECEIVABLE ACCOUNT],
                                                             [GL EXPENSE ACCOUNT],
                                                             [TO PRINT],
                                                             [TO EMAIL]
        )
        SELECT DISTINCT
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING GROUP]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER NAME]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER KEY]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[SYSTEM EMPLOYER KEY]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BROKER CODE]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BROKER NAME]
          , pcorifees.lineitem [BILLING CODE]
          , pcorifees.lineitem [BILLING CODE QB]
          , pcorifees.lineitem [BILLING DESCRIPTION]
          , 1 [BILLING UNIT COUNT]
          , 150 [BILLING UNIT AMOUNT]
          , pcorifees.amount [BILLING AMOUNT]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[INVOICE NUMBER]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[INVOICE DATE]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[INVOICE DUE DATE]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].terms
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[CUSTOMER MESSAGE]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING PERIOD]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILL TO]
          , '' [PAID BY BROKER FLG]
          , '' [KEY_MM MONTHLY MINIMUM]
          , '' [MONTHLY MIN BILLING FLG]
          , '' [MONTHLY MIN BILLING AMOUNT]
          , pcorifees.amount [CALCULATED BILLING AMOUNT]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER BILLING NUMBER]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[GL RECEIVABLE ACCOUNT]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[GL EXPENSE ACCOUNT]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[TO PRINT]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[TO EMAIL]
        FROM
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
                INNER JOIN pcorifees ON [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER KEY] = pcorifees.bencode;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

