CREATE VIEW [dbo].[Delete Broker Not Used Not Fixed for EMB]
    AS
        /*  delete all exports for billinggroupprocess 'broker' where billinggroup is not 'EMB'  */
        
        SELECT
            [tbl_Billing Invoice Export All QuickBooks].*
        FROM
            processtype
                INNER JOIN [tbl_Billing Invoice Export All QuickBooks]
                           ON processtype.[Employer Name] = [tbl_Billing Invoice Export All QuickBooks].[Employer Name]
        WHERE
            (((processtype.[Billing Group Process]) = 'broker') AND /* sumeet: EMBMERGE*/
            /*   [BILLING GROUP]) NOT LIKE  '%EMB%' */ processed_group NOT LIKE '%BEN ADMIN%'
                /* sumeet END*/
                )
go

