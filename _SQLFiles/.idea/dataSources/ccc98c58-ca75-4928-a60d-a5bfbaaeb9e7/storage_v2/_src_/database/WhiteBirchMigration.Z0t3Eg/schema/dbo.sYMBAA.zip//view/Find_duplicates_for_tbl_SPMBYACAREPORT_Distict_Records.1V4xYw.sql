CREATE VIEW [	Find duplicates for tbl_SPMBYACAREPORT Distict Records	]
    AS
        SELECT
            [tbl_SPMBYACAREPORT Distict Records].[UniqueKey]
          , [tbl_SPMBYACAREPORT Distict Records].[ClientAlternate]
          , [tbl_SPMBYACAREPORT Distict Records].[ClientName]
          , [tbl_SPMBYACAREPORT Distict Records].[First Name]
          , [tbl_SPMBYACAREPORT Distict Records].[Last Name]
          , [tbl_SPMBYACAREPORT Distict Records].[Account Type]
          , [tbl_SPMBYACAREPORT Distict Records].[MemberID]
        FROM
            [tbl_SPMBYACAREPORT Distict Records]
        WHERE
            ((([tbl_SPMBYACAREPORT Distict Records].[UniqueKey]) IN
              (
                  SELECT
                      [UniqueKey]
                  FROM
                      [tbl_SPMBYACAREPORT Distict Records] AS tmp
                  GROUP BY
                      [UniqueKey]
                  HAVING
                      COUNT( * ) > 1
              )))
go

