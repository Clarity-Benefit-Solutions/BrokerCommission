CREATE
    PROCEDURE [dbo].[_imp_cp_clients_from_portal] AS
BEGIN
    DECLARE @msg1 nvarchar(max)
    
    IF OBJECT_ID( 'dbo.cp_clients' , 'U' ) IS NOT NULL
        DROP TABLE dbo.cp_clients;
    
    SELECT *
    INTO dbo.cp_clients
    FROM
        cobrapoint_portal_prod.dbo.client;
    
    -- COMMIT;
    DECLARE @rows varchar(10);
    SELECT
        @rows = COUNT( * )
    FROM
        dbo.cp_clients;
    
    SET @msg1 = CONCAT( '**LOG** ' , 'imp_cp_clients_from_portal' , ' FINISHED INSERTED ' + @rows + ' ROWS' );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT

END;
go

