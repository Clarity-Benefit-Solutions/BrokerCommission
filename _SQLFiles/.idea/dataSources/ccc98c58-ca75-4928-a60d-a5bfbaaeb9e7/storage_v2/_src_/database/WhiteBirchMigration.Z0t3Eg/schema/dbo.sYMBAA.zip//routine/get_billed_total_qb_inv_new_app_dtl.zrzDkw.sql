CREATE FUNCTION get_billed_total_qb_inv_new_app_dtl(
                                                   @OrgEmployerName nvarchar(255),
                                                   @EmployerName nvarchar(255),
                                                   @BillingCodeQB nvarchar(255) ) RETURNS money
BEGIN
    DECLARE @ret money;
    SELECT
        @ret = SUM( t.[Billing Amount] )
    FROM
        dbo.[tbl_Billing Invoice Export All QuickBooks] t
    WHERE
          t.[Original Employer Name] LIKE @OrgEmployerName
      AND t.[Employer Name] LIKE @EmployerName
      AND t.[Billing Code QB] LIKE @BillingCodeQB
      AND ISNULL( t.ToDelete , 0 ) <> 1
    
    IF @ret IS NULL
        BEGIN
            SET @ret = 0
        END
    
    RETURN @ret
END
go

