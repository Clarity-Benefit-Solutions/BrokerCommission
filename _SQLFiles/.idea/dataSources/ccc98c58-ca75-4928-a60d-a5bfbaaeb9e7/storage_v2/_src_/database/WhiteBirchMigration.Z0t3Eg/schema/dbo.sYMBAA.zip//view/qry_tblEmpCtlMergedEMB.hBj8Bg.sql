CREATE VIEW qry_tblempctlmergedemb
    AS
        SELECT
            CONCAT( CASE
                        WHEN dbo.isnotblank( tec.[Employer Key Ben Admin] ) = 1
                            THEN [Employer Key Ben Admin]
                        ELSE [Employer Key]
                    END , '' ) mergedempkey
          , CONCAT( CASE
                        WHEN dbo.isnotblank( tec.[Employer Key Ben Admin] ) = 1
                            THEN [Employer Key Ben Admin]
                        ELSE [Employer Key]
                    END , '--' , [Employer Name] ) mergedempnameandkey
          , [Employer Key]
          , tec.[Employer Key Ben Admin]
          , tec.notes
          , [BEN_BEN PLAN ID]
          , [Employer Name]
          , tec.recordid
          , tec.[Billing Group]
          , tec.[Billing Group Process]
          , tec.[BEN_BEN ADMIN FLG]
          , tec.[BEN_BEN ADMIN BILLING CODE]
          , tec.[BEN_BEN ADMIN PEPM AMOUNT]
          , tec.[BEN_BEN ADMIN_PAID BY BROKER FLG]
          , tec.[BEN_BEN ADMIN_KEY MONTHLY MINIMUM]
          , tec.[BEN_BEN ADMIN_MONTHLY MINIMUM FLG]
          , tec.[BASE_FEE FLG]
          , tec.[BEN_BEN ADMIN_MONTHLY MINIMUM AMOUNT]
          , tec.[NONBEN_NONBEN ADMIN FLG]
          , tec.[NONBEN_NONBEN ADMIN BILLING CODE]
          , tec.[NONBEN_NONBEN ADMIN PEPM AMOUNT]
          , tec.[NONBEN_NONBEN_PAID BY BROKER FLG]
        FROM
            [TBL_EMPLOYER CONTROL] tec
        WHERE
            dbo.isnotblank( tec.[Billing Group Process] ) = 1
go

