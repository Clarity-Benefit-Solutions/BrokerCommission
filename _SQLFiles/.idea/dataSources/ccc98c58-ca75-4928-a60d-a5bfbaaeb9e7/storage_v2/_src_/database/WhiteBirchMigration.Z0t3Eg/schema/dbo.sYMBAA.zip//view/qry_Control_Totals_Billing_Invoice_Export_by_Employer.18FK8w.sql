CREATE VIEW [dbo].[qry_Control Totals Billing Invoice Export by Employer]
    AS
        /* sum invoice  [Billing Amount] by ClientName */
        SELECT
            [tbl_Billing Invoice Export].[Employer Name]
          , SUM( [tbl_Billing Invoice Export].[Billing Amount] ) [SumOfBilling Amount]
        FROM
            [tbl_Billing Invoice Export]
        GROUP BY
            [tbl_Billing Invoice Export].[Employer Name]
go

