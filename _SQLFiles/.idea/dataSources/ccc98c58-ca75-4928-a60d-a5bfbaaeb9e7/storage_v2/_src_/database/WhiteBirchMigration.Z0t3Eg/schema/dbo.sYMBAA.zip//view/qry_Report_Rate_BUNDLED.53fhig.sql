CREATE VIEW [dbo].[qry_Report Rate BUNDLED]
    AS
        /* get bundle fields from EmplCtl records for billing group 'EMB''*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].process
          , [tbl_Employer Control].[QB Client Type]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[Employer Effective Date]
          , [tbl_Employer Control].[Employer Term Date]
          , [tbl_Employer Control].[BROKER CODE]
          , [tbl_Employer Control].[BND_Plan Name]
          , [tbl_Employer Control].[BND_BILLING CODE]
          , [tbl_Employer Control].[BND_BUNDLE BILL FLG]
          , [tbl_Employer Control].[BND_BUNDLE RATE AMOUNT]
          , [tbl_Employer Control].[BND_PAID BY BROKER FLG]
          , [tbl_Employer Control].[BND_PAID BY BROKER PERCENT]
          , [tbl_Employer Control].[BND_PAID BY EMPLOYER FLG]
          , [tbl_Employer Control].[BND_PAID BY EMPLOYER PERCENT]
        FROM
            [tbl_Employer Control]
        WHERE
            (((
                /* sumeet: EMBMERGE*/
                /*   [BILLING GROUP]) NOT LIKE  '%EMB%' */
                [BEN_BEN ADMIN FLG] <> 1
                /* sumeet END*/
                )))
go

