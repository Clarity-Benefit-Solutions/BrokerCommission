CREATE VIEW [dbo].[BILLING_Clarity_ALEGEUS_ClientsNotinCurrentEC]
    AS
        SELECT DISTINCT
            [Clarity_BillableClientsfromECPreviouswNameTBL].[Billing Group]
          , [Clarity_BillableClientsfromECPreviouswNameTBL].[Billable Account]
          , IIF(
                    [Clarity_BillableClientsfromECpreviouswNameTBL].[employer Name] IS NULL ,
                    'Not found in WB' ,
                    [Clarity_BillableClientsfromECpreviouswNameTBL].[employer Name] ) emp_name
          , [Clarity_BillableClientsfromECPreviouswNameTBL].[BENCODE]
          , [Clarity_BillableClientsfromECPreviouswNameTBL].[Notes]
          , 'In Previous EC not in Current EC' fallouttype
        FROM
            [Clarity_BillableClientsfromECwNameTBL]
                RIGHT JOIN [Clarity_BillableClientsfromECPreviouswNameTBL]
                           ON [Clarity_BillableClientsfromECwNameTBL].[Employer Name] =
                              [Clarity_BillableClientsfromECPreviouswNameTBL].[Employer Name]
        WHERE
            ((([Clarity_BillableClientsfromECwNameTBL].[Employer Name]) IS NULL))
go

exec sp_addextendedproperty 'MS_SSMA_SOURCE' , N'ClarityAuditSystemv4.[BILLING_Clarity_ALEGEUS_ClientsNotinCurrentEC]' ,
     'SCHEMA' , 'dbo' , 'VIEW' , 'BILLING_Clarity_ALEGEUS_ClientsNotinCurrentEC'
go

