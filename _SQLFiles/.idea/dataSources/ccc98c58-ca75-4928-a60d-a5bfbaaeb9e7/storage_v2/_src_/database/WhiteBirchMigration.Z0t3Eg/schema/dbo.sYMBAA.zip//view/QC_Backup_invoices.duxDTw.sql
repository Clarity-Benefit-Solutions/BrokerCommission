CREATE VIEW [dbo].[QC_Backup_invoices]
    AS
        /* list distinct backup invoices   */
        
        SELECT DISTINCT
            [tbl_Backup Reporting Export Table].[Employer Name]
          , [tbl_Backup Reporting Export Table].[Employer Key]
          , [tbl_Backup Reporting Export Table].[Backup Invoice Number]
        FROM
            [tbl_Backup Reporting Export Table]
go

