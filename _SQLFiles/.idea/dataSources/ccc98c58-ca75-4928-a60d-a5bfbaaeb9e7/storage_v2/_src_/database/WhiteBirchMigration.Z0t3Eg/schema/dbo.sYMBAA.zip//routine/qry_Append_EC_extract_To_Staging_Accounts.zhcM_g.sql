CREATE PROCEDURE dbo.[QRY_APPEND EC EXTRACT TO STAGING ACCOUNTS] AS
    /* inserts all billable EC Import Rows into StagingAccts*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_STAGING ACCOUNTS] (
                                        [EMPLOYER CODE],
                                        [EC ACCOUNT TYPE],
                                        [PLAN NAME],
                                        [PARTICIPANT SSN],
                                        [EMPLOYEE NUMBER],
                                        [PLAN START DATE TXT],
                                        [PLAN END DATE TXT],
                                        [EFFECTIVE DATE TXT],
                                        [TERMINATION DATE TXT],
                                        [ACCOUNT STATUS],
                                        [PARTICIPANT STATUS],
                                        [PARTICIPANT FIRST NAME],
                                        [PARTICIPANT LAST NAME],
                                        [PARTICIPANT ANNUAL ELECTION],
                                        [PARTICIPANT PAY PERIOD ELECTION],
                                        [EMPLOYER ANNUAL ELECTION],
                                        [EMPLOYER PAY PERIOD ELECTION],
                                        productpartnerstatus
        )
        SELECT
            [EMPLOYER ID]
          , [ACCOUNT TYPE CODE]
          , [PLAN ID]
          , [EMPLOYEE SOCIAL SECURITY NUMBER]
          , [EMPLOYEE ID]
          , [PLAN START DATE]
          , [PLAN END DATE]
          , [EFFECTIVE DATE]
          , [TERMINATION DATE]
          , [ACCOUNT STATUS]
          , [EMPLOYEE STATUS]
          , [EMPLOYEE FIRST NAME]
          , [EMPLOYEE LAST NAME]
            --     , ([CURRENT ANNUAL ELECTION])
          , dbo.cmoney( [CURRENT ANNUAL ELECTION] )
            --     ,( [EMPLOYEE PAY PERIOD ELECTION])
          , dbo.cmoney( [EMPLOYEE PAY PERIOD ELECTION] )
            --     ,( [EMPLOYER ANNUAL ELECTION])
          , dbo.cmoney( [EMPLOYER ANNUAL ELECTION] )
            --     ,( [EMPLOYER PAY PERIOD ELECTION])
          , dbo.cmoney( [EMPLOYER PAY PERIOD ELECTION] )
          , productpartneracctstatus
        FROM
            [TBL_STAGING EC EXTRACT]
        WHERE
              dbo.TRIM( [BILLABLE ACCOUNT] ) = 'billable'
          AND dbo.isblank( [Dependent ID] ) = 1
            
            /* sumeet - hardcoded 2021-09-16 to exclude TP3-FIELDSTAFF */
              --         and [Employer Id]  in ('BENNOMURA', 'BENCPRONY')
          AND NOT (ISNULL( [Account Type Code] , '' ) = 'TP3' AND ISNULL( [Plan Id] , '' ) = 'FIELDSTAFF')
        /* sumeet end*/
        ;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

