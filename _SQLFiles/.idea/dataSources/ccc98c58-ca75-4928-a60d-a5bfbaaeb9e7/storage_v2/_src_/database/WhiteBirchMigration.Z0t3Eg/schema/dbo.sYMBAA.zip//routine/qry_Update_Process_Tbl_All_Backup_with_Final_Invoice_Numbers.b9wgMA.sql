CREATE PROCEDURE dbo.[QRY_UPDATE PROCESS TBL ALL BACKUP WITH FINAL INVOICE NUMBERS] AS
    /* update ProcessBackup.[Backup Invoice Number] = InvExpQB.[Invoice Number] where [System Employer Code] is empty  */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        /* 2022-03-22 the previous query is missing out updating some lines if either tables biolliong group is null*/
        
        /*   UPDATE [TBL_PROCESS TABLE ALL BACKUP]
           SET
               [TBL_PROCESS TABLE ALL BACKUP].[BACKUP INVOICE NUMBER] = [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[INVOICE NUMBER]
           FROM
               [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
                   INNER JOIN [TBL_PROCESS TABLE ALL BACKUP]
                              ON ([TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING GROUP] =
                                  [TBL_PROCESS TABLE ALL BACKUP].[BILLING GROUP]) AND
                                 ([TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER KEY] =
                                  [TBL_PROCESS TABLE ALL BACKUP].[EMPLOYER KEY])
           WHERE
               ((dbo.isblank( [TBL_PROCESS TABLE ALL BACKUP].[SYSTEM EMPLOYER CODE] ) = 1));*/
        
        UPDATE [TBL_PROCESS TABLE ALL BACKUP]
        SET
            [TBL_PROCESS TABLE ALL BACKUP].[BACKUP INVOICE NUMBER] = (
                                                                         SELECT TOP 1
                                                                             [Invoice Number]
                                                                         FROM
                                                                             [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS] q
                                                                         WHERE
                                                                             q.[Employer Key] = [TBL_PROCESS TABLE ALL BACKUP].[Employer Key]
                                                                     );
        
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

