CREATE VIEW [qry_Audit Invalid Emp Ctl NONBEN ADMIN BILLING CODE]
    AS
        SELECT
            [Employer Key]
          , [Employer Name]
          , [NONBEN_NONBEN ADMIN BILLING CODE]
          , [tbl_Account Type Billing Codes].[Billing Code]
        FROM
            [TBL_EMPLOYER CONTROL]
                LEFT JOIN [tbl_Account Type Billing Codes]
                          ON [tbl_Employer Control].[NONBEN_NONBEN ADMIN BILLING CODE] =
                             [tbl_Account Type Billing Codes].[Billing Code]
        WHERE
              [NONBEN_NONBEN ADMIN BILLING CODE] IS NOT NULL
          AND [Billing Code] IS NULL
go

