CREATE procedure testRateAmount as
BEGIN
    DECLARE @rate money;
    EXEC dbo.rate_increase_get_rate 3313 , '[BASE_FEE Amount]' , 'OLD' , @rate;
    SELECT
        @rate;
END;
    
    exec testRateAmount;

SELECT
    dbo.rate_increase_calc_new_rate( 'a' , 'b' );
SELECT
    dbo.rate_increase_calc_new_rate( '0' , '0' );
SELECT
    dbo.rate_increase_calc_new_rate( '100.50' , '0' );
SELECT
    dbo.rate_increase_calc_new_rate( '100' , '5.11512121' );
SELECT
    dbo.rate_increase_calc_new_rate( '100' , '-5' );
SELECT
    dbo.rate_increase_calc_new_rate( '100' , '100' );
go

