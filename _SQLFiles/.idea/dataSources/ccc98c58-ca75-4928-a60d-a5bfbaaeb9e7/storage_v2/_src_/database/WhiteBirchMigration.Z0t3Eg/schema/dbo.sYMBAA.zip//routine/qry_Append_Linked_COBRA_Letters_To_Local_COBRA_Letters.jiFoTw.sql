CREATE PROCEDURE dbo.[QRY_APPEND LINKED COBRA LETTERS TO LOCAL COBRA LETTERS] AS
    /* inserts all [TBL_COBRA LETTERS] records into  [TBL_STAGING COBRA LETTERS SUMMARY]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_STAGING COBRA LETTERS SUMMARY] (
                                                     clientname,
                                                     divisionname,
                                                     modeorder,
                                                     modename,
                                                     description,
                                                     qty
        )
        SELECT
            [TBL_COBRA LETTERS].clientname
          , [TBL_COBRA LETTERS].divisionname
          , [TBL_COBRA LETTERS].modeorder
          , [TBL_COBRA LETTERS].modename
          , [TBL_COBRA LETTERS].description
          , [TBL_COBRA LETTERS].qty
        FROM
            [TBL_COBRA LETTERS];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

