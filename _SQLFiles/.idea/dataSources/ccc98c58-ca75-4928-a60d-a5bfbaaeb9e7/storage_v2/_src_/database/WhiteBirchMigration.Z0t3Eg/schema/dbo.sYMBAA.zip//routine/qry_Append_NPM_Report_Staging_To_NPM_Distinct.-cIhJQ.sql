CREATE PROCEDURE dbo.[qry_Append NPM Report Staging To NPM Distinct] AS

BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        -- ALTER PROCEDURE [qry_Append NPM Report Staging To NPM Distinct] AS
        INSERT
            INTO [tbl_NPM Report Distinct] (
                                           clientname,
                                           include,
                                           fullname,
                                           ssn,
                                           type,
                                           [Is Paylocity],
                                           [Alternate ER ID],
                                           [NPM UniqueKey]
        )
        SELECT
            [tbl_NPM Report Staging].clientname
          , [tbl_NPM Report Staging].include
          , [tbl_NPM Report Staging].fullname
          , [tbl_NPM Report Staging].ssn
          , [tbl_NPM Report Staging].type
          , [tbl_NPM Report Staging].[Is Paylocity]
          , [tbl_NPM Report Staging].[Alternate ER ID]
          , ([tbl_NPM Report Staging].[Alternate ER ID] + [tbl_NPM Report Staging].[SSN] +
             [tbl_NPM Report Staging].[FullName]) [NPM UniqueKey]
        FROM
            [tbl_NPM Report Staging]
        GROUP BY
            [tbl_NPM Report Staging].clientname
          , [tbl_NPM Report Staging].include
          , [tbl_NPM Report Staging].fullname
          , [tbl_NPM Report Staging].ssn
          , [tbl_NPM Report Staging].type
          , [tbl_NPM Report Staging].[Is Paylocity]
          , [tbl_NPM Report Staging].[Alternate ER ID]
          , ([tbl_NPM Report Staging].[Alternate ER ID] + [tbl_NPM Report Staging].[SSN] +
             [tbl_NPM Report Staging].[FullName]);;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

