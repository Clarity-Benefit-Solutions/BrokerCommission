CREATE VIEW [dbo].[FIND DUPLICATES FOR TBL_EMPLOYER CONTROL]
    AS
        /*  select distinct records from EmployerControl  */
        SELECT DISTINCT
            [BILLING GROUP PROCESS]
          , [EMPLOYER KEY]
          , [EMPLOYER BILLING NUMBER]
          , [SYSTEM EMPLOYER CODE]
          , [EMPLOYER STATUS]
          , [EMPLOYER EFFECTIVE DATE]
          , [EMPLOYER TERM DATE]
            -- [True Employer Term Date],
          , [BROKER CODE]
          , [BASE_FEE BILLING CODE]
          , [BASE_FEE FLG]
          , [BASE_FEE AMOUNT]
          , [BASE_PAID BY BROKER FLG]
          , [BASE_PAID BY BROKER PERCENT]
          , [BASE_PAID BY EMPLOYER FLG]
          , [BASE_PAID BY EMPLOYER PERCENT]
          , [COBRA BASE_FEE BILLING CODE]
          , [COBRA BASE_FEE FLG]
          , [COBRA BASE_FEE AMOUNT]
          , [COBRA BASE_PAID BY BROKER FLG]
          , [COBRA BASE_PAID BY BROKER PERCENT]
          , [COBRA BASE_PAID BY EMPLOYER FLG]
          , [COBRA BASE_PAID BY EMPLOYER PERCENT]
          ,
            /*    [DCA_Account Type],
           [DCA_Plan Name],
           [DCA_BILLING CODE],
           [DCA_PEPM FLG],
           [DCA_PEPM AMOUNT],
           [DCA_MONTHLY MINIMUM FLG],
           [DCA_MONTHLY MINIMUM AMOUNT],
           [DCA_FLAT RATE FLG],
           [DCA_FLAT RATE AMOUNT],
           [DCA_PAID BY BROKER FLG],
           [DCA_PAID BY BROKER PERCENT],
           [DCA_PAID BY EMPLOYER FLG],
           [DCA_PAID BY EMPLOYER PERCENT],*/
            [FSA_ACCOUNT TYPE]
          , [FSA_PLAN NAME]
          , [FSA_BILLING CODE]
          , [FSA_PEPM FLG]
          , [FSA_PEPM AMOUNT]
          , [KEY_MMFSA MONTHLY MINUMUM]
          , [FSA_MONTHLY MINIMUM FLG]
          , [FSA_MONTHLY MINIMUM AMOUNT]
          , [FSA_FLAT RATE FLG]
          , [FSA_FLAT RATE AMOUNT]
          , [FSA_PAID BY BROKER FLG]
          , [FSA_PAID BY BROKER PERCENT]
          , [FSA_PAID BY EMPLOYER FLG]
          , [FSA_PAID BY EMPLOYER PERCENT]
          , [LPF_ACCOUNT TYPE]
          , [LPF_PLAN NAME]
          , [LPF_BILLING CODE]
          , [LPF_PEPM FLG]
          , [LPF_PEPM AMOUNT]
          , [LPF_MONTHLY MINIMUM FLG]
          , [LPF_MONTHLY MINIMUM AMOUNT]
          , [LPF_FLAT RATE FLG]
          , [LPF_FLAT RATE AMOUNT]
          , [LPF_PAID BY BROKER FLG]
          , [LPF_PAID BY BROKER PERCENT]
          , [LPF_PAID BY EMPLOYER FLG]
          , [LPF_PAID BY EMPLOYER PERCENT]
          , [HRA_ACCOUNT TYPE]
          , [HRA_PLAN NAME]
          , [HRA_BILLING CODE]
          , [HRA_PEPM FLG]
          , [HRA_PEPM AMOUNT]
          , [KEY_MMHRA MONTHLY MINUMUM]
          , [HRA_MONTHLY MINIMUM FLG]
          , [HRA_MONTHLY MINIMUM AMOUNT]
          , COUNT( * ) countrecs
        FROM
            [TBL_EMPLOYER CONTROL]
        GROUP BY
            [BILLING GROUP PROCESS]
          , [EMPLOYER KEY]
          , [EMPLOYER BILLING NUMBER]
          , [SYSTEM EMPLOYER CODE]
          , [EMPLOYER STATUS]
          , [EMPLOYER EFFECTIVE DATE]
          , [EMPLOYER TERM DATE]
          ,
            -- [True Employer Term Date],
            [BROKER CODE]
          , [BASE_FEE BILLING CODE]
          , [BASE_FEE FLG]
          , [BASE_FEE AMOUNT]
          , [BASE_PAID BY BROKER FLG]
          , [BASE_PAID BY BROKER PERCENT]
          , [BASE_PAID BY EMPLOYER FLG]
          , [BASE_PAID BY EMPLOYER PERCENT]
          , [COBRA BASE_FEE BILLING CODE]
          , [COBRA BASE_FEE FLG]
          , [COBRA BASE_FEE AMOUNT]
          , [COBRA BASE_PAID BY BROKER FLG]
          , [COBRA BASE_PAID BY BROKER PERCENT]
          , [COBRA BASE_PAID BY EMPLOYER FLG]
          , [COBRA BASE_PAID BY EMPLOYER PERCENT]
          ,
            /*    [DCA_Account Type],
         [DCA_Plan Name],
         [DCA_BILLING CODE],
         [DCA_PEPM FLG],
         [DCA_PEPM AMOUNT],
         [DCA_MONTHLY MINIMUM FLG],
         [DCA_MONTHLY MINIMUM AMOUNT],
         [DCA_FLAT RATE FLG],
         [DCA_FLAT RATE AMOUNT],
         [DCA_PAID BY BROKER FLG],
         [DCA_PAID BY BROKER PERCENT],
         [DCA_PAID BY EMPLOYER FLG],
         [DCA_PAID BY EMPLOYER PERCENT],*/
            [FSA_ACCOUNT TYPE]
          , [FSA_PLAN NAME]
          , [FSA_BILLING CODE]
          , [FSA_PEPM FLG]
          , [FSA_PEPM AMOUNT]
          , [KEY_MMFSA MONTHLY MINUMUM]
          , [FSA_MONTHLY MINIMUM FLG]
          , [FSA_MONTHLY MINIMUM AMOUNT]
          , [FSA_FLAT RATE FLG]
          , [FSA_FLAT RATE AMOUNT]
          , [FSA_PAID BY BROKER FLG]
          , [FSA_PAID BY BROKER PERCENT]
          , [FSA_PAID BY EMPLOYER FLG]
          , [FSA_PAID BY EMPLOYER PERCENT]
          , [LPF_ACCOUNT TYPE]
          , [LPF_PLAN NAME]
          , [LPF_BILLING CODE]
          , [LPF_PEPM FLG]
          , [LPF_PEPM AMOUNT]
          , [LPF_MONTHLY MINIMUM FLG]
          , [LPF_MONTHLY MINIMUM AMOUNT]
          , [LPF_FLAT RATE FLG]
          , [LPF_FLAT RATE AMOUNT]
          , [LPF_PAID BY BROKER FLG]
          , [LPF_PAID BY BROKER PERCENT]
          , [LPF_PAID BY EMPLOYER FLG]
          , [LPF_PAID BY EMPLOYER PERCENT]
          , [HRA_ACCOUNT TYPE]
          , [HRA_PLAN NAME]
          , [HRA_BILLING CODE]
          , [HRA_PEPM FLG]
          , [HRA_PEPM AMOUNT]
          , [KEY_MMHRA MONTHLY MINUMUM]
          , [HRA_MONTHLY MINIMUM FLG]
          , [HRA_MONTHLY MINIMUM AMOUNT]
go

