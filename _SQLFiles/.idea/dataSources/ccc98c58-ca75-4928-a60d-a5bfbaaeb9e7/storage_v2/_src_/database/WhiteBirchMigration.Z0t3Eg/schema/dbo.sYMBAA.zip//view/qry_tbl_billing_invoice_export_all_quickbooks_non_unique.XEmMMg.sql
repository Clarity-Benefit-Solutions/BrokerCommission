CREATE VIEW [qry_tbl_billing invoice export all quickbooks non unique]
    AS
        SELECT
            /* sumeet: 2021-09-26 ensure same item is not billed to BROKER and Employer 0- is happening for Setup fees for PPM and others*/ /* sumeet: 2021-09-26 ensure same item is not billed to BROKER and Employer 0- is happening for Setup fees for PPM and others*/
            CASE
                WHEN dbo.IsNotBlank(
                             [Broker Code] ) = 1 THEN 0
                ELSE
                    1
            END
                IsBrokerBilled
            /* sumeet: 2021-09-26 END */
          , [Billing Group]
          , [Employer Name]
          , [Employer Key]
          , [System Employer Key]
          , [Broker Code]
          , [Broker Name]
          , [Billing Code]
          , [Billing Code QB]
          , [Billing Description]
          , [Billing Unit Count]
          , [Billing Unit Rate]
          , [Billing Amount]
          , [Invoice Number]
          , [Invoice Date]
          , [Invoice Due Date]
          , Terms
          , [Customer Message]
          , [Billing Period]
          , [Bill To]
          , [PAID BY BROKER FLG]
          , [KEY_MM Monthly Minimum]
          , [Monthly Min Billing Flg]
          , [Monthly Min Billing Amount]
          , [Calculated Billing Amount]
          , [Employer Billing Number]
          , [GL Receivable Account]
          , [GL Expense Account]
          , [To Print]
          , [To Email]
          , [Monthly Min To Delete]
          , [Original Employer Name]
          , PROCESSED_GROUP
          , rowID
          , [Billing Group Process]
          , RecordID
          , ToDelete
          , DeleteReason
        FROM
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS NON UNIQUE] N
go

