CREATE PROCEDURE [dbo].[_process_append_all_bnd_to_process] AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        BEGIN
            
            /*   append to process from cobra letters*/
            EXEC [dbo].[qry_Append Staging COBRA Letters To Process];
            /*   append to process from staging accounts by billing group*/
            EXEC [dbo].[qry_Append Staging Accounts To Process FSA BND FSAHRA];
            EXEC [dbo].[qry_Append Staging Accounts To Process FSA BND FSAHRA Terms];
            EXEC [dbo].[qry_Append Staging Accounts To Process FSA BND FSAHRA NONBND];
            EXEC [dbo].[qry_Append Staging Accounts To Process HRA FSAHRA];
            EXEC [dbo].[qry_Append Staging Accounts To Process HRA Terms FSAHRA];
            EXEC [dbo].[qry_Append Staging Accounts To Process HRA FSAHRA NONBND];
            EXEC [dbo].[qry_Append Staging Accounts To Process TRN BND FSAPKG];
            EXEC [dbo].[qry_Append Staging Accounts To Process TRN Terms BND FSABKGTRN];
            EXEC [dbo].[qry_Append Staging Accounts To Process TRN BND FSAPKG NONBND];
            EXEC [dbo].[qry_Append Staging Accounts To Process FSA BND FSAPKGTRN];
            EXEC [dbo].[qry_Append Staging Accounts To Process FSA BND FSAPGKTRN Terms];
            EXEC [dbo].[qry_Append Staging Accounts To Process HSA BND LFSAHSA];
            EXEC [dbo].[qry_Append Staging Accounts To Process HSA BND LFSAHSA NONBND];
            EXEC [dbo].[qry_Append Staging Accounts To Process LPF BND LFSAHSA];
            EXEC [dbo].[qry_Append Staging Accounts To Process LPF Terms BND LFSAHSA];
            EXEC [dbo].[qry_Append Staging Accounts To Process LPF BND LFSAHSA NONBND];
            
            /*  update proces table with bnd unique key and set flags   */
            EXEC [dbo].[qry_Update Process Table with BundleBilling UniqueKey];
            EXEC [dbo].[qry_Update Process Table With Bundle Flag To No];
            EXEC [dbo].[qry_Update Process Table With Bundle Qualified];
            
            /*   append to process from staging accounts by billing group*/
            EXEC [dbo].[qry_Append Staging Accounts To Process BASE];
            EXEC [dbo].[qry_Append Staging Accounts To Process BASE COBRA];
            EXEC [dbo].[qry_Append Staging Accounts To Process SPM];
            EXEC [dbo].[qry_Append Staging Accounts To Process Plan Docs frm Control];
            EXEC [dbo].[qry_Append Staging Accounts To Process Renewal frm Control];
            EXEC [dbo].[qry_Append Staging COBRA PEPM Manual frm Control tbl];
            /*  append mp plan and credits to process    */
            EXEC [dbo].[qry_Append Employer PlanSetup To Process Table];
            EXEC [dbo].[qry_Append Employer ACH Credits To Process Table];
            /* append edi 2    */
            EXEC [dbo].[qry_Append Staging EDI_2 Data Source To Process Yes];
            EXEC [dbo].[qry_Append Staging EDI_2 Data Source To Process No];
            /* append edi 3    */
            EXEC [dbo].[qry_Append Staging EDI_3 Data Source To Process];
            /* append edi 4    */
            EXEC [dbo].[qry_Append Staging EDI_4 Debit Card To Process NEW];
            EXEC [dbo].[qry_Append Staging EDI_4 Debit Card To Process Rpl];
            /* append edi 6    */
            EXEC [dbo].[qry_Append Staging EDI_6 Data Source To Process];
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

