CREATE VIEW [dbo].[qry_Employer Control]
    AS
        /* select all fields from EmployerControl*/
        SELECT DISTINCT *
        FROM
            [tbl_Employer Control]
go

