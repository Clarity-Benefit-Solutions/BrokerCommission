CREATE PROCEDURE [dbo].[_new_process_all_employers](
    @p_only_for_name nvarchar(200) = '%' ) AS
BEGIN
    
    DECLARE @msg1 nvarchar(max)
    DECLARE @rowno int = 0
    DECLARE @continue int = 0
    /**/
    
    DECLARE @recordid int;
    DECLARE @employername nvarchar(500);
    DECLARE @employerkey nvarchar(500);
    DECLARE @billinggrouptoprocess nvarchar(500);
    DECLARE @billinggroup nvarchar(500);
    
    DECLARE db_cursor CURSOR FOR SELECT
                                     [Employer Name]
                                   , [Employer Key]
                                   , [Billing Group Process]
                                   , [Billing Group]
                                   , recordid
                                 FROM
                                     dbo.[tbl_Employer Control]
                                 WHERE
                                     [Employer Name] LIKE ISNULL( @p_only_for_name , '%' )
                                 ORDER BY
                                     [Employer Name]
                                   , [Employer Key];
    
    EXEC db_log_message '_new_process_all_employers' , ' OPENING CURSOR' , 'INFO';
    /**/
    OPEN db_cursor
    /**/
    
    WHILE @continue = 1 BEGIN
        FETCH NEXT FROM db_cursor INTO @employername, @employerkey, @billinggrouptoprocess, @billinggroup, @recordid;
        IF @@FETCH_STATUS <> 0
            BEGIN
                SET @continue = 0
                BREAK
            END
        /**/
        
        SET @rowno = @rowno + 1;
        BEGIN TRY
            SET @msg1 = CONCAT( '#RowNo ' , @rowno , 'Processing ' , @recordid , ' ' , @billinggrouptoprocess , ' ' ,
                                @employername , ' ' , @employerkey )
            
            EXEC db_log_message '_new_process_all_employers' , @msg1 , 'INFO';
            
            --
            EXEC [dbo].[_new_process_employer] @recordid
            /**/
        END TRY BEGIN CATCH
            SET @msg1 = CONCAT( @rowno , ' - ' , 'ERROR: ' , ERROR_MESSAGE( ) , ' FOR RECORD ' , @msg1 );
            EXEC db_log_error 50001 , '_new_process_all_employers' , @msg1 , 'ERROR';
        END CATCH
        
        /**/
    END
    /* while*/
    
    /**/
    CLOSE db_cursor
    DEALLOCATE db_cursor
    
    /**/
    
    SET @msg1 = CONCAT( '**LOG** ' , '_new_process_all_employers' , ' FINISHED INSERTED ROW COUNT: ' , @rowno );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT

END
go

