CREATE  PROCEDURE [dbo].[_process_2_post_import_1] AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        BEGIN/*clear procedure cache - very important when debugging!*/
            DBCC FREEPROCCACHE
            
            
            /*-- truncate EDI Count process tables*/
            EXEC dbo.[qry_Truncate NPM Report Distinct];
            EXEC dbo.[qry_Truncate QB TE];
            EXEC dbo.[qry_Truncate QB TP];
            EXEC dbo.[qry_Truncate tbl NPM Count];
            EXEC dbo.[qry_Truncate Final EDI Billable table];
            EXEC dbo.[qry_Truncate SPMBYACAREPORTING Distinct];
            
            /* process edi counts to final */
            
            EXEC dbo.[qry_Update SPMBYACAREPORT with ClientAlternateID frm ClientList];
            EXEC dbo.[qry_Update SPMBTACAREPORT with UniqueKey];
            
            EXEC dbo.[qry_Append SPMBYACAREPORT To Distict tbl];
            
            EXEC dbo.[qry_Update QB Detail with Client List AltID];
            EXEC dbo.[qry_Update NPN Report Staging with Client List AlTID];
            EXEC dbo.[qry_Update NPN With Client List EDI];
            EXEC dbo.[qry_Truncate Final EDI Billable table];
            EXEC dbo.[qry_Append EDI groups To Final Billing];
            EXEC dbo.[qry_Truncate QB TE];
            EXEC dbo.[qry_Append QB TE Count To TE Table rev];
            EXEC dbo.[qry_Update Final EDI with TE Counts];
            EXEC dbo.[qry_Truncate QB TP];
            EXEC dbo.[qry_Append QB TP Count To TP Table Rev];
            EXEC dbo.[qry_Update Final EDI with TP Counts];
            EXEC dbo.[qry_Truncate NPM Report Distinct];
            EXEC dbo.[qry_Append NPM Report Staging To NPM Distinct];
            EXEC dbo.[qry_Truncate tbl NPM Count];
            EXEC dbo.[qry_Append NPM Count To NPN Table];
            EXEC dbo.[qry_Update Final EDI with NPM Count];
            EXEC dbo.[qry_Update Final EDI with Final Billible Counts Calc];
            EXEC dbo.[qry_Update Final EDI with Suppression Groups];
            
            /* admin billingalter*/
            EXEC [dbo].[qry_Update Staging_EDI_5_ Trimout fields];
            EXEC [dbo].[qry_Update Staging_EDI_5_formatting runout dt];
            EXEC [dbo].[QRY_UPDATE STAGING EDI_5_BILLIABLE PLAN];
            EXEC [dbo].[qry_Update Staging EDI_5_Billable Plan Uniquekey];
            EXEC [dbo].[qry_Append Linked COBRA Client List To Local COBRA Client List];
            EXEC [dbo].[qry_Append Linked COBRA Letters To Local COBRA Letters];
            EXEC [dbo].[qry_Update Staging COBRA Letters with ClientID];
            EXEC [dbo].[qry_Update Staging EDI_2 Source Date UniqueKey];
            EXEC [dbo].[qry_Update Staging EDI 2 EL Ad US Holdings Florida2 to florida];
            EXEC [dbo].[qry_Update Staging EDI 2 EL Ad US Holdings FloridaERKey];
            EXEC [dbo].[qry_Update Staging EDI_6 Trimout comany field];
            EXEC [dbo].[QRY_APPEND LINKED EDI_3 FINAL COUNTS TO LOCAL EDI_6 TABLE];
            EXEC [dbo].[qry_Update Staging EC Extract Account Uniquekey];
            EXEC [dbo].[QRY_UPDATE STAGING EC EXTRACT WITH BILLABLE KEYCODE];
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

