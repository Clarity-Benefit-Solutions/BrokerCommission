CREATE VIEW [dbo].[qry_Bundle Billing Qualified Records]
    AS
        /* all process records for bundle*/
        SELECT
            [tbl_Process Table].[Employer Name]
          , [tbl_Process Table].[Employer Key]
          , [tbl_Process Table].[Participant ID]
          , [tbl_Process Table].[First Name]
          , [tbl_Process Table].[Last Name]
          , [tbl_Process Table].[BND_BILLING CODE]
          , [tbl_Process Table].[BND_BUNDLE BILL FLG]
          , [tbl_Process Table].[BND_BUNDLE BILL QUAL]
          , '1' [Count]
        FROM
            [tbl_Process Table]
        GROUP BY
            [tbl_Process Table].[Employer Name]
          , [tbl_Process Table].[Employer Key]
          , [tbl_Process Table].[Participant ID]
          , [tbl_Process Table].[First Name]
          , [tbl_Process Table].[Last Name]
          , [tbl_Process Table].[BND_BILLING CODE]
          , [tbl_Process Table].[BND_BUNDLE BILL FLG]
          , [tbl_Process Table].[BND_BUNDLE BILL QUAL]
        HAVING
            ((([tbl_Process Table].[BND_BILLING CODE]) IS NOT NULL) AND
             (([tbl_Process Table].[BND_BUNDLE BILL FLG]) = 1) AND
             (([tbl_Process Table].[BND_BUNDLE BILL QUAL]) = 'bundle'))
go

