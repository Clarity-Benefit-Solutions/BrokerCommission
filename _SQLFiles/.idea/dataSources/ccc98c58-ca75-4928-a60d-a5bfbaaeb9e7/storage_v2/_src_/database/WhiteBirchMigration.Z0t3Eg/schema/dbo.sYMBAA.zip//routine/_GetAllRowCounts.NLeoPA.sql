/* GET ALL TABLE ROW COUNTS */
CREATE PROC dbo._getallrowcounts AS
SELECT *
FROM
    (
        SELECT
            sc.name + '.' + ta.name tablename
          , SUM( pa.rows ) rowcnt
          , CONCAT( 'TRUNCATE TABLE ' , sc.name , '.[' , ta.name , '];' ) truncatesql
        
        FROM
            sys.tables ta
                INNER JOIN sys.partitions pa ON pa.object_id = ta.object_id
                INNER JOIN sys.schemas sc ON ta.schema_id = sc.schema_id
        WHERE
              ta.is_ms_shipped = 0
          AND pa.index_id IN (1, 0)
        GROUP BY
            sc.name
          , ta.name
    ) AS t
    -- where t.tablename like '%staging%'
ORDER BY
    t.rowcnt DESC
  , t.tablename ASC;
go

