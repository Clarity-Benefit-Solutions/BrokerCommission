/**/
CREATE PROCEDURE __exec_wb_r_0_reimportlatestmasterfilesfromaccess AS
BEGIN
    EXEC dbo.util_exec_job_and_wait_till_complete N'WB_R_0_ReImportLatestMasterFilesFromAccess';
    SELECT
        'Finished JOB: WB_R_1_ProcessTruncateAndImportInitialFiles'
END;
go

