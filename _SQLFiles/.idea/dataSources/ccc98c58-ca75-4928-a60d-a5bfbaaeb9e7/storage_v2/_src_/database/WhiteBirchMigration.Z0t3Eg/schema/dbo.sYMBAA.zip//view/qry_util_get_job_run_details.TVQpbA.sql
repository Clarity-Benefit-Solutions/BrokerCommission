CREATE VIEW dbo.qry_util_get_job_run_details
    AS
        SELECT
            sjv.job_id
          , j.name job_name
          , sja.run_requested_date job_start_execution_date
          , sjh.message job_last_run_message
          , sjh.run_date job_history_run_date
          , sjh.run_time job_history_run_time
          , logs.date_created job_step_log_date_created
          , sjh.run_status job_last_run_status
          , sjh.run_duration job_last_run_duration
          , steps.step_name job_step_name
          , steps.last_run_outcome job_step_last_run_status
          , steps.last_run_duration job_step_last_run_duration
          , logs.log job_step_last_run_log
            --       , steps.step_id
            --       , steps.step_uid
            --       , logs.date_created
            --       , logs.date_modified
          , logs.log_size job_step_last_run_log_size
        
        FROM
            msdb.dbo.sysjobs j
                LEFT OUTER JOIN msdb.dbo.sysjobs_view sjv
                                ON j.job_id = sjv.job_id
                LEFT OUTER JOIN msdb.dbo.sysjobsteps AS steps ON steps.job_id = j.job_id
                LEFT OUTER JOIN msdb.dbo.sysjobstepslogs AS logs ON logs.step_uid = steps.step_uid
                LEFT OUTER JOIN msdb.dbo.sysjobactivity sja ON sja.job_id = j.job_id
                LEFT OUTER JOIN msdb.dbo.sysjobhistory sjh ON sja.job_history_id = sjh.instance_id
go

