create FUNCTION get_billed_total_reporting_export(
    @OrgEmployerName nvarchar(255) ) RETURNS money

BEGIN
    DECLARE @ret money;
    SELECT
        @ret = SUM( t.[PEPM Amount] )
    FROM
        dbo.[TBL_BACKUP REPORTING EXPORT TABLE] t
    WHERE
          t.[Original Employer Name] LIKE @OrgEmployerName
      AND ISNULL( t.ToDelete , 0 ) <> 1;
    
    IF @ret IS NULL
        BEGIN
            SET @ret = 0
        END
    
    RETURN @ret
END
go

