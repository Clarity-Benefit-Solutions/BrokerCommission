CREATE VIEW [qry_Linked xFinal EDI Counts To Update]
    AS
        SELECT
            [tbl_Final EDI Billing Group Counts].clientname
          , [tbl_Final EDI Billing Group Counts].[Alternate ER ID]
          , ([tbl_Final EDI Billing Group Counts].[Final Billable Counts]) newqty
          , [tbl_Final EDI Billing Group Counts].suppress
        FROM
            [tbl_Final EDI Billing Group Counts]
        WHERE
            ((([tbl_Final EDI Billing Group Counts].suppress) IS NULL))
go

exec sp_addextendedproperty 'MS_SSMA_SOURCE' ,
     N'Admin_1COBRA_EDI_Counter_vc0825.[qry_Linked xFinal EDI Counts To Update]' , 'SCHEMA' , 'dbo' , 'VIEW' ,
     'qry_Linked xFinal EDI Counts To Update'
go

