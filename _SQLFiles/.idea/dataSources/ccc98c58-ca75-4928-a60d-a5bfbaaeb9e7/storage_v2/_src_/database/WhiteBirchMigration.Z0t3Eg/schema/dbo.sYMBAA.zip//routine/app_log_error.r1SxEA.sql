CREATE PROCEDURE dbo.app_log_error(
                                 @ip_address varchar(50),
                                 @err_source varchar(200),
                                 @file_path varchar(200),
                                 @err_type varchar(200),
                                 @msg varchar(500),
                                 @json_dump text ) AS
BEGIN
    BEGIN TRY
        INSERT
            INTO app_error_logs (
                                ip_address,
                                error_source,
                                file_path,
                                err_type,
                                err_msg,
                                json_dump
        )
        VALUES (
               @ip_address,
               @err_source,
               @file_path,
               @err_type,
               @msg,
               @json_dump
               );
    END TRY BEGIN CATCH
        INSERT
            INTO dbo.db_error_log(
                                 sql_state,
                                 err_no,
                                 err_source,
                                 err_msg
        )
        VALUES (
               ERROR_SEVERITY( ),
               '' + ERROR_NUMBER( ),
               ERROR_PROCEDURE( ),
               CAST( ERROR_LINE( ) AS nvarchar ) + ' - ' + ERROR_MESSAGE( )
               );
    END CATCH
END;
go

