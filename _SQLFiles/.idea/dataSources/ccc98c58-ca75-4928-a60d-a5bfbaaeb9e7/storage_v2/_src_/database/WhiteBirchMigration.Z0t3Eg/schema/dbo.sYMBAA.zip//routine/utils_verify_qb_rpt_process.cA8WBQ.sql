CREATE PROCEDURE utils_verify_qb_rpt_process(
    @employerName nvarchar(255) ) AS
BEGIN
    
    /* process*/
    SELECT
        'PROCESS'
      , *
    FROM
        dbo.[tbl_Process Table All Backup] b
    WHERE
        ([ORIGINAL EMPLOYER NAME] LIKE @employerName OR [Employer Name] LIKE @employerName)
        --       AND [BILLING CODE] = 'COBRA'
    ORDER BY
        [Employer Name]
      , [ORIGINAL EMPLOYER NAME]
      , [BILLING CODE]
        --   , [QB Billing Code]
      , [First Name]
      , [Last Name];
    
    /*rpt*/
    SELECT
        'RPT BK'
      , *
    FROM
        [TBL_BACKUP REPORTING EXPORT TABLE] b
    WHERE
        ([ORIGINAL EMPLOYER NAME] LIKE @employerName OR [Employer Name] LIKE @employerName)
    ORDER BY
        [Employer Name]
      , [ORIGINAL EMPLOYER NAME]
      , [ACTUAL_BILLING CODE]
      , [BILLING CODE]
      , [First Name]
      , [Last Name];
    
    /* QB*/
    SELECT
        'QB'
      , [Employer Name]
      , [ORIGINAL EMPLOYER NAME]
      , [BILLING CODE]
      , [Billing Code QB]
      , q.[Billing Unit Count]
      , q.[Billing Amount]
      , ToDelete
    
    FROM
        [tbl_Billing Invoice Export All QuickBooks] q
    WHERE
        ([ORIGINAL EMPLOYER NAME] LIKE @employerName OR [Employer Name] LIKE @employerName)
    ORDER BY
        [Employer Name]
      , [ORIGINAL EMPLOYER NAME]
      , [BILLING CODE]
      , [Billing Code QB];
    
    /* mismatch*/
    SELECT
        'MISMATCH'
      , t.TableName
      , t.[ORIGINAL EMPLOYER NAME]
      , t.[Billing Unit Count]
      , t.[Billing Amount]
      , t.[Billing Code QB]
      , t.[Billing Group Process]
      , t.[EMPLOYER NAME]
      , t.[Billing Code]
      , t.[Billing Description]
      , t.[Billing Group Process]
    FROM
        dbo.vw_utils_compare_qb_process_backup_reporting_mismatches t
    WHERE
        ([ORIGINAL EMPLOYER NAME] LIKE @employerName OR [Employer Name] LIKE @employerName)
    
    ORDER BY
        t.[ORIGINAL EMPLOYER NAME]
      , t.[Billing Code]
      , t.TableName;

END
go

