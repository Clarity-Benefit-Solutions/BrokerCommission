CREATE VIEW qry_preview_invoices_headline AS
    SELECT DISTINCT
        MIN( [Invoice Number] ) [Invoice Number]
      , [Employer Key]
      , [Employer Name]
      , [To Email]
      , [Invoice Date]
      , [Invoice Due Date]
      , [Terms]
      , [Customer Message]
      , [GL Expense Account]
      , [GL Receivable Account]
      , SUM( [Billing Amount] ) [Invoice Amount]
    FROM
        dbo.[tbl_Billing Invoice Export All QuickBooks]
    GROUP BY
        [Employer Key]
      , [Employer Name]
      , [To Email]
      , [Invoice Date]
      , [Invoice Due Date]
      , [Terms]
      , [Customer Message]
      , [GL Expense Account]
      , [GL Receivable Account]
go

