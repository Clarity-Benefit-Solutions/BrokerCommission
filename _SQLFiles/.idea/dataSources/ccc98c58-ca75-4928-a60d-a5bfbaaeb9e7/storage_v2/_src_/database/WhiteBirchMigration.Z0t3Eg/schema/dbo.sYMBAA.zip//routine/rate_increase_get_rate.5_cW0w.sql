CREATE PROCEDURE rate_increase_get_rate(
                                      @RecordId int,
                                      @colName nvarchar(255),
                                      @rateType nvarchar(255),
                                      @rate nvarchar(255) OUTPUT ) AS
BEGIN
    DECLARE @SQL nvarchar(max);
    DECLARE @msg1 nvarchar(max);
    DECLARE @TABLENAME nvarchar(255);
    DECLARE @retVal nvarchar(255);
    
    SET @SQL = '';
    IF @rateType = 'OLD'
        BEGIN
            SET @TABLENAME = '[tbl_Employer Control_2021_08_14_before_rate_increase]';
        END;
    
    IF @rateType = 'NEW'
        BEGIN
            SET @TABLENAME = '[tbl_Employer Control]';
        END;
    
    IF @rateType = 'PCT'
        BEGIN
            SET @TABLENAME = '[tbl_Employer Control Rate Increase Pct]';
        END;
    
    SET @sql =
            CONCAT( 'SELECT  @rate = ' , @colName , ' FROM ' , @TABLENAME , ' WHERE  RecordID = ' , @RecordId , ';' );
    
--         SET @msg1 = CONCAT( '' , @sql );
--         RAISERROR (@msg1, 0, 1) WITH NOWAIT;
    
    EXECUTE sp_executesql @sql , N'@rate nvarchar(255) OUTPUT' , @rate=@retVal OUTPUT;
    
    SET @rate = @retVal;
--     SELECT
--         @rate;
END
go

