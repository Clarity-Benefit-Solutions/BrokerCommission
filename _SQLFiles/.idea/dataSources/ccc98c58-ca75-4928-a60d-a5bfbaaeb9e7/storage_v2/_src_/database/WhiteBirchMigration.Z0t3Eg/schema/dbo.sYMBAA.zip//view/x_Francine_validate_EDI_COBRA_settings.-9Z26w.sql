CREATE VIEW [dbo].[x_Francine validate EDI COBRA settings]
    AS
        /* */
        SELECT
            [tbl_Staging EDI_3 Source Data].client
          , [tbl_Staging EDI_3 Source Data].bencode
          , [tbl_Employer Control].[COBRA_PEPM TYPE]
          , [tbl_Employer Control].[COBRA_PEPM FLG]
          , [tbl_Employer Control].[COBRA_PEPM Count]
          , [tbl_Staging EDI_3 Source Data].new_qty
          , [tbl_Employer Control].[COBRA_MONTHLY MINIMUM FLG]
          , [tbl_Employer Control].[COBRA_MONTHLY MINIMUM AMOUNT]
        FROM
            [tbl_Employer Control]
                INNER JOIN [tbl_Staging EDI_3 Source Data] ON /*EMBMerge*/ /*[TBL_EMPLOYER CONTROL].[EMPLOYER KEY]*/
            /*EMBMerge end*/
                    [tbl_Staging EDI_3 Source Data].bencode IN
                    ([TBL_EMPLOYER CONTROL].[Employer Key Ben Admin], [TBL_EMPLOYER CONTROL].[EMPLOYER KEY])
        WHERE
            ((([tbl_Employer Control].[COBRA_PEPM TYPE]) IS NULL))
go

