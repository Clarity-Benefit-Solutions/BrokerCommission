CREATE VIEW [dbo].[InsertOnly_MonthlyFix Query]
    AS
        /* select QBSpelling & Client from InsertOnly_MonthlyFix */
        SELECT DISTINCT
            insertonly_monthlyfix.[QBSpelling]
          , insertonly_monthlyfix.[Client]
        FROM
            insertonly_monthlyfix
go

