CREATE PROCEDURE test_util_exec_job_and_return(
    @job_name nvarchar(500) ) AS
BEGIN
    DECLARE @starttime datetime;
    DECLARE @str_starttime nvarchar(50);
    
    EXEC [dbo].[util_exec_job_and_return] @job_name= @job_name , @out_starttime = @starttime OUTPUT;
    --
--     SELECT
--         @starttime
    
    SET @starttime = DATEADD( SECOND , -15 , @starttime )
    
    EXEC [dbo].[util_get_job_last_run_details] @job_name = @job_name , @job_start_date_time= @starttime
END
go

