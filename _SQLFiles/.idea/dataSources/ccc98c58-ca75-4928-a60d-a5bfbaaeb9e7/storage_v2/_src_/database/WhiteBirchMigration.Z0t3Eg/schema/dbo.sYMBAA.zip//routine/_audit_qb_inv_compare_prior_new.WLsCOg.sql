CREATE PROCEDURE _audit_qb_inv_compare_prior_new(
                                                  @newPeriod nvarchar(200)
                                                , @priorPeriod nvarchar(200)
                                                , @onlyDiff int = 0
                                                , @onlyPrior int = 0
                                                , @onlyNew int = 0
                                                , @onlyGreaterThan int = 0
                                                , @onlyLessThan int =0
                                                , @onlySame int = 0
                                                , @groupBy nvarchar(255) = 'EmployerAndDesc' ) AS
BEGIN
    
    DECLARE @sql nvarchar(max);
    DECLARE @where nvarchar(max);
    
    SET @sql = '
    SELECT
       new.[Billing Group Process]
      , new.RecordID
      , new.PROCESSED_GROUP
      , ISNULL
            ( new.[Employer Name] , prior.[Employer Name] ) [Employer Name]
      , ISNULL( new.[Employer Key] , prior.[Employer Key] ) [Employer Key]
      , ISNULL( new.[Billing Code QB] , prior.[Billing Code QB] ) [Billing Code QB]
      , new.processed_group new_processed_group
      , prior.processed_group prior_processed_group
      , new.ToDelete as [new_ToDelete], new.DeleteReason
            , prior.ToDelete  as prior_ToDelete, isnull( ISNULL( new.[Billing Amount] , 0 ) - ISNULL( prior.[Billing Amount] , 0 ),0) DiffInAmount
      , ISNULL( prior.[Billing Amount] , 0 ) [prior_Billing Amount]
      , ISNULL( new.[Billing Amount] , 0 ) [new_Billing Amount]
      , ISNULL( (prior.[Billing Unit Count]) , 0 ) [prior_Billing Unit Count]
      , ISNULL( new.[Billing Unit Count] , 0 ) [new_Billing Unit Count]
      ,  prior.[Billing Description] [prior_Billing Description]
      , new.[Billing Description]  [new_Billing Description]
      , new.[Employer Name] [new_Employer Name]
      , prior.[Employer Name] [prior_Employer Name]
      , new.[Employer Key] [new_Employer Key]
      , prior.[Employer Key] [prior_Employer Key]
      , new.rowid
    FROM
        dbo.[tbl_Billing Invoice Export Archive] AS new
            FULL OUTER JOIN dbo.[tbl_Billing Invoice Export Archive] AS prior
                            ON (new.[Billing Code QB]) = (prior.[Billing Code QB]) AND
                               (new.[Employer Name]) = (prior.[Employer Name])
               WHERE prior.[Billing Period] =' + CHAR( 39 ) + @priorPeriod + CHAR( 39 ) +
               ' AND  new.[Billing Period] =' + CHAR( 39 ) + @newPeriod + CHAR( 39 ) +
               '     and  ISNULL( prior.ToDelete , 0 ) <> 1
                     and  ISNULL( new.ToDelete , 0 ) <> 1               ';
    
    SET @where = ' WHERE 1 = 1';
    
    IF @onlyPrior <> 0
        BEGIN
            SET @where = CONCAT( @where , CHAR( 13 ) , ' AND [new_Employer Name] IS NULL' );
        END
    
    IF @onlyNew <> 0
        BEGIN
            SET @where = CONCAT( @where , CHAR( 13 ) , ' AND [old_Employer Name] IS NULL' );
        END
    
    IF @onlySame <> 0
        BEGIN
            SET @where = CONCAT( @where , CHAR( 13 ) , ' AND diffinamount = 0' );
        END
    
    IF @onlyDiff <> 0
        BEGIN
            SET @where = CONCAT( @where , CHAR( 13 ) , ' AND diffinamount <> 0' );
        END
    
    SET @sql = CONCAT( CHAR( 13 ) , '  SELECT * from (
          ' , @sql , ' ) t1 ' , @where
        );
    
    IF @groupBy = 'EmployerAndDesc'
        BEGIN
            SET @sql = CONCAT( CHAR( 13 ) , '  SELECT
            [Billing Group Process]
          , RecordID
          , PROCESSED_GROUP
          , [Employer Name]
          , [Employer Key]
          , [prior_Billing Description]
          , [new_Billing Description]
          , [Billing Code QB]
          , [new_ToDelete]
            , prior_ToDelete,  SUM( [new_Billing Amount] ) - SUM( [prior_Billing Amount] ) DiffInAmount
          , SUM( [new_Billing Amount] ) [new_Billing Amount]
          , SUM( [prior_Billing Amount] ) [prior_Billing Amount]
          , SUM( dbo.CMoney( [new_Billing Unit Count] ) ) [new_Billing Unit Count]
          , SUM( dbo.CMoney( [prior_Billing Unit Count] ) ) [prior_Billing Unit Count]
        FROM ( ' , @sql , ' ) t2 ' , 'GROUP BY
            [Billing Group Process]
          , [Employer Name]
          , [Employer Key]
           , [new_ToDelete]
            , prior_ToDelete, [prior_Billing Description]
          , [new_Billing Description]
          , [Billing Code QB]
          , RecordID
          , PROCESSED_GROUP '
                );
        END
    
    --     SELECT
    --         @sql;
    
    EXEC (@sql)
END
go

