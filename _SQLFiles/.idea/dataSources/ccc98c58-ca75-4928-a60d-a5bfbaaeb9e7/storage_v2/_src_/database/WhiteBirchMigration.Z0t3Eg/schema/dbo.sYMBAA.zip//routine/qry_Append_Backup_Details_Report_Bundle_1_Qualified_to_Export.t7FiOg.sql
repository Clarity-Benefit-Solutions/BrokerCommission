CREATE PROCEDURE dbo.[QRY_APPEND BACKUP DETAILS REPORT BUNDLE 1 QUALIFIED TO EXPORT] AS
    /* inserts all Process rows matching 'bundle' to BackupReporting only if BND_BILLING CODE is NOT NULL*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BACKUP REPORTING EXPORT TABLE] (
                                                     RowId,
                                                     [EMPLOYER KEY],
                                                     [EMPLOYER NAME],
                                                     [BACKUP INVOICE NUMBER],
                                                     [BILLING CODE],
                                                     [BILLING DESCRIPTION],
                                                     [LAST NAME],
                                                     [FIRST NAME],
                                                     [PARTICIPANT STATUS],
                                                     [PARTICIPANT TERM DATE],
                                                     [PEPM FLG],
                                                     pepm,
                                                     [PEPM AMOUNT],
                                                     [BILLING GROUP],
                                                     division,
                                                     [ORIGINAL EMPLOYER NAME],
                                                     [BND_BILLING CODE],
                                                     [ACTUAL_BILLING CODE],
                                                     [Billing Group Process],
                                                     UniqueKeyParticipant
        
        )
        SELECT
            MIN( RowId )
          , [EMPLOYER KEY]
          , [EMPLOYER NAME]
          , [BACKUP INVOICE NUMBER]
          , ([BND_BILLING CODE]) [BILLING CODE]
          , ([BND_BILLING CODE]) [BILLING DESCRIPTION]
          , [LAST NAME]
          , [FIRST NAME]
          , [PARTICIPANT STATUS]
          , [PARTICIPANT TERM DATE]
          , [PEPM FLG]
          , CASE
                WHEN [PEPM FLG] = 1 THEN SUM( CASE
                                                  WHEN [PEPM COUNT] > 0 THEN [PEPM COUNT]
                                                  ELSE 1
                                              END )
                ELSE MAX( [PEPM COUNT] )
            END units
          , CASE
                WHEN [PEPM FLG] = 1 THEN SUM( CASE
                                                  WHEN [PEPM COUNT] > 0 THEN [PEPM COUNT]
                                                  ELSE 1
                                              END * [PEPM AMOUNT] )
                ELSE MAX( [PEPM AMOUNT] )
            END amount
            --           , IIF( [PEPM COUNT] = 0 , '1' ,
            --                  [PEPM COUNT] ) pepm
            --           , ([BND_BUNDLE RATE AMOUNT]) [PEPM AMOUNT]
          , [BILLING GROUP]
          , MAX( division )
          , [ORIGINAL EMPLOYER NAME]
          , [BND_BILLING CODE]
          , [BILLING CODE]
          , [Billing Group Process]
          , UniqueKeyParticipant
        FROM
            [TBL_PROCESS TABLE ALL BACKUP]
        WHERE
              ((([BND_BUNDLE BILL QUAL]) = 'bundle') AND
               (([BILLING GROUP PROCESS]) = 'Bundle'))
          AND ((dbo.isnotblank( [BND_BILLING CODE] ) = 1))
        GROUP BY
            [EMPLOYER KEY]
          , [EMPLOYER NAME]
          , [BACKUP INVOICE NUMBER]
            --           , ([BND_BILLING CODE])
          , [LAST NAME]
          , [FIRST NAME]
          , [PARTICIPANT STATUS]
          , [PARTICIPANT TERM DATE]
            --           , IIF( [PEPM COUNT] = 0 , '1' , [PEPM COUNT] )
            --           , ([BND_BUNDLE RATE AMOUNT])
          , [BILLING GROUP]
          , uniquekeyparticipant
          , [BND_BILLING CODE]
          , [BILLING CODE]
            --           , division
          , [ORIGINAL EMPLOYER NAME]
          , [PEPM FLG]
          , [Billing Group Process];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

