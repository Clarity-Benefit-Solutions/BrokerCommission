CREATE VIEW [qry_tbl_billing invoice export all quickbooks non unique 2]
AS
    SELECT
        IsBrokerBilled
      , [Billing Group]
      , [Employer Name]
      , [Employer Key]
      , [System Employer Key]
      , [Broker Code]
      , [Broker Name]
      , [Billing Code]
      , [Billing Code QB]
      , [Billing Description]
      , [Billing Unit Count]
      , [Billing Unit Rate]
      , [Billing Amount]
      , [Invoice Number]
      , [Invoice Date]
      , [Invoice Due Date]
      , Terms
      , [Customer Message]
      , [Billing Period]
      , [Bill To]
      , [PAID BY BROKER FLG]
      , [KEY_MM Monthly Minimum]
      , [Monthly Min Billing Flg]
      , [Monthly Min Billing Amount]
      , [Calculated Billing Amount]
      , [Employer Billing Number]
      , [GL Receivable Account]
      , [GL Expense Account]
      , [To Print]
      , [To Email]
      , [Monthly Min To Delete]
      , [Original Employer Name]
      , PROCESSED_GROUP
      , rowID
      , [Billing Group Process]
      , RecordID
      , ToDelete
      , DeleteReason
      , ROW_NUMBER( )
                OVER (PARTITION BY [Original Employer Name], [Billing Code], [Billing Unit Count], [Billing Unit Rate]
                    ORDER BY isbrokerbilled
                    ) RowNum
    FROM
        [qry_tbl_billing invoice export all quickbooks non unique]
go

