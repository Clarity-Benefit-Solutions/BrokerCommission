CREATE PROCEDURE dbo.[QRY_APPEND PROCESS TBL TO FINAL BILLING EXPORT BUNDLE] AS
    /* inserts all Process records matching [BND_BUNDLE BILL QUAL]) = 'Bundle' and [BND_BILLING CODE]) IS NOT NULL into InvExp */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT] (
                                              [EMPLOYER NAME],
                                              [SYSTEM EMPLOYER KEY],
                                              [BILLING GROUP],
                                              [EMPLOYER KEY],
                                              [BROKER CODE],
                                              [EMPLOYER BILLING NUMBER],
                                              [BROKER NAME],
                                              [BILLING CODE],
                                              [KEY_MM MONTHLY MINIMUM],
                                              [MONTHLY MIN BILLING AMOUNT],
                                              [MONTHLY MIN BILLING FLG],
                                              [BILLING UNIT RATE],
                                              [BILLING AMOUNT],
                                              [CALCULATED BILLING AMOUNT],
                                              [BILLING UNIT COUNT],
                                              [PAID BY BROKER FLG]
        )
        SELECT
            [TBL_PROCESS TABLE].[EMPLOYER NAME]
          , [TBL_PROCESS TABLE].[SYSTEM EMPLOYER CODE]
          , [TBL_PROCESS TABLE].[BILLING GROUP]
          , [TBL_PROCESS TABLE].[EMPLOYER KEY]
          , [TBL_PROCESS TABLE].[BROKER CODE]
          , [TBL_PROCESS TABLE].[EMPLOYER BILLING NUMBER]
          , [TBL_PROCESS TABLE].[BROKER NAME]
          , [TBL_PROCESS TABLE].[BND_BILLING CODE]
          , [TBL_PROCESS TABLE].[KEY_MM MONTHLY MINIMUM]
          , [TBL_PROCESS TABLE].[MONTHLY MINIMUM AMOUNT]
          , [TBL_PROCESS TABLE].[MONTHLY MINIMUM FLG]
          , [TBL_PROCESS TABLE].[BND_BUNDLE RATE AMOUNT]
          , ([QRY_BUNDLE BILLING QUALIFIED RECORDS COUNT].[COUNTOFCOUNT] *
             [TBL_PROCESS TABLE].[BND_BUNDLE RATE AMOUNT]) [BILLING AMOUNT]
          , ([QRY_BUNDLE BILLING QUALIFIED RECORDS COUNT].[COUNTOFCOUNT] *
             [TBL_PROCESS TABLE].[BND_BUNDLE RATE AMOUNT]) [CALCULATED BILLING AMOUNT]
          , [QRY_BUNDLE BILLING QUALIFIED RECORDS COUNT].countofcount
          , [TBL_PROCESS TABLE].[PAID BY BROKER FLG]
        FROM
            [TBL_PROCESS TABLE]
                INNER JOIN [QRY_BUNDLE BILLING QUALIFIED RECORDS COUNT] ON [TBL_PROCESS TABLE].[EMPLOYER KEY] =
                                                                           [QRY_BUNDLE BILLING QUALIFIED RECORDS COUNT].[EMPLOYER KEY]
        WHERE
            ((([TBL_PROCESS TABLE].[BND_BUNDLE BILL QUAL]) = 'Bundle') AND
             (([TBL_PROCESS TABLE].[BND_BUNDLE BILL FLG]) = 1))
        GROUP BY
            [TBL_PROCESS TABLE].[EMPLOYER NAME]
          , [TBL_PROCESS TABLE].[SYSTEM EMPLOYER CODE]
          , [TBL_PROCESS TABLE].[BILLING GROUP]
          , [TBL_PROCESS TABLE].[EMPLOYER KEY]
          , [TBL_PROCESS TABLE].[BROKER CODE]
          , [TBL_PROCESS TABLE].[EMPLOYER BILLING NUMBER]
          , [TBL_PROCESS TABLE].[BROKER NAME]
          , [TBL_PROCESS TABLE].[BND_BILLING CODE]
          , [TBL_PROCESS TABLE].[KEY_MM MONTHLY MINIMUM]
          , [TBL_PROCESS TABLE].[MONTHLY MINIMUM AMOUNT]
          , [TBL_PROCESS TABLE].[MONTHLY MINIMUM FLG]
          , [TBL_PROCESS TABLE].[BND_BUNDLE RATE AMOUNT]
          , [QRY_BUNDLE BILLING QUALIFIED RECORDS COUNT].countofcount
          , [TBL_PROCESS TABLE].[PAID BY BROKER FLG]
        HAVING
            ((dbo.isnotblank( [TBL_PROCESS TABLE].[BND_BILLING CODE] ) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

