CREATE PROCEDURE dbo.[FIXLONGITEMS] AS
    /* fixes longitesm in InvExp from user updated rows in longitems*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
        SET
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING CODE QB] = [LONGITEMS].[BILLING CODE QB]
        FROM
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
                INNER JOIN longitems ON ([TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING CODE] =
                                         longitems.[BILLING CODE]) AND
                                        ([TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING DESCRIPTION] =
                                         longitems.[BILLING DESCRIPTION]);
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

