CREATE FUNCTION dbo.isnotblank(
    @string nvarchar(max) ) RETURNS bit AS
    /* simulate missing Access fn */
    BEGIN
        IF @string IS NULL OR @string = '' OR dbo.TRIM( @string ) = ''
            BEGIN
                RETURN 0
            END
        
        RETURN 1;
    END
go

