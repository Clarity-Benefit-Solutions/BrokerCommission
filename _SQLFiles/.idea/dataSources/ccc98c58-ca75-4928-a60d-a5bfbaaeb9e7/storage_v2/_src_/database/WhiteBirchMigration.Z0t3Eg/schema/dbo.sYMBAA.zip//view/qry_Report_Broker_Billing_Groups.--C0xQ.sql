CREATE VIEW [dbo].[qry_Report Broker Billing Groups]
    AS
        /* list EmplCtl records for borker billing group*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[System Employer Code]
          , [tbl_Employer Control].process
        FROM
            [tbl_Employer Control]
        WHERE
            ((([tbl_Employer Control].[Billing Group]) LIKE '%Broker%'))
go

