CREATE VIEW [dbo].[ProcessType]
    AS
        /*  broker billing group process */
        SELECT DISTINCT
            [tbl_Employer Control].[Billing Group Process]
          , [tbl_Employer Control].[Employer Name]
        FROM
            [tbl_Employer Control]
        WHERE
            ((([tbl_Employer Control].[Billing Group Process]) = 'Broker'))
go

