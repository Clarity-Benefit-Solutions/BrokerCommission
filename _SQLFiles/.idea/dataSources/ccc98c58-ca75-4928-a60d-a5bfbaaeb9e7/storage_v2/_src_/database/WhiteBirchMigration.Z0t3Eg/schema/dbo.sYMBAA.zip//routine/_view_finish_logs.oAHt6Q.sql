CREATE PROCEDURE dbo.[_view_finish_logs] AS

BEGIN
    SELECT *
    FROM
        dbo.db_message_log
    WHERE
        log_msg NOT LIKE ' Starting%'
    ORDER BY
        log_id DESC;;

END;
go

