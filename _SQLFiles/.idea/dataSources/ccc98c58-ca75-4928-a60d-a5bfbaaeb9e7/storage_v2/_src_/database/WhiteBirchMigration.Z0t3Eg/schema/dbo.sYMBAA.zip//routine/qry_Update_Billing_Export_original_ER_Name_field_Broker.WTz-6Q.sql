CREATE PROCEDURE dbo.[QRY_UPDATE BILLING EXPORT ORIGINAL ER NAME FIELD BROKER] AS
    /* update InvExp set [Original Employer Name] =  [Employer Name]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_BILLING INVOICE EXPORT]
        SET
            [TBL_BILLING INVOICE EXPORT].[ORIGINAL EMPLOYER NAME] = [TBL_BILLING INVOICE EXPORT].[EMPLOYER NAME];
        
        /* sumeet - added 2021-07-10 update process table also*/
        UPDATE [tbl_Process Table]
        SET
            [ORIGINAL EMPLOYER NAME] = [tbl_Process Table].[EMPLOYER NAME];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

