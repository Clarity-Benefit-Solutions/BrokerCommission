CREATE PROCEDURE dbo.[QRY_APPEND BOB HSA_1012 TO FINAL BILLING] AS
    /* inserts all  InvExpHSA1012 Rows into InvExp*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT] (
                                              [BILLING GROUP],
                                              [EMPLOYER NAME],
                                              [EMPLOYER KEY],
                                              [SYSTEM EMPLOYER KEY],
                                              [BROKER CODE],
                                              [BROKER NAME],
                                              [BILLING CODE],
                                              [BILLING CODE QB],
                                              [BILLING DESCRIPTION],
                                              [BILLING UNIT COUNT],
                                              [BILLING UNIT RATE],
                                              [BILLING AMOUNT],
                                              [INVOICE NUMBER],
                                              [INVOICE DATE],
                                              [INVOICE DUE DATE],
                                              terms,
                                              [CUSTOMER MESSAGE],
                                              [BILLING PERIOD],
                                              [BILL TO],
                                              [MONTHLY MIN BILLING FLG],
                                              [MONTHLY MIN BILLING AMOUNT],
                                              [CALCULATED BILLING AMOUNT],
                                              [EMPLOYER BILLING NUMBER],
                                              [GL RECEIVABLE ACCOUNT],
                                              [GL EXPENSE ACCOUNT],
                                              [TO PRINT],
                                              [TO EMAIL]
        )
        SELECT
            [TBL_BILLING INVOICE EXPORT HSA_1012].[BILLING GROUP]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[EMPLOYER NAME]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[EMPLOYER KEY]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[SYSTEM EMPLOYER KEY]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[BROKER CODE]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[BROKER NAME]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[BILLING CODE]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[BILLING CODE QB]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[BILLING DESCRIPTION]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[BILLING UNIT COUNT]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[BILLING UNIT RATE]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[BILLING AMOUNT]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[INVOICE NUMBER]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[INVOICE DATE]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[INVOICE DUE DATE]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].terms
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[CUSTOMER MESSAGE]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[BILLING PERIOD]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[BILL TO]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[MONTHLY MIN BILLING FLG]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[MONTHLY MIN BILLING AMOUNT]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[CALCULATED BILLING AMOUNT]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[EMPLOYER BILLING NUMBER]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[GL RECEIVABLE ACCOUNT]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[GL EXPENSE ACCOUNT]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[TO PRINT]
          , [TBL_BILLING INVOICE EXPORT HSA_1012].[TO EMAIL]
        FROM
            [TBL_BILLING INVOICE EXPORT HSA_1012];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

