CREATE VIEW [dbo].[FindQBBENCODE]
    AS
        /* find all QBClients wityh namne like %usi%  */
        SELECT
            clarity_qb_customers.name
          , clarity_qb_customers.customfieldbencode
        FROM
            clarity_qb_customers
        WHERE
            (((clarity_qb_customers.name) LIKE '%usi%'))
go

