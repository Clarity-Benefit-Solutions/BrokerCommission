CREATE VIEW [dbo].[qry_Report Monthly Minimum Compare]
    AS
        /* Audit Invoices with month over month billing */
        
        SELECT
            [tbl_Monthly Minimum Conversion Invoice].process
          , [tbl_Monthly Minimum Conversion Invoice].[Employer Name]
          , [tbl_Monthly Minimum Conversion Invoice].[Employer Key]
          , [tbl_Monthly Minimum Conversion Invoice].[Billing Group]
          , [tbl_Monthly Minimum Conversion Invoice].[Key_MM Monthly Minimum]
          , [tbl_Monthly Minimum Conversion Invoice].[BILLING CODE]
          , [tbl_Monthly Minimum Conversion Invoice].[MONTHLY MINIMUM AMOUNT]
          , [tbl_Monthly Minimum Conversion Invoice].[FINAL INVOICE AMOUNT]
          , [tbl_Monthly Minimum Conversion Invoice].[Monthly Min Greater]
        FROM
            [tbl_Monthly Minimum Conversion Invoice]
go

