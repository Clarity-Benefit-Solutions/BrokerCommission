CREATE VIEW [dbo].[x_BACKUP Details Report ALL Bundle old 0919]
    AS
        /* Liat all backup process records for BUNDLE billing*/
        SELECT
            [tbl_Process Table All Backup].[Employer Key]
          , [tbl_Process Table All Backup].[Employer Name]
          , [tbl_Process Table All Backup].[Backup Invoice Number]
          , ([tbl_Process Table All Backup].[BND_BILLING CODE]) [BILLING CODE]
          , ([tbl_Process Table All Backup].[BND_BILLING CODE]) [Billing Description]
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , IIF( [tbl_Process Table All Backup].[PEPM COUNT] = 0 , '1' ,
                 [tbl_Process Table All Backup].[PEPM COUNT] ) pepm
          , ([tbl_Process Table All Backup].[BND_BUNDLE RATE AMOUNT]) [PEPM Amount]
        FROM
            [tbl_Process Table All Backup]
        WHERE
            ((([tbl_Process Table All Backup].[BND_BUNDLE BILL QUAL]) = 'bundle') AND
             (([tbl_Process Table All Backup].[Billing Group]) LIKE '%Bundle%'))
        GROUP BY
            [tbl_Process Table All Backup].[Employer Key]
          , [tbl_Process Table All Backup].[Employer Name]
          , [tbl_Process Table All Backup].[Backup Invoice Number]
          , ([tbl_Process Table All Backup].[BND_BILLING CODE])
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , IIF( [tbl_Process Table All Backup].[PEPM COUNT] = 0 , '1' , [tbl_Process Table All Backup].[PEPM COUNT] )
          , ([tbl_Process Table All Backup].[BND_BUNDLE RATE AMOUNT])
          , [tbl_Process Table All Backup].uniquekeyparticipant
          , [tbl_Process Table All Backup].[BND_BILLING CODE]
        HAVING
            ((([tbl_Process Table All Backup].[BND_BILLING CODE]) IS NOT NULL))
            -- ORDER BY [tbl_Process Table All Backup].[Employer Name], [tbl_Process Table All Backup].[Last Name], [tbl_Process Table All Backup].[First Name];
        UNION ALL
        SELECT
            [tbl_Process Table All Backup].[Employer Key]
          , [tbl_Process Table All Backup].[Employer Name]
          , [tbl_Process Table All Backup].[Backup Invoice Number]
          , ([tbl_Process Table All Backup].[BILLING CODE]) [BILLING CODE]
          , ([tbl_Process Table All Backup].[Plan Name]) [Billing Description]
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , IIF( [tbl_Process Table All Backup].[PEPM COUNT] = 0 , '1' ,
                 [tbl_Process Table All Backup].[PEPM COUNT] ) pepm
          , ([tbl_Process Table All Backup].[PEPM AMOUNT]) [PEPM AMOUNT]
        FROM
            [tbl_Process Table All Backup]
        WHERE
            ((([tbl_Process Table All Backup].[BND_BILLING CODE]) IS NULL) AND
             (([tbl_Process Table All Backup].[BND_BUNDLE BILL QUAL]) = 'Bundle') AND
             (([tbl_Process Table All Backup].[Billing Group]) LIKE '%Bundle%'))
        GROUP BY
            [tbl_Process Table All Backup].[Employer Key]
          , [tbl_Process Table All Backup].[Employer Name]
          , [tbl_Process Table All Backup].[Backup Invoice Number]
          , ([tbl_Process Table All Backup].[BILLING CODE])
          , ([tbl_Process Table All Backup].[Plan Name])
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , IIF( [tbl_Process Table All Backup].[PEPM COUNT] = 0 , '1' , [tbl_Process Table All Backup].[PEPM COUNT] )
          , ([tbl_Process Table All Backup].[PEPM AMOUNT])
          , [tbl_Process Table All Backup].uniquekeyparticipant
            -- ORDER BY [tbl_Process Table All Backup].[Employer Name], [tbl_Process Table All Backup].[Last Name], [tbl_Process Table All Backup].[First Name];
        UNION ALL
        SELECT
            [tbl_Process Table All Backup].[Employer Key]
          , [tbl_Process Table All Backup].[Employer Name]
          , [tbl_Process Table All Backup].[Backup Invoice Number]
          , ([tbl_Process Table All Backup].[BILLING CODE]) [BILLING CODE]
          , ([tbl_Process Table All Backup].[Plan Name]) [Billing Description]
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , IIF( [tbl_Process Table All Backup].[PEPM COUNT] = 0 , '1' ,
                 [tbl_Process Table All Backup].[PEPM COUNT] ) pepm
          , ([tbl_Process Table All Backup].[PEPM AMOUNT]) [PEPM AMOUNT]
        FROM
            [tbl_Process Table All Backup]
        WHERE
            ((([tbl_Process Table All Backup].[BND_BUNDLE BILL QUAL]) IS NULL) AND
             (([tbl_Process Table All Backup].[Billing Group]) LIKE '%Bundle%'))
        GROUP BY
            [tbl_Process Table All Backup].[Employer Key]
          , [tbl_Process Table All Backup].[Employer Name]
          , [tbl_Process Table All Backup].[Backup Invoice Number]
          , ([tbl_Process Table All Backup].[BILLING CODE])
          , ([tbl_Process Table All Backup].[Plan Name])
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , IIF( [tbl_Process Table All Backup].[PEPM COUNT] = 0 , '1' , [tbl_Process Table All Backup].[PEPM COUNT] )
          , ([tbl_Process Table All Backup].[PEPM AMOUNT])
          , [tbl_Process Table All Backup].uniquekeyparticipant
go

