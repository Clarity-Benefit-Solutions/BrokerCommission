CREATE VIEW [dbo].[qry_Report Invoice Audit]
    AS
        /* Audit current inv items by BillingGroup , Employer, invoice number */
        SELECT
            [tbl_Billing Invoice Export].[Billing Group]
          , [tbl_Billing Invoice Export].[Employer Name]
          , [tbl_Billing Invoice Export].[Employer Key]
          , [tbl_Billing Invoice Export].[Billing Code]
          , [tbl_Billing Invoice Export].[Billing Code QB]
          , [tbl_Billing Invoice Export].[Invoice Number]
          , SUM( [tbl_Billing Invoice Export].[Billing Unit Count] ) [SumOfBilling Unit Count]
          , [tbl_Billing Invoice Export].[Billing Unit Rate]
          , SUM( [tbl_Billing Invoice Export].[Billing Amount] ) [SumOfBilling Amount]
        FROM
            [tbl_Billing Invoice Export]
        GROUP BY
            [tbl_Billing Invoice Export].[Billing Group]
          , [tbl_Billing Invoice Export].[Employer Name]
          , [tbl_Billing Invoice Export].[Employer Key]
          , [tbl_Billing Invoice Export].[Billing Code]
          , [tbl_Billing Invoice Export].[Billing Code QB]
          , [tbl_Billing Invoice Export].[Invoice Number]
          , [tbl_Billing Invoice Export].[Billing Unit Rate]
go

