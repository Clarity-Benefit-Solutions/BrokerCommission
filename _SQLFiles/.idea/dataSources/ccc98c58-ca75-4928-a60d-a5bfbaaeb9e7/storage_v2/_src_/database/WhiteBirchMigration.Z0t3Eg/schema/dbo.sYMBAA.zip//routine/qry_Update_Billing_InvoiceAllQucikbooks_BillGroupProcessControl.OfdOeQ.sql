CREATE PROCEDURE dbo.[QRY_UPDATE BILLING INVOICEALLQUCIKBOOKS_BILLGROUPPROCESSCONTROL] AS
    /* update InvExpQB set [Billing Group] =  EmpCtl.[Billing Group Process]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
        SET
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[BILLING GROUP] = [TBL_EMPLOYER CONTROL].[BILLING GROUP PROCESS]
        FROM
            [TBL_EMPLOYER CONTROL]
                INNER JOIN [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
                           ON [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER] =
                              [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER BILLING NUMBER];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

