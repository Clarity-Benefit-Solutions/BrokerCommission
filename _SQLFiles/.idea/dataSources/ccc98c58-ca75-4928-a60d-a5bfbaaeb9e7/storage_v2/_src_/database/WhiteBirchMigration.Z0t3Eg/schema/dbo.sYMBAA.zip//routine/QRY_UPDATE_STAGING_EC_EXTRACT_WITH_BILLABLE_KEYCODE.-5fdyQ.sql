CREATE PROCEDURE dbo.[QRY_UPDATE STAGING EC EXTRACT WITH BILLABLE KEYCODE] AS
    /* update EcImp set [BILLABLE ACCOUNT] = 'Billable' if record exists in Edi5PlanDocImp joined on AccountUniqueKey  */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_STAGING EC EXTRACT]
        SET
            [TBL_STAGING EC EXTRACT].[BILLABLE ACCOUNT] = 'Billable'
        FROM
            [TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT]
                INNER JOIN [TBL_STAGING EC EXTRACT] ON [TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].accountuniquekey =
                                                       [TBL_STAGING EC EXTRACT].uniquekeyaccounts;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

