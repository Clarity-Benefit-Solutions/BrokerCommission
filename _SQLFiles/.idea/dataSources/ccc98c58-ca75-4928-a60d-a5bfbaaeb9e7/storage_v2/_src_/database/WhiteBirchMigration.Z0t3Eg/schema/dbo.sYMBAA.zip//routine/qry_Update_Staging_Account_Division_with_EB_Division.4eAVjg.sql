CREATE PROCEDURE dbo.[QRY_UPDATE STAGING ACCOUNT DIVISION WITH EB DIVISION] AS
    /* update StagingAccts set [Division IB Records] = EBImp.[Division] joined on EmployeeNO and EmpCode */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_STAGING ACCOUNTS]
        SET
            [TBL_STAGING ACCOUNTS].[DIVISION IB RECORDS] = [TBL_STAGING EB EXTRACT].[DIVISION]
        FROM
            [TBL_STAGING EB EXTRACT]
                INNER JOIN [TBL_STAGING ACCOUNTS]
                           ON ([TBL_STAGING EB EXTRACT].[EMPLOYEE ID] = [TBL_STAGING ACCOUNTS].[EMPLOYEE NUMBER]) AND
                              ([TBL_STAGING EB EXTRACT].[EMPLOYER ID] = [TBL_STAGING ACCOUNTS].[EMPLOYER CODE]);
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

