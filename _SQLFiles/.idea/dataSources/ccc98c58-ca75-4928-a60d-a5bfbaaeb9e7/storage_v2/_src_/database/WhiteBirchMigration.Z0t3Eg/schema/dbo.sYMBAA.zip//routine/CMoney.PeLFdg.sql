CREATE FUNCTION dbo.cmoney(
    @string nvarchar(100) ) RETURNS money AS
    /* simulate missing Access fn */
    BEGIN
        DECLARE @moneyval money = 0.00;
        
        SET @moneyval = ISNULL( TRY_CAST( @string AS money ) , 0.00 );
        
        RETURN @moneyval;
    END
go

