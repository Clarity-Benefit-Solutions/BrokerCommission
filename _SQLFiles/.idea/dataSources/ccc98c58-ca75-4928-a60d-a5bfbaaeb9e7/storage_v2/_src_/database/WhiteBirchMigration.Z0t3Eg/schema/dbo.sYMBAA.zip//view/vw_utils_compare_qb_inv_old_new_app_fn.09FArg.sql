CREATE VIEW vw_utils_compare_qb_inv_old_new_app_fn AS
    SELECT
        t3.NewAppAmount
      , t3.OldAppAmount
      , t3.NewAppAmount - t3.OldAppAmount DiffInBilledAmount
      , t3.[Original Employer Name]
      , t3.[Employer Name]
      , t3.[Billing Group Process]
    
    FROM
        (
            SELECT *
                 , dbo.get_billed_total_qb_inv_old_app( t2.[Original Employer Name] ) OldAppAmount
                 , dbo.get_billed_total_qb_inv_new_app( t2.[Original Employer Name] ) NewAppAmount
            
            FROM
                (
                    SELECT DISTINCT
                        [Original Employer Name]
                      , t.[Employer Name]
                      , MAX( t.[Billing Group Process] ) [Billing Group Process]
                    FROM
                        dbo.[tbl_Billing Invoice Export All QuickBooks] t
                    WHERE
                        ISNULL( ToDelete , 0 ) <> 1
                    GROUP BY
                        [Original Employer Name]
                      , t.[Employer Name]
                ) t2
        ) t3
go

