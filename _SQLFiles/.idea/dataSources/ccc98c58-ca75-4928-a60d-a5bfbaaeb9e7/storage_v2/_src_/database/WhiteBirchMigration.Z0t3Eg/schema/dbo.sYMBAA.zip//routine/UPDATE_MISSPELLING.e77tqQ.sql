CREATE PROCEDURE dbo.[UPDATE_MISSPELLING] AS
    /* update InvExpQB set [EMPLOYER NAME] = [MISPELLEDCLIENTS].[CHANGENAME] joined on [EMPLOYER NAME] = [EMPLOYER NAME]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
        SET
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER NAME] = [MISSPELLED].[CHANGENAME]
        FROM
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
                INNER JOIN misspelled
                           ON [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER NAME] = misspelled.[EMPLOYER NAME];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

