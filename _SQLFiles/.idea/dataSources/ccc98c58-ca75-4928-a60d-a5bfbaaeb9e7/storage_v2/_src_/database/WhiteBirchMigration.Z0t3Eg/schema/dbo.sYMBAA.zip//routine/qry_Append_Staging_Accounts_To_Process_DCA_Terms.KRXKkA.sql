CREATE PROCEDURE dbo.[QRY_APPEND STAGING ACCOUNTS TO PROCESS DCA TERMS] AS
    /* !!! invalid inserts EMPCTL records matching
 ???
into Process */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_PROCESS TABLE] (
                                     process,
                                     [EMPLOYER NAME],
                                     [EMPLOYER KEY],
                                     [BILLING GROUP],
                                     [SYSTEM EMPLOYER CODE],
                                     [EMPLOYER BILLING NUMBER],
                                     [BROKER CODE],
                                     [PARTICIPANT ID],
                                     division,
                                     [FIRST NAME],
                                     [LAST NAME]/*, [Account Type], [Plan Name]*/,
                                     [PLAN START DATE],
                                     [PLAN END DATE],
                                     [PARTICIPANT STATUS],
                                     [ALLOW CLAIMS IMPORT],
                                     uniquekeyparticipant,
                                     uniquekeyaccount /*, UniqueKeyBillingAccount, [BILLING CODE], [PEPM FLG], [PEPM AMOUNT], [MONTHLY MINIMUM FLG], [MONTHLY MINIMUM AMOUNT], [FLAT RATE FLG], [FLAT RATE AMOUNT], [PAID BY BROKER FLG], [PAID BY BROKER PERCENT], [PAID BY EMPLOYER FLG], [PAID BY EMPLOYER PERCENT]*/
        )
        SELECT
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_STAGING ACCOUNTS].[EMPLOYEE NUMBER]
          , [TBL_STAGING ACCOUNTS].[DIVISION IB RECORDS]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT FIRST NAME]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT LAST NAME]/*, [tbl_Employer Control].[DCA_Account Type], [tbl_Employer Control].[DCA_Plan Name]*/, [TBL_STAGING ACCOUNTS].[PLAN START DATE DT]
          , [TBL_STAGING ACCOUNTS].[PLAN END DATE DT]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT STATUS]
          , '' [ALLOW CLAIMS IMPORT]
          , [TBL_STAGING ACCOUNTS].uniquekeyparticipant
          , [TBL_STAGING ACCOUNTS].uniquekeyparticipantaccounts/*, ([tbl_Staging Accounts].[Employer Code] + [tbl_Staging Accounts].[Employee Number] + [tbl_Employer Control].[DCA_Billing Code]) AS UniqueKeyBillingAccount, [tbl_Employer Control].[DCA_BILLING CODE], [tbl_Employer Control].[DCA_PEPM FLG], [tbl_Employer Control].[DCA_PEPM AMOUNT], [tbl_Employer Control].[DCA_MONTHLY MINIMUM FLG], [tbl_Employer Control].[DCA_MONTHLY MINIMUM AMOUNT], [tbl_Employer Control].[DCA_FLAT RATE FLG], [tbl_Employer Control].[DCA_FLAT RATE AMOUNT], [tbl_Employer Control].[DCA_PAID BY BROKER FLG], [tbl_Employer Control].[DCA_PAID BY BROKER PERCENT], [tbl_Employer Control].[DCA_PAID BY EMPLOYER FLG], [tbl_Employer Control].[DCA_PAID BY EMPLOYER PERCENT]*/
        FROM
            [TBL_STAGING ACCOUNTS]
                INNER JOIN [TBL_EMPLOYER CONTROL] ON ([TBL_STAGING ACCOUNTS].[EMPLOYER CODE] =
                                                      [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]) /*AND ([tbl_Staging Accounts].[Account Type] = [tbl_Employer Control].[DCA_Account Type])*/
        WHERE
            ((dbo.isnotblank( [TBL_STAGING ACCOUNTS].[TERMINATION DATE TXT] ) = 1))
        GROUP BY
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_STAGING ACCOUNTS].[EMPLOYEE NUMBER]
          , [TBL_STAGING ACCOUNTS].[DIVISION IB RECORDS]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT FIRST NAME]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT LAST NAME]/*, [tbl_Employer Control].[DCA_Account Type], [tbl_Employer Control].[DCA_Plan Name]*/, [TBL_STAGING ACCOUNTS].[PLAN START DATE DT]
          , [TBL_STAGING ACCOUNTS].[PLAN END DATE DT]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT STATUS]
          , [TBL_STAGING ACCOUNTS].uniquekeyparticipant
          , [TBL_STAGING ACCOUNTS].uniquekeyparticipantaccounts/*, ([tbl_Staging Accounts].[Employer Code] + [tbl_Staging Accounts].[Employee Number] + [tbl_Employer Control].[DCA_Billing Code])*//*, [tbl_Employer Control].[DCA_BILLING CODE], [tbl_Employer Control].[DCA_PEPM FLG], [tbl_Employer Control].[DCA_PEPM AMOUNT], [tbl_Employer Control].[DCA_MONTHLY MINIMUM FLG], [tbl_Employer Control].[DCA_MONTHLY MINIMUM AMOUNT], [tbl_Employer Control].[DCA_FLAT RATE FLG], [tbl_Employer Control].[DCA_FLAT RATE AMOUNT], [tbl_Employer Control].[DCA_PAID BY BROKER FLG], [tbl_Employer Control].[DCA_PAID BY BROKER PERCENT], [tbl_Employer Control].[DCA_PAID BY EMPLOYER FLG], [tbl_Employer Control].[DCA_PAID BY EMPLOYER PERCENT]*/, [TBL_STAGING ACCOUNTS].[TERM BILLABLE ACCOUNTS]
        HAVING
            ((([TBL_EMPLOYER CONTROL].process) = 1) AND
             (([TBL_STAGING ACCOUNTS].[PARTICIPANT STATUS]) = 'Terminated') /*AND (([tbl_Employer Control].[DCA_PEPM FLG])=Yes)*/ AND
             (([TBL_STAGING ACCOUNTS].[TERM BILLABLE ACCOUNTS]) = 'Billable'));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

