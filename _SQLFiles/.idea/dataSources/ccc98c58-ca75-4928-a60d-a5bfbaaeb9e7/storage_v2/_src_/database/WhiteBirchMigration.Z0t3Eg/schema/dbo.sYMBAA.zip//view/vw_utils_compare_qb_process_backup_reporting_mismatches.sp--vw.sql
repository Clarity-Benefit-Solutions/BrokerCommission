/*totals by employer*/
    CREATE VIEW dbo.vw_utils_compare_qb_process_backup_reporting_mismatches
    AS
        SELECT
            t.TableName
          , t.[ORIGINAL EMPLOYER NAME]
             , t.[Employer Name]
          , t.[Billing Code]
          , t.[Billing Code QB]
          , SUM( t.PEPM ) [Billing Unit Count]
          , SUM( t.[PEPM AMOUNT] ) [Billing Amount]
          , t.[Billing Description]
          , t.[Billing Group Process]
        
        FROM
            vw_utils_compare_qb_process_backup_reporting t
            
            -- where t.[Billing Code QB] = 'HRA'
        WHERE
                t.[ORIGINAL EMPLOYER NAME] IN (
                                                  SELECT
                                                      [Original Employer Name]
                                                  FROM
                                                      dbo.vw_utils_compare_qb_process_backup_reporting_fn
                                                  WHERE
                                                        1 = 1
                                                    AND invoiceamount <> BackupAmount
                                              )
        GROUP BY
            t.TableName
          , t.[Employer Name]
          , t.[ORIGINAL EMPLOYER NAME]
          , t.[Billing Code]
          , t.[Billing Code QB]
          , t.[Billing Description]
          , t.[Billing Group Process]
go

