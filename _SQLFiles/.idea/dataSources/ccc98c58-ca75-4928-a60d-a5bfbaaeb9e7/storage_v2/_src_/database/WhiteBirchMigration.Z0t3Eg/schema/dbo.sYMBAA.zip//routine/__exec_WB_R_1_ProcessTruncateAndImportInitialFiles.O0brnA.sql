/**/
CREATE PROCEDURE __exec_wb_r_1_processtruncateandimportinitialfiles AS
BEGIN
    BEGIN TRY
        EXEC dbo.util_exec_job_and_wait_till_complete N'WB_R_1_ProcessTruncateAndImportInitialFiles';
        --
        SELECT
            'Finished JOB: WB_R_1_ProcessTruncateAndImportInitialFiles'
    END TRY BEGIN CATCH
        DECLARE @errno varchar(500) = ERROR_NUMBER( )
        DECLARE @errmsg varchar(2000) = ERROR_MESSAGE( )
        DECLARE @errstate varchar(200) = ERROR_STATE( )
        
        EXEC dbo.db_throw_error @errno , 'WB_R_1_ProcessTruncateAndImportInitialFiles' , @errmsg;
        
        --         select
        --             concat( 'ERROR: ' , @errmsg );
        --
    END CATCH
END;
go

