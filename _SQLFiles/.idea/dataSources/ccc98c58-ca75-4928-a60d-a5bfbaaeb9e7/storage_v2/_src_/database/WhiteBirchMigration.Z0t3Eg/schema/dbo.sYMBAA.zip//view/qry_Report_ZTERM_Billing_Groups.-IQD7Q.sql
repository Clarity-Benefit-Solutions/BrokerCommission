CREATE VIEW [dbo].[qry_Report ZTERM Billing Groups]
    AS
        /* list empCtl records with blank BillngGroupProcess*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].[Billing Group Process]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[System Employer Code]
          , [tbl_Employer Control].process
        FROM
            [tbl_Employer Control]
        WHERE
            ((([tbl_Employer Control].[Billing Group Process]) IS NULL))
go

