CREATE VIEW [dbo].[qry_Control Totals Billing Invoice Export by Billing Type]
    AS
        /* sum invoice [Billing Amount] for by ClientName, [Billing Unit Count], Billing Code*/
        SELECT
            [tbl_Billing Invoice Export].[Employer Name]
          , [tbl_Billing Invoice Export].[Billing Unit Count]
          , [tbl_Billing Invoice Export].[Billing Code]
          , SUM( [tbl_Billing Invoice Export].[Billing Amount] ) [SumOfBilling Amount]
        FROM
            [tbl_Billing Invoice Export]
        GROUP BY
            [tbl_Billing Invoice Export].[Employer Name]
          , [tbl_Billing Invoice Export].[Billing Unit Count]
          , [tbl_Billing Invoice Export].[Billing Code]
go

