CREATE VIEW [dbo].[QC_findLongLineitems]
    AS
        /* invoice items with [Billing Code QB] longer thn 31   */
        SELECT
            [tbl_Billing Invoice Export All QuickBooks].*
          , LEN( [Billing Code QB] ) linelegnth
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
        WHERE
            (((LEN( [Billing Code QB] )) > 31))
go

