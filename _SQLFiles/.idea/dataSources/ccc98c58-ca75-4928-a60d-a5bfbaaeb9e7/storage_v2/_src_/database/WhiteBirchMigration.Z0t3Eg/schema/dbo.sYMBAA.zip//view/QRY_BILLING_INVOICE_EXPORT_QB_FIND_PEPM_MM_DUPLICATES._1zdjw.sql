--
    CREATE VIEW [QRY_BILLING INVOICE EXPORT QB FIND PEPM MM DUPLICATES]
    AS
        SELECT *
        FROM
            (
                SELECT
                    uk
                  , ROW_NUMBER( )
                            OVER (PARTITION BY uk ORDER BY SUM( [Billing Amount] ) DESC) rn
                  , [Employer Name]
                  , [Employer Key]
                  , OrgEmpName
                  , SUM( [Billing Amount] ) BillingAmount
                
                FROM
                    (
                        SELECT
                            CONCAT( [Employer Name] ,
                                    dbo.get_org_employer_name( [Employer Name] , [Billing Description] ) ) uk
                          , [Employer Name]
                          , dbo.get_org_employer_name( [Employer Name] , [Billing Description] ) OrgEmpName
                          , [Billing Amount]
                          , qb1.[Employer Key]
                          , qb1.[Broker Code]
                          , qb1.[Broker Name]
                          , qb1.[Billing Code]
                          , qb1.[Billing Code QB]
                          , qb1.[Billing Description]
                          , qb1.[Billing Unit Count]
                          , qb1.[Billing Unit Rate]
                          , qb1.[Original Employer Name]
                          , qb1.PROCESSED_GROUP
                          , qb1.rowID
                          , qb1.[Billing Group Process]
                          , qb1.RecordID
                        FROM
                            dbo.[tbl_Billing Invoice Export All QuickBooks] qb1
                        WHERE
                            [Billing Code] IN ('COBRA', 'COBRA MIN')
                    ) AS qb2
                GROUP BY
                    uk
                  , [Employer Name]
                  , [Employer Key]
                  , OrgEmpName
            ) AS qb2
        
        WHERE
                RN
                > 1
go

