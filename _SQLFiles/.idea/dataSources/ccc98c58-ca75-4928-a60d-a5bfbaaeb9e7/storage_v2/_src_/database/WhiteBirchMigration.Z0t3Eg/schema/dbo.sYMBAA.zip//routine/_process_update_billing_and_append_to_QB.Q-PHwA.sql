CREATE PROCEDURE [dbo].[_process_update_billing_and_append_to_QB](
                                                                @b_updatebrokerdetails int=0,
                                                                @b_appendtobackuprpttable int=0,
                                                                @b_useolderupdatebrokerdetailsproc int=0,
                                                                @processed_group nvarchar(50) ) AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        BEGIN
            /* update invoice numbers*/
            EXEC [QRY_UPDATE BILLING INVOICE EXPORT WITH INVOICE NUMBER];
            
            /* sumeet - added - set current processed grp in BillingInv ansd billinggrouipprocess before changiong employer names*/
            EXEC dbo.[qry_Update Final Billing with Processed Group] @processed_group;
            
            /* sumeet - remove duplicated codes such as COBRA and COBRA MIn, keeping only the max amount - must do before billing to broker */
            EXEC dbo.[QRY_FIX BILLING INVOICE EXPORT REMOVE DUPLICATED CODES]
            
            /* sumeet - ato allow broker billing for bundle etc, these next procs could be tun on InvQB after completion of all other processes incl broker process?*/
            
            /* sumeet - ato allow broker billing for bundle etc, these next procs could be tun on InvQB after completion of all other processes incl broker process?*/
            IF @b_updatebrokerdetails = 1
                BEGIN
                    /* update invDtl table for broker ...*/
                    /* sumeet 2021-03-08 update Org Emp name*/
                    EXEC dbo.[QRY_UPDATE BILLING EXPORT ORIGINAL ER NAME FIELD BROKER]
                    /* end*/
                    EXEC [dbo].[qry_Update Billing Invoice Export With Billing Code Desc Broker];
                    IF @b_useolderupdatebrokerdetailsproc = 1
                        BEGIN
                            EXEC [dbo].[qry_Update Final Billing with Broker Changes - Use  Employer Name And Billing Desc];
                        END
                    ELSE
                        BEGIN
                            EXEC [dbo].[qry_Update Final Billing with Broker Changes];
                        END
                    
                    /* qry_Update Final Billing with Broker Changes 0506*/
                END;
            
                /* ENSURE ORIGINAL EMPLOYER NAME IS FILLED IN*/
            UPDATE [TBL_BILLING INVOICE EXPORT]
            SET
                [TBL_BILLING INVOICE EXPORT].[ORIGINAL EMPLOYER NAME] = [TBL_BILLING INVOICE EXPORT].[EMPLOYER NAME]
            WHERE
                DBO.IsBlank( [ORIGINAL EMPLOYER NAME] ) = 1;
            
            /* sumeet - added - set current processed grp in BillingInv - BUT Broker Name has not yet been updated in PROCESSTABLE and that causes an error for e.g. 'Proper Hospitality' */
            EXEC dbo.[qry_Update Final Billing with Processed Group] @processed_group;
            
            /**/
            EXEC [dbo].[qry_Append Billing Invoice Export To All QuickBooks];
            
            /*  TBL_PROCESS TABLE ALL BACKUP   */
            /*  1 append all from current process table */
            EXEC [dbo].[qry_Append Process tbl To Process tbl All Backup];
            /*  2 append all QB Inv where [BILLING CODE QB]) LIKE '%Monthly Minimum Fee%' */
            EXEC [dbo].[qry_Append All Invoice Monthly Min To All Process tbl];
            /*  */
            EXEC [dbo].[qry_Update Process Tbl All Backup with Final Invoice Numbers];
            EXEC [dbo].[qry_Update Process Tbl All Backup with Final Invoice Numbers Div];
            EXEC [dbo].[qry_Update Process Table All Backup with QB Billing Codes];
            EXEC [dbo].[qry_Update Process Table All with Billing Group Process];
            
            /*[TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]*/
            EXEC [dbo].[qry_Update Billing InvoiceAllQucikbooks_BillGroupProcessControl];
            
            IF @b_appendtobackuprpttable = 1
                BEGIN
                    EXEC [dbo].[qry_Append Backup Details Report Bundle 1 Qualified to Export];
                    EXEC [dbo].[qry_Append Backup Details Report Bundle 2 NonQualified To Export];
                    EXEC [dbo].[qry_Append BACKUP Details Report Bundle 3 NonQualified To Export];
                    EXEC [dbo].[qry_Append Backup Details Report PEPM Only To Export];
                END;
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

