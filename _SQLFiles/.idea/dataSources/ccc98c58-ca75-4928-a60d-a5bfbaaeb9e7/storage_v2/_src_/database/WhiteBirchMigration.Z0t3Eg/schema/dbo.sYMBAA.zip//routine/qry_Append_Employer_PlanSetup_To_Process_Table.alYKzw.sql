CREATE PROCEDURE dbo.[QRY_APPEND EMPLOYER PLANSETUP TO PROCESS TABLE] AS
    /* inserts all EmpCtl matching Process=1 = 'SETUP' into Process*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_PROCESS TABLE] (
                                     [BILLING GROUP],
                                     [EMPLOYER KEY],
                                     [EMPLOYER NAME],
                                     [EMPLOYER BILLING NUMBER],
                                     [BROKER CODE],
                                     [BILLING CODE],
                                     [PEPM COUNT],
                                     [PEPM AMOUNT],
                                     [ACCOUNT TYPE],
                                     [PLAN NAME],
                                     process /*embmerge4*/
            ,
                                     [PAID BY BROKER FLG]
            /*embmerge4 END*/
            /* 2021-08-14 backup fixes*/
            ,
                                     [PEPM FLG]
        )
        SELECT
            [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_EMPLOYER SETUP FEES].[QB BILLING CODE]
          , [TBL_EMPLOYER SETUP FEES].quantity
          , [TBL_EMPLOYER SETUP FEES].rate
          , 'SETUP' [ACCOUNT TYPE]
          , [TBL_EMPLOYER SETUP FEES].[PLAN TYPE]
          , [TBL_EMPLOYER CONTROL].process
            --           , [PAID BY BROKER FLG]
            /*embmerge4*/
          , CASE
                WHEN [TBL_EMPLOYER CONTROL].[Billing Group Process] IN ('BROKER') THEN 1
                /* sumeet- allow partial invoicing to broker*/
                WHEN ISNULL( [TBL_EMPLOYER SETUP FEES].[PAID BY BROKER FLG] , 0 ) <> 0 THEN
                    1
                /* sumeet- allow partial invoicing to broker*//* sumeet- allow partial invoicing to broker*/
                ELSE 0
            END
            /*embmerge4 END*/
          , 1
        FROM
            ([TBL_EMPLOYER SETUP FEES] INNER JOIN [TBL_INVOICE DATE TABLE] ON
                    [TBL_EMPLOYER SETUP FEES].[BILLING PERIOD] = [TBL_INVOICE DATE TABLE].[BILLING PERIOD])
                INNER JOIN [TBL_EMPLOYER CONTROL]
                           ON [TBL_EMPLOYER SETUP FEES].[EMPLOYER KEY] = [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
        GROUP BY
            [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_EMPLOYER SETUP FEES].[QB BILLING CODE]
          , [TBL_EMPLOYER SETUP FEES].quantity
          , [TBL_EMPLOYER SETUP FEES].rate
          , [TBL_EMPLOYER SETUP FEES].[PAID BY BROKER FLG]
          , [TBL_EMPLOYER SETUP FEES].[PLAN TYPE]
          , [TBL_EMPLOYER CONTROL].process
            /*embmerge4*/
          , [Billing Group Process]
            /*embmerge4 END*/
        HAVING
            ((([TBL_EMPLOYER CONTROL].process) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

