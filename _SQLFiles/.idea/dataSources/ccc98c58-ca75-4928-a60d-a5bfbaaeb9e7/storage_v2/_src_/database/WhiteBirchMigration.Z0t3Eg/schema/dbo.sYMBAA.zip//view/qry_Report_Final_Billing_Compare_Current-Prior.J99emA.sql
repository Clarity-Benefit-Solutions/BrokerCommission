CREATE VIEW [dbo].[qry_Report Final Billing Compare Current-Prior]
    AS
        /* compares archived data to current  data by [Billing Code QB] and [Billing Code QB]*/
        SELECT
            [tbl_Billing Invoice Export All QuickBooks].[Billing Group]
          , [tbl_Billing Invoice Export All QuickBooks].[Employer Key]
          , [tbl_Billing Invoice Export All QuickBooks].[Employer Name]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Code QB]
          , ([tbl_Billing Invoice Export All QuickBooks].[Billing Period]) [Current Billing Period]
          , ([qry_Billing Invoice Export Archive To Compare].[Billing Period]) [Prior Billing Period]
          , ([tbl_Billing Invoice Export All QuickBooks].[Billing Unit Count]) [Current Billing Unit Count]
          , ([qry_Billing Invoice Export Archive To Compare].[Billing Unit Count]) [Prior Billing Unit Count]
          , ([tbl_Billing Invoice Export All QuickBooks].[Billing Unit Count] -
             [qry_Billing Invoice Export Archive To Compare].[Billing Unit Count]) [Unit Count Difference]
          , ([tbl_Billing Invoice Export All QuickBooks].[Billing Amount]) [Current Billing Amount]
          , ([qry_Billing Invoice Export Archive To Compare].[Billing Amount]) [Prior Billing Amount]
          , ([tbl_Billing Invoice Export All QuickBooks].[Billing Amount] -
             [qry_Billing Invoice Export Archive To Compare].[Billing Amount]) [Billing Amount Difference]
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
                LEFT JOIN [qry_Billing Invoice Export Archive To Compare]
                          ON ([tbl_Billing Invoice Export All QuickBooks].[Billing Code QB] =
                              [qry_Billing Invoice Export Archive To Compare].[Billing Code QB]) AND
                             ([tbl_Billing Invoice Export All QuickBooks].[Employer Name] =
                              [qry_Billing Invoice Export Archive To Compare].[Employer Name])
go

