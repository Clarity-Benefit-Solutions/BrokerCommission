CREATE VIEW [	qry_QBDetail TE Unique Records	]
    AS
        SELECT
            [tbl_QBACADETAILREPORT Staging].clientname
          , [tbl_QBACADETAILREPORT Staging].[Alternate ER ID]
          , [tbl_QBACADETAILREPORT Staging].ssn
          , [tbl_QBACADETAILREPORT Staging].status
        FROM
            [tbl_QBACADETAILREPORT Staging]
        WHERE
            ((([tbl_QBACADETAILREPORT Staging].relationshipname) = 'SELF'))
        GROUP BY
            [tbl_QBACADETAILREPORT Staging].clientname
          , [tbl_QBACADETAILREPORT Staging].[Alternate ER ID]
          , [tbl_QBACADETAILREPORT Staging].ssn
          , [tbl_QBACADETAILREPORT Staging].status
        HAVING
            ((([tbl_QBACADETAILREPORT Staging].status) = 'TE'))
go

