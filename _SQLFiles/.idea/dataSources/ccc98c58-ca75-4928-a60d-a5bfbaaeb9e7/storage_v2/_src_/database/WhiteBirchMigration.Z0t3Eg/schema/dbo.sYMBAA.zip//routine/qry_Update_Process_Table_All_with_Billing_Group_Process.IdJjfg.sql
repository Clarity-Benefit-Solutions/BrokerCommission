CREATE PROCEDURE dbo.[QRY_UPDATE PROCESS TABLE ALL WITH BILLING GROUP PROCESS] AS
    /* update ProcessBackup.[Billing Group process] from EmpCtl joined on [Employer Key]   ???? ERROR table should be ProcessTable not backup table*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_PROCESS TABLE ALL BACKUP]
        SET
            [TBL_PROCESS TABLE ALL BACKUP].[BILLING GROUP PROCESS] = [TBL_EMPLOYER CONTROL].[BILLING GROUP PROCESS]
        FROM
            [TBL_EMPLOYER CONTROL]
                INNER JOIN [TBL_PROCESS TABLE ALL BACKUP] ON /*EMBMerge*/ /*[TBL_EMPLOYER CONTROL].[EMPLOYER KEY]*/
                    [TBL_PROCESS TABLE ALL BACKUP].[EMPLOYER KEY] IN
                    ([TBL_EMPLOYER CONTROL].[Employer Key Ben Admin], [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]);
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

