CREATE VIEW _audit_qb_inv_old_app AS
    SELECT *
    FROM
    [_ExportedInvoices-App-LastMonth-qb]
go

