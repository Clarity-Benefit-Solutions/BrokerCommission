CREATE PROCEDURE dbo.[QC_MISPELLED_CLIENTS_CLARITY] AS
    /* Appends wrongly spelled clients from QBClients from InvExp to  qc_mispelled_clarity   */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO qc_mispelled_clarity(
                                     [EMPLOYER NAME],
                                     [EMPLOYER KEY]
        )
        SELECT DISTINCT
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER NAME]
          , [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER KEY]
        FROM
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
                LEFT JOIN clarity_qb_customers
                          ON [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER NAME] = clarity_qb_customers.name
        WHERE
            ((dbo.isblank( clarity_qb_customers.name ) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

