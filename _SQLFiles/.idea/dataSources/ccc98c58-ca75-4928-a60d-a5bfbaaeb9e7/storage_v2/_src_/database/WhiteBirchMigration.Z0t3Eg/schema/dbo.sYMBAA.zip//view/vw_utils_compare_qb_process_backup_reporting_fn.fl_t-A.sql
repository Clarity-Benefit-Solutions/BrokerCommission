CREATE VIEW vw_utils_compare_qb_process_backup_reporting_fn AS
    SELECT
        t3.BackupAmount
      , t3.InvoiceAmount
      , t3.backupamount - t3.invoiceamount DiffInBackupAmount
      , t3.[Original Employer Name]
      , t3.[Billing Group Process]
    
    FROM
        (
            SELECT *
                 , dbo.get_billed_total_qb_inv_export( t2.[Original Employer Name] ) InvoiceAmount
                 , dbo.get_billed_total_reporting_export( t2.[Original Employer Name] ) BackupAmount
            
            FROM
                (
                    SELECT DISTINCT
                        [Original Employer Name]
                      , MAX( t.[Billing Group Process] ) [Billing Group Process]
                    FROM
                        dbo.[tbl_Billing Invoice Export All QuickBooks] t
                    WHERE
                        ISNULL( ToDelete , 0 ) <> 1
                    GROUP BY
                        [Original Employer Name]
                      , t.[Billing Group Process]
                ) t2
        ) t3
go

