CREATE FUNCTION dbo.isblank(
    @string nvarchar(max) ) RETURNS bit AS
    /* simulate missing Access fn */
    BEGIN
        IF @string IS NULL OR @string = '' OR dbo.TRIM( @string ) = ''
            BEGIN
                RETURN 1
            END
        
        RETURN 0;
    END
go

