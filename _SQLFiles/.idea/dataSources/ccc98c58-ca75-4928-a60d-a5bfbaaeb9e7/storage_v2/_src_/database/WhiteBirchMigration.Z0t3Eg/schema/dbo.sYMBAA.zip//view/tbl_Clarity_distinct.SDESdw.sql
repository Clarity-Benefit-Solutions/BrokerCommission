CREATE VIEW [dbo].[tbl_Clarity_distinct]
    AS
        /* list distinct emple names from Current InvExp*/
        SELECT DISTINCT
            [Employer Name]
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
go

