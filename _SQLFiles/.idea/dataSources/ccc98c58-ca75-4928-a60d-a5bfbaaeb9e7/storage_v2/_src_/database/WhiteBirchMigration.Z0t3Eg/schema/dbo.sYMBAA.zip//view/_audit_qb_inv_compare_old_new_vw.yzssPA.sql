CREATE VIEW _audit_qb_inv_compare_old_new_vw
AS
    /* select e.[Billing Group Process], compare.* from
         (*/
    SELECT
        new.[Billing Group Process]
      , new.RecordID
      , new.PROCESSED_GROUP
      , ISNULL
            ( new.[Employer Name] , old.[Employer Name] ) [Employer Name]
      , ISNULL( new.[Employer Key] , old.[Employer Key] ) [Employer Key]
      , ISNULL( new.[Billing Code QB] , old.[Billing Code QB] ) [Billing Code QB]
        --       , new.processed_group processed_group
      , ISNULL( new.[Billing Amount] , 0 ) - ISNULL( old.[Billing Amount] , 0 ) diffinamount
      , ISNULL( old.[Billing Amount] , 0 ) [old_Billing Amount]
      , ISNULL( new.[Billing Amount] , 0 ) [new_Billing Amount]
      , ISNULL( new.[Billing Unit Count] , 0 ) -
        ISNULL( old.[Billing Unit Count] , 0 ) diffinunitcounts
      , ISNULL( /*dbo.cmoney*/(old.[Billing Unit Count]) , 0 ) [old_Billing Unit Count]
      , ISNULL( new.[Billing Unit Count] , 0 ) [new_Billing Unit Count]
      , ISNULL( old.[Billing Description] , '' ) [old_Billing Description]
      , ISNULL( new.[Billing Description] , '' ) [new_Billing Description]
      , new.[Employer Name] [new_Employer Name]
      , old.[Employer Name] [old_Employer Name]
      , new.[Employer Key] [new_Employer Key]
      , old.[Employer Key] [old_Employer Key]
      
      , new.rowid
    FROM
        _audit_qb_inv_new_app AS new
            FULL OUTER JOIN _audit_qb_inv_old_app AS old
                            ON /*dbo.trim( new.[Employer Key] ) = dbo.trim( old.[Employer Key] ) AND
                               *//*dbo.trim*/(new.[Billing Description]) = /*dbo.trim*/(old.[Billing Description]) AND
                                /*dbo.trim*/(new.[Employer Name]) = /*dbo.trim*/(old.[Employer Name])
    WHERE
          ISNULL( old.ToDelete , 0 ) = 0
      AND ISNULL( new.ToDelete , 0 ) = 0
go

