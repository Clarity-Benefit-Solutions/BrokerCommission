CREATE VIEW [dbo].[qry_Export_ILEB_Records__] AS
    
    /* query to export all ILEB_Records we need to Alegeus for ECImport RecordType='EC'*/
    SELECT
        'IL' recordtype
      , 'BENEFL' admin
      , [tbl_Staging EC Extract].[Employer Id]
      , 'EB,,,2,' fields
    FROM
        [tbl_Staging EC Extract]
    WHERE
        ((([tbl_Staging EC Extract].[Billable Account]) = 'billable'))
    GROUP BY
        [tbl_Staging EC Extract].[Employer Id]
      , [tbl_Staging EC Extract].recordtype
    HAVING
          ((([tbl_Staging EC Extract].recordtype) = 'EC'))
      AND [Employer Id] IS NOT NULL
      AND [Employer Id] <> ''
go

