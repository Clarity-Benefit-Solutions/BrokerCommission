CREATE PROCEDURE dbo.[QRY_APPEND STAGING EDI_6 DATA SOURCE TO PROCESS] AS
    /* inserts EMPCTL records matching
       [BEN_BEN ADMIN FLG]) = 1
    into Process */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_PROCESS TABLE] (
                                     process,
                                     [EMPLOYER NAME],
                                     [BILLING GROUP],
                                     [EMPLOYER KEY],
                                     [SYSTEM EMPLOYER CODE],
                                     [EMPLOYER BILLING NUMBER],
                                     [BROKER CODE],
                                     [PARTICIPANT ID],
                                     [FIRST NAME],
                                     [LAST NAME],
                                     [ACCOUNT TYPE],
                                     [PLAN NAME],
                                     uniquekeyparticipant,
                                     uniquekeyaccount,
                                     [BILLING CODE],
                                     [PEPM FLG],
                                     [PEPM AMOUNT],
                                     [PEPM COUNT],
                                     [PAID BY BROKER FLG],
                                     [PAID BY BROKER PERCENT],
                                     [PAID BY EMPLOYER FLG],
                                     [PAID BY EMPLOYER PERCENT],
                                     [KEY_MM MONTHLY MINIMUM],
                                     [MONTHLY MINIMUM FLG],
                                     [MONTHLY MINIMUM AMOUNT]
        )
        SELECT
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , '' [EMPLOYEE NUMBER]
          , '' [PARTICIPANT FIRST NAME]
          , '' [PARTICIPANT LAST NAME]
          , 'Employee Navigator' [ACCOUNT TYPE]
          , 'Employee Navigator' [PLAN NAME]
          , '' uniquekeyparticipant
          , ([TBL_EMPLOYER CONTROL].[EMPLOYER KEY] + 'Employee Navigator') uniquekeyaccount
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN FLG]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN PEPM AMOUNT]
          , [TBL_STAGING_EDI_6_SOURCE DATA].[ACTIVE EMPLOYEES]
            /* sumeet - changes 202105-10*/
            /*, [TBL_EMPLOYER CONTROL].[COBRA_PAID BY BROKER FLG]*/
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN_PAID BY BROKER FLG]
            /* end*/
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY BROKER PERCENT]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY EMPLOYER FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY EMPLOYER PERCENT]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN_KEY MONTHLY MINIMUM]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN_MONTHLY MINIMUM FLG]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN_MONTHLY MINIMUM AMOUNT]
        FROM
            [TBL_EMPLOYER CONTROL]
                INNER JOIN [TBL_STAGING_EDI_6_SOURCE DATA] ON /* sumeet: EMBMERGE*/
            /*[TBL_EMPLOYER CONTROL].[EMPLOYER KEY] */ [TBL_STAGING_EDI_6_SOURCE DATA].company IN
                                                       ([TBL_EMPLOYER CONTROL].[Employer Key Ben Admin],
                                                        [TBL_EMPLOYER CONTROL].[EMPLOYER KEY])
        WHERE
            ((([TBL_EMPLOYER CONTROL].process) = 1) AND (([TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN FLG]) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

