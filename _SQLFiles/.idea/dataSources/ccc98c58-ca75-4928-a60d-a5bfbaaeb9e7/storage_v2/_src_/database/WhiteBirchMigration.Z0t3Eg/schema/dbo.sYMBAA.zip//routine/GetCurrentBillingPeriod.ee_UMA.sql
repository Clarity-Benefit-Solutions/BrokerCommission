CREATE FUNCTION dbo.getcurrentbillingperiod(
    @monthsago int = 0 ) RETURNS nvarchar(50) AS
    /* simulate missing Access fn */
    BEGIN
        DECLARE @datevalue nvarchar(50) = NULL;
        DECLARE @datecastvalue date = NULL;
        
        SELECT TOP 1
            @datevalue = [Billing Period]
        FROM
            [tbl_Invoice Date Table];
        
        SET @datecastvalue = CAST( @datevalue AS date );
        RETURN FORMAT( DATEADD( MONTH , @monthsago , @datecastvalue ) , 'MMMM yyyy' );
    
    END
go

