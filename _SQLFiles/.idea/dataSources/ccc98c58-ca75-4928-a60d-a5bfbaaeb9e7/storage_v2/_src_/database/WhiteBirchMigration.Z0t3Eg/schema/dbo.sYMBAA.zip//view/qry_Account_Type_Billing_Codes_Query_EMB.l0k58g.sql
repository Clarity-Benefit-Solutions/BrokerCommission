CREATE VIEW [dbo].[qry_Account Type Billing Codes Query EMB]
    AS
        /* select EMB billing codes for use in benadmin tab*/
        SELECT
            [tbl_Account Type Billing Codes].[Account Type]
          , [tbl_Account Type Billing Codes].[Billing Code]
          , [tbl_Account Type Billing Codes].[QB Billing Item Code]
          , [tbl_Account Type Billing Codes].[Billing Code Description]
          , [tbl_Account Type Billing Codes].[QB CO]
        FROM
            [tbl_Account Type Billing Codes]
        WHERE
            ((([tbl_Account Type Billing Codes].[QB CO]) = 'EMB'))
go

