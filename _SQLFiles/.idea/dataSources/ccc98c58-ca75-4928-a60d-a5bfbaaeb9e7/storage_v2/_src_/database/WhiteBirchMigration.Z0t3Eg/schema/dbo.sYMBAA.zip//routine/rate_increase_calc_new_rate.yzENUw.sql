CREATE FUNCTION rate_increase_calc_new_rate(
    @currrate nvarchar(255),
    @increaseByPct nvarchar(255) ) RETURNS money
    BEGIN
        DECLARE @moneyCurrentRate money;
        DECLARE @moneyIncreaseByPct money;
        DECLARE @newRate money;
        
        SET @currrate = dbo.TRIM( @currrate );
        SET @increaseByPct = dbo.TRIM( @increaseByPct );
        
        SET @moneyCurrentRate = dbo.CMoney( @currrate );
        
        IF @increaseByPct = 'No Increase'
            BEGIN
                SET @increaseByPct = '0.0';
            END
        ELSE
            BEGIN
                IF @increaseByPct IS NULL OR @increaseByPct = ''
                    BEGIN
                        SET @increaseByPct = '0.05'
                    END
            END
        
        BEGIN
            SET @moneyIncreaseByPct = dbo.CMoney( @increaseByPct );
        END
        
        --     IF @moneyCurrentRate = 0
        --         BEGIN
        --             RETURN 0;
        --         END
        --
        --     IF @moneyIncreaseByPct = 0
        --         BEGIN
        --             RETURN @moneyCurrentRate;
        --         END
        --
        SET @newRate = @moneyCurrentRate + (@moneyCurrentRate * @moneyIncreaseByPct);
        
        SET @newRate = CAST( ROUND( @newRate , 2 ) AS money );
        
        RETURN @newRate;
    END
go

