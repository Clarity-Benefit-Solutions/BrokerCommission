CREATE VIEW [qry_Count NPM]
    AS
        SELECT
            [tbl_NPM Report Staging].clientname
          , [tbl_NPM Report Staging].[Alternate ER ID]
          , COUNT( ([tbl_NPM Report Staging].[SSN]) ) [NPM Count]
        FROM
            [tbl_NPM Report Staging]
                INNER JOIN [tbl_Final EDI Billing Group Counts] ON [tbl_NPM Report Staging].[Alternate ER ID] =
                                                                   [tbl_Final EDI Billing Group Counts].[Alternate ER ID]
        GROUP BY
            [tbl_NPM Report Staging].clientname
          , [tbl_NPM Report Staging].[Alternate ER ID]
go

