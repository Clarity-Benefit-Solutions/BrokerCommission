CREATE  PROCEDURE [dbo].[_process_5_basic_all] AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        BEGIN/*clear procedure cache - very important when debugging!*/
            DBCC FREEPROCCACHE
            
            /* clear trn tables  */
            EXEC [dbo].[_process_4_1_clear_temp_trn_tables]
            
            /*  fix NONBEN_NONBEN ADMIN BILLING CODE   */
            EXEC [dbo].[_process_4_1_fix_trn_tables]
            
            /*  dont process any employers    */
            EXEC [dbo].[qry_Update Employer Control Process All To No];
            
            /* mark process = 1 for employers with basic group*/
            EXEC [dbo].[qry_Update Employer Control Process BASIC To Yes];
            
            /*EMBMERGE     */
            EXEC [dbo].[_process_append_all_non_bnd_to_process] 0
            
            /*     */
            EXEC [dbo].[_process_append_all_to_monthly_min] 1
            /*EXEC [dbo].[_process_append_all_to_monthly_min]*/
            
            /*  EMBMERGE - was in process_emb   */
            /* exec  [dbo].[_process_update_divisions]; */
            
            /**/
            /*EMBMERGE     */
            EXEC [dbo].[_process_billing_all_non_bnd] 1 , 0 , 0;
            /* EXEC [dbo].[_process_billing_all_non_bnd] 0 , 0 , 1 , 1;*/
            
            /*     */
            EXEC [dbo].[_process_update_min_conv_table];
            
            /*     */
            EXEC [dbo].[_process_update_billing_and_append_to_QB] 0 , 0 , 0 , 'BASIC';
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

