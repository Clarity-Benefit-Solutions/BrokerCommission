CREATE VIEW [QRY_BILLING INVOICE EXPORT QUICK BOOKS GET BUNDLE ELIGIBLE SERVICES]
    AS
        SELECT
            [Employer Name]
          , [Original Employer Name]
          , [Employer Key]
          , RecordID
          , [BILLING GROUP PROCESS]
          , [BILLING GROUP]
          , [BND_BUNDLE BILL FLG]
          , [BND_BILLING CODE]
          , [BND_BUNDLE RATE AMOUNT]
          , [BND_PAID BY BROKER FLG]
          , [BND_PAID BY BROKER PERCENT]
          , [BND_PAID BY EMPLOYER FLG]
          , [BND_PAID BY EMPLOYER PERCENT]
          , [BND_Plan Name]
          , dbo.get_cobra_mm_amount( [Employer Name] , [Original Employer Name] ) COBRA_MM
          , dbo.get_benadm_mm_amount( [Employer Name] , [Original Employer Name] ) BENADMIN_MM
          , dbo.get_benadm_pepm_amount( [Employer Name] , [Original Employer Name] ) BENADMIN_PEPM
          , dbo.get_en_mm_amount( [Employer Name] , [Original Employer Name] ) EN_MM
          , dbo.get_en_pepm_amount( [Employer Name] , [Original Employer Name] ) EN_PEPM
          , dbo.get_alegeus_mm_amount( [Employer Name] , [Original Employer Name] , 'FSA' ) FSA_MM
          , dbo.get_alegeus_pepm_amount( [Employer Name] , [Original Employer Name] , 'FSA' ) FSA_PEPM
          , dbo.get_alegeus_mm_amount( [Employer Name] , [Original Employer Name] , 'HRA' ) HRA_MM
          , dbo.get_alegeus_pepm_amount( [Employer Name] , [Original Employer Name] , 'HRA' ) HRA_PEPM
          , dbo.get_alegeus_mm_amount( [Employer Name] , [Original Employer Name] , 'HSA' ) HSA_MM
          , dbo.get_alegeus_pepm_amount( [Employer Name] , [Original Employer Name] , 'HSA' ) HSA_PEPM
          , dbo.get_alegeus_mm_amount( [Employer Name] , [Original Employer Name] , 'TRN' ) TRN_MM
          , dbo.get_alegeus_pepm_amount( [Employer Name] , [Original Employer Name] , 'PKGTRN' ) TRN_PEPM
        FROM
            (
                SELECT
                    [Employer Name]
                  , [Employer Name] [Original Employer Name]
                  , [Employer Key]
                  , RecordID
                  , [TBL_EMPLOYER CONTROL].[BILLING GROUP PROCESS]
                  , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
                  , [BND_BUNDLE BILL FLG]
                  , [BND_BILLING CODE]
                  , [BND_BUNDLE RATE AMOUNT]
                  , [BND_PAID BY BROKER FLG]
                  , [BND_PAID BY BROKER PERCENT]
                  , [BND_PAID BY EMPLOYER FLG]
                  , [BND_PAID BY EMPLOYER PERCENT]
                  , [BND_Plan Name]
                
                FROM
                    [TBL_BILLING GROUPS TO PROCESS]
                        INNER JOIN [TBL_EMPLOYER CONTROL] ON [TBL_BILLING GROUPS TO PROCESS].[BILLING GROUP] =
                                                             [TBL_EMPLOYER CONTROL].[BILLING GROUP PROCESS]
                WHERE
                      [TBL_BILLING GROUPS TO PROCESS].[BILLING GROUP] <> 'BUNDLE'
                  AND [TBL_EMPLOYER CONTROL].Process = 1
                  AND (
                              [Employer Name] LIKE dbo.get_employers_to_process_name_filter( )
                              OR [Employer Name] IN
                                 (
                                     SELECT
                                         [Employer Name]
                                     FROM
                                         _EmployerNamesToProcess
                                 )
                          )
                  AND (
                              [BND_BUNDLE BILL FLG] = 1
                              AND dbo.IsNotBlank( [BND_BILLING CODE] ) = 1
                              AND [BND_BUNDLE RATE AMOUNT] > 0
                          )
            ) t
go

