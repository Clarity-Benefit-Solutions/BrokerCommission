CREATE VIEW [dbo].[qry_Report Total Billing Amount From Export]
    AS
        /* count & sum of invoices grouped by Billing Period*/
        SELECT
            [tbl_Billing Invoice Export All QuickBooks].[Billing Period]
          , COUNT( [tbl_Billing Invoice Export All QuickBooks].[Billing Unit Count] ) [CountOfBilling Unit Count]
          , SUM( [tbl_Billing Invoice Export All QuickBooks].[Billing Amount] ) [SumOfBilling Amount]
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
        WHERE
            ISNULL( ToDelete , 0 ) <> 1
        GROUP BY
            [tbl_Billing Invoice Export All QuickBooks].[Billing Period]
go

