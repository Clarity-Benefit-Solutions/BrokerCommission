CREATE PROCEDURE dbo.[QRY_UPDATE PROCESS TABLE WITH BUNDLE QUALIFIED] AS
    /* update Process.[BND_BUNDLE BILL QUAL]= 'BUNDLE' where there are duplcaited emploeeIds in the table */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_PROCESS TABLE]
        SET
            [TBL_PROCESS TABLE].[BND_BUNDLE BILL QUAL] = 'BUNDLE'
        FROM
            [FIND DUPLICATES EMPLOYEE ID IN TBL_PROCESS TABLE]
                INNER JOIN [TBL_PROCESS TABLE] ON ([FIND DUPLICATES EMPLOYEE ID IN TBL_PROCESS TABLE].[EMPLOYER KEY] =
                                                   [TBL_PROCESS TABLE].[EMPLOYER KEY]) AND
                                                  ([FIND DUPLICATES EMPLOYEE ID IN TBL_PROCESS TABLE].[PARTICIPANT ID] =
                                                   [TBL_PROCESS TABLE].[PARTICIPANT ID])
        WHERE
            ((([TBL_PROCESS TABLE].[BND_BUNDLE BILL FLG]) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

