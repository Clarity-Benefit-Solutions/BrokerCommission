CREATE VIEW [dbo].[qry_Report Rate BENADMIN]
    AS
        /* get benadmin fields from EmplCtl records for billing group 'EMB''*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].process
          , [tbl_Employer Control].[QB Client Type]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[Employer Effective Date]
          , [tbl_Employer Control].[Employer Term Date]
          , [tbl_Employer Control].[BROKER CODE]
          , [tbl_Employer Control].[BEN_BEN PLAN ID]
          , [tbl_Employer Control].[BEN_BEN ADMIN FLG]
          , [tbl_Employer Control].[BEN_BEN ADMIN BILLING CODE]
          , [tbl_Employer Control].[BEN_BEN ADMIN PEPM AMOUNT]
          , [tbl_Employer Control].[NONBEN_NONBEN ADMIN FLG]
          , [tbl_Employer Control].[NONBEN_NONBEN ADMIN BILLING CODE]
          , [tbl_Employer Control].[NONBEN_NONBEN ADMIN PEPM AMOUNT]
        FROM
            [tbl_Employer Control]
        WHERE
            /* sumeet: EMBMERGE*/
            /*      ((([TBL_BILLING GROUPS TO PROCESS].[BILLING GROUP]) LIKE '%EMB%'))*/
            [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN FLG] = 1
go

