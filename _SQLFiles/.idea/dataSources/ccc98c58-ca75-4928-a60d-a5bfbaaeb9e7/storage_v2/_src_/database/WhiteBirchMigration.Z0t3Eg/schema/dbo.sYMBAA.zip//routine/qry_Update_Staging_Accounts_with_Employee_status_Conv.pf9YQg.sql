CREATE PROCEDURE dbo.[QRY_UPDATE STAGING ACCOUNTS WITH EMPLOYEE STATUS CONV] AS
    /* update StagingAccts set [Participant Status] = ConvEmpStatus.Target status Code] joined on [Participant Status] = [Source Status Code] */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_STAGING ACCOUNTS]
        SET
            [TBL_STAGING ACCOUNTS].[PARTICIPANT STATUS] = [TBL_CONVERSION EMPLOYEE STATUS].[TARGET STATUS CODE]
        FROM
            [TBL_STAGING ACCOUNTS]
                INNER JOIN [TBL_CONVERSION EMPLOYEE STATUS] ON [TBL_STAGING ACCOUNTS].[PARTICIPANT STATUS] =
                                                               [TBL_CONVERSION EMPLOYEE STATUS].[SOURCE STATUS CODE];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

