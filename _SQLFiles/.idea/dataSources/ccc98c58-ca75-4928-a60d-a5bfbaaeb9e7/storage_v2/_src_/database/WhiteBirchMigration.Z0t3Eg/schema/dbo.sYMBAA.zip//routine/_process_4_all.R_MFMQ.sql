CREATE PROCEDURE [dbo].[_process_4_all] AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        BEGIN
            TRUNCATE TABLE dbo.db_error_log;
            TRUNCATE TABLE dbo.db_message_log;
            
            /* clear previously processed final tables once */
            EXEC dbo._process_4_1_clear_final_trn_tables_once;
            
            /* clear temp  trn tables for each group */
            EXEC [dbo].[_process_4_1_clear_temp_trn_tables]
            
            EXEC dbo._process_5_basic_all;
            EXEC dbo._process_6_division_all;
            EXEC dbo._process_7_bundle_all;
            EXEC dbo._process_8_broker_all;
            EXEC dbo._process_9_pppm_all;
            EXEC dbo._process_10_emb_all;
            
            /* ensure duplciate invoice line items aare removed */
            EXEC dbo.[QRY_APPEND BILLING INVOICE EXPORT TO ALL QUICKBOOKS UNIQUE RECORDS];
            EXEC dbo.[QRY_APPEND BILLING INVOICE EXPORT TO ALL QUICKBOOKS UNIQUE RECORDS];
            
            /*remove any remaining duplicated codes such as cobra mm?pepm, benadm mm/pepm*/
            EXEC [dbo].[QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES];
            
            /* append generated invoices to archive*/
            EXEC dbo.[QRY_APPEND BILLING INVOICE EXPORT TO ARCHIVE];
            
            /* Update all stats for tables used in queries */
            UPDATE STATISTICS dbo.[tbl_Employer Control];
            UPDATE STATISTICS dbo.[tbl_Billing Invoice Export];
            UPDATE STATISTICS dbo.[_ExportedInvoices-App-LastMonth-qb];
            UPDATE STATISTICS dbo.[tbl_Billing Invoice Export All QuickBooks];
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

