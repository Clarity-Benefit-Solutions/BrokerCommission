CREATE VIEW [dbo].[qry_Report Selected Control tbl Yes vs Final Export DIV]
    AS
        /* check if all records marked for processing are present in inv exp
           ?? is same as [qry_Report Selected Control tbl Yes vs Final Export]*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].process
          , ([tbl_Employer Control].[Employer Name]) [ER Name]
          , [tbl_Billing Invoice Export].[Employer Name]
          , [tbl_Billing Invoice Export].[Employer Key]
          , [tbl_Billing Invoice Export].[Billing Code QB]
        FROM
            [tbl_Billing Invoice Export]
                RIGHT JOIN [tbl_Employer Control]
                           ON [tbl_Billing Invoice Export].[Employer Key] = [tbl_Employer Control].[Employer Key]
        WHERE
            ((([tbl_Employer Control].process) = 1))
go

