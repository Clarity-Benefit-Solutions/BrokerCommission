CREATE PROCEDURE dbo.[QRY_APPEND EC EXTRACT TO STAGING ACCOUNTS HSA] AS
    /* inserts all EC Import Rows with matching [TBL_EMPLOYER CONTROL].[HSA_ACCOUNT TYPE] into StagingAccts*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_STAGING ACCOUNTS] (
                                        [EMPLOYER CODE],
                                        [EC ACCOUNT TYPE],
                                        [PLAN NAME],
                                        [PARTICIPANT SSN],
                                        [EMPLOYEE NUMBER],
                                        [PLAN START DATE TXT],
                                        [PLAN START DATE DT],
                                        [PLAN END DATE TXT],
                                        [PLAN END DATE DT],
                                        [EFFECTIVE DATE TXT],
                                        [TERMINATION DATE TXT],
                                        [ACCOUNT STATUS],
                                        [PARTICIPANT STATUS],
                                        [PARTICIPANT FIRST NAME],
                                        [PARTICIPANT LAST NAME],
                                        [PARTICIPANT ANNUAL ELECTION],
                                        [PARTICIPANT PAY PERIOD ELECTION],
                                        [EMPLOYER ANNUAL ELECTION],
                                        [EMPLOYER PAY PERIOD ELECTION],
                                        productpartnerstatus
        )
        SELECT
            [TBL_STAGING EC EXTRACT].[EMPLOYER ID]
          , [TBL_STAGING EC EXTRACT].[ACCOUNT TYPE CODE]
          , [TBL_STAGING EC EXTRACT].[PLAN ID]
          , [TBL_STAGING EC EXTRACT].[EMPLOYEE SOCIAL SECURITY NUMBER]
          , [TBL_STAGING EC EXTRACT].[EMPLOYEE ID]
          , [TBL_STAGING EC EXTRACT].[PLAN START DATE]
          , NULL
            --  [tbl_Employer Control].PlanYearStartDate                                                  AS Expr1,
          , [TBL_STAGING EC EXTRACT].[PLAN END DATE]
          , NULL
            -- [tbl_Employer Control].PlanYearEndDate                                                    AS Expr2,
          , [TBL_STAGING EC EXTRACT].[EFFECTIVE DATE]
          , [TBL_STAGING EC EXTRACT].[TERMINATION DATE]
          , [TBL_STAGING EC EXTRACT].[ACCOUNT STATUS]
          , IIF( [TBL_STAGING EC EXTRACT].[EMPLOYEE STATUS] = 1 , 'Active' ,
                 IIF( [TBL_STAGING EC EXTRACT].[EMPLOYEE STATUS] = 2 , 'Active' ,
                      IIF( [TBL_STAGING EC EXTRACT].[EMPLOYEE STATUS] = 3 , 'TempInactive' ,
                           IIF( [TBL_STAGING EC EXTRACT].[ACCOUNT STATUS] = 4 , 'Terminated' ,
                                IIF( [TBL_STAGING EC EXTRACT].[EMPLOYEE STATUS] = 5 , 'Terminated' , '' ) ) ) ) ) [EMPLOYEE STATUS]
          , [TBL_STAGING EC EXTRACT].[EMPLOYEE FIRST NAME]
          , [TBL_STAGING EC EXTRACT].[EMPLOYEE LAST NAME]
          , [TBL_STAGING EC EXTRACT].[CURRENT ANNUAL ELECTION]
          , [TBL_STAGING EC EXTRACT].[EMPLOYEE PAY PERIOD ELECTION]
          , [TBL_STAGING EC EXTRACT].[EMPLOYER ANNUAL ELECTION]
          , [TBL_STAGING EC EXTRACT].[EMPLOYER PAY PERIOD ELECTION]
          , [TBL_STAGING EC EXTRACT].productpartneracctstatus
        FROM
            [TBL_EMPLOYER CONTROL]
                INNER JOIN [TBL_STAGING EC EXTRACT] ON (/*EMBMerge*/
                                                           /*EMBMerge2*/
                                                           [TBL_STAGING EC EXTRACT].[EMPLOYER ID]) IN
                                                       ([TBL_EMPLOYER CONTROL].[Employer Key Ben Admin],
                                                        [TBL_EMPLOYER CONTROL].[EMPLOYER KEY])
                AND
                                                       ([TBL_EMPLOYER CONTROL].[HSA_ACCOUNT TYPE] =
                                                        [TBL_STAGING EC EXTRACT].[ACCOUNT TYPE CODE]);
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

