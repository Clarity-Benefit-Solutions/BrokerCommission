CREATE PROCEDURE dbo.[QRY BACKUP REPORTING EXPORT UNIQUE RECORDS] AS
    /* inseerts all records into a temp table (TBL_BACKUP REPORTING EXPORT TABLE NON UNIQUE) , deletes all records, and inserts only unique records back into invexpqb*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        
        /* fix orgEmployerID*/
        UPDATE [TBL_BACKUP REPORTING EXPORT TABLE]
        SET
            [ORIGINAL EMPLOYER NAME] = [Employer Name]
        WHERE
            dbo.IsBlank( [ORIGINAL EMPLOYER NAME] ) = 1;
        
        /*delete from temp*/
        TRUNCATE TABLE [TBL_BACKUP REPORTING EXPORT TABLE NON UNIQUE];
        
        /*insert into temp */
        INSERT INTO [TBL_BACKUP REPORTING EXPORT TABLE NON UNIQUE] (
                                                                   [Billing Group],
                                                                   [Employer Key],
                                                                   [Employer Name],
                                                                   Division,
                                                                   [Backup Invoice Number],
                                                                   [BILLING CODE],
                                                                   [Billing Description],
                                                                   [Last Name],
                                                                   [First Name],
                                                                   [Participant Status],
                                                                   [Participant Term Date],
                                                                   PEPM,
                                                                   [PEPM Amount],
                                                                   [ORIGINAL EMPLOYER NAME],
                                                                   ToDelete,
                                                                   DeleteReason,
                                                                   [PEPM Flg],
                                                                   [BND_BILLING CODE],
                                                                   [ACTUAL_BILLING CODE],
                                                                   UniqueKeyParticipant
        )
        SELECT
            [Billing Group]
          , [Employer Key]
          , [Employer Name]
          , Division
          , [Backup Invoice Number]
          , [BILLING CODE]
          , [Billing Description]
          , [Last Name]
          , [First Name]
          , [Participant Status]
          , [Participant Term Date]
          , PEPM
          , [PEPM Amount]
          , [ORIGINAL EMPLOYER NAME]
          , ToDelete
          , DeleteReason
          , [PEPM Flg]
          , [BND_BILLING CODE]
          , [ACTUAL_BILLING CODE]
          , UniqueKeyParticipant
        FROM
            [TBL_BACKUP REPORTING EXPORT TABLE];
        
        /*delete from dest*/
        TRUNCATE TABLE [TBL_BACKUP REPORTING EXPORT TABLE];
        
        /*insert unique only into dest from temp */
        INSERT
            INTO [TBL_BACKUP REPORTING EXPORT TABLE] (
            /* RowId,
             */[Billing Group],
               [Employer Key],
               [Employer Name],
               Division,
               [Backup Invoice Number],
               [BILLING CODE],
               [Billing Description],
               [Last Name],
               [First Name],
               [Participant Status],
               [Participant Term Date],
               PEPM,
               [PEPM Amount],
               [ORIGINAL EMPLOYER NAME],
               ToDelete,
               DeleteReason,
               [PEPM Flg],
               [BND_BILLING CODE],
               [ACTUAL_BILLING CODE],
               UniqueKeyParticipant
        )
        SELECT
            /*  RowId
            ,*/
            [Billing Group]
          , [Employer Key]
          , [Employer Name]
          , Division
          , [Backup Invoice Number]
          , [BILLING CODE]
          , [Billing Description]
          , [Last Name]
          , [First Name]
          , [Participant Status]
          , [Participant Term Date]
          , PEPM
          , [PEPM Amount]
          , [ORIGINAL EMPLOYER NAME]
          , ToDelete
          , DeleteReason
          , [PEPM Flg]
          , [BND_BILLING CODE]
          , [ACTUAL_BILLING CODE]
          , UniqueKeyParticipant
        FROM
            [TBL_BACKUP REPORTING EXPORT TABLE NON UNIQUE]
        WHERE
                rowid IN
                (
                    SELECT
                        MIN( rowid )
                    FROM
                        [TBL_BACKUP REPORTING EXPORT TABLE NON UNIQUE] n
                    WHERE
                        [PEPM Amount] <> 0
                    GROUP BY
                        /* [Billing Group]
                       , */[Employer Key]
                      ,    [Employer Name]
                           --                       ,    Division
                      ,    [Backup Invoice Number]
                      ,    [Last Name]
                      ,    [First Name]
                      ,    [Participant Status]
                      ,    [Participant Term Date]
                      ,    [ORIGINAL EMPLOYER NAME]
                      ,    ToDelete
                      ,    DeleteReason
                        
                        /* 2021-09-16 sumeet - for bundle billed items, keep only one line per bundle per participant */
                        /*,    [BND_BILLING CODE]
                        ,    [BILLING CODE]
                        ,    [Billing Description]
                        ,    [ACTUAL_BILLING CODE]
                              ,    PEPM
                      ,    [PEPM Amount]*/
                      ,    CASE
                               WHEN dbo.isnotblank( n.[BND_BILLING CODE] ) = 1 OR n.[Billing Group] = 'PPPM'
                                   THEN n.[BND_BILLING CODE]
                          
                               ELSE CONCAT( [BND_BILLING CODE] , [BILLING CODE]
                                   , [Billing Description]
                                   , [ACTUAL_BILLING CODE] , PEPM
                                   , [PEPM Amount] , [PEPM Flg] )
                           END
                        /* sumeet end*/
                      ,    UniqueKeyParticipant
                )
        --          AND [Employer Name] = 'Charter Township Of Ypsilanti' and [First Name] = 'JAVONNA'
        --         ORDER BY [tbl_Backup Reporting Export Table Non Unique].[Employer Name], [tbl_Backup Reporting Export Table Non Unique].[First Name]
        ;
        
        /**/
        UPDATE [TBL_BACKUP REPORTING EXPORT TABLE]
        SET
            [Billing Group Process] = [tbl_Employer Control].[Billing Group Process]
        FROM
            [TBL_BACKUP REPORTING EXPORT TABLE]
                INNER JOIN dbo.[tbl_Employer Control] ON [TBL_BACKUP REPORTING EXPORT TABLE].[ORIGINAL EMPLOYER NAME] =
                                                         [tbl_Employer Control].[Employer Name] AND
                                                         dbo.IsNotBlank( [tbl_Employer Control].[Billing Group Process] ) = 1;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END ;
go

