CREATE VIEW [dbo].[tbl_Employer Control Without Matching tbl_Staging COBRA Client L]
    AS
        /* list EmplCtl records for billing group 'cobra' with no records in Cobra import*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[Employer Status]
          , [tbl_Employer Control].[Employer Effective Date]
          , [tbl_Employer Control].[Employer Term Date]
        FROM
            [tbl_Employer Control]
                LEFT JOIN [tbl_Staging COBRA Client List] ON [tbl_Employer Control].[Employer Billing Number] =
                                                             [tbl_Staging COBRA Client List].[ClientAlternate]
        WHERE
            ((([tbl_Employer Control].[Billing Group]) LIKE '%cobra%') AND
             (([tbl_Staging COBRA Client List].clientalternate) IS NULL))
go

