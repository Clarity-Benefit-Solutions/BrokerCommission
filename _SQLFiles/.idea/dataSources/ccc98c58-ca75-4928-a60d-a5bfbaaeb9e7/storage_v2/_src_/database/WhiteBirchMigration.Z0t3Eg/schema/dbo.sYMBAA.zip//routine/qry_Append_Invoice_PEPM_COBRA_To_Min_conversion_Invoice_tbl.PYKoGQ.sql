CREATE PROCEDURE dbo.[QRY_APPEND INVOICE PEPM COBRA TO MIN CONVERSION INVOICE TBL] AS
    /* inserts all InvExp EmpCtl matching MonthlyBilling  and [BILLING CODE]) = 'COBRA' into MonthlyMinConvInv */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_MONTHLY MINIMUM CONVERSION INVOICE] (
                                                          [EMPLOYER NAME],
                                                          [EMPLOYER KEY],
                                                          [BROKER CODE],
                                                          [BILLING GROUP],
                                                          [EMPLOYER BILLING NUMBER],
                                                          [KEY_MM MONTHLY MINIMUM],
                                                          [FINAL INVOICE AMOUNT],
                                                          [BILLING CODE]
        )
        SELECT
            [TBL_BILLING INVOICE EXPORT].[EMPLOYER NAME]
          , [TBL_BILLING INVOICE EXPORT].[EMPLOYER KEY]
          , [TBL_BILLING INVOICE EXPORT].[BROKER CODE]
          , [TBL_BILLING INVOICE EXPORT].[BILLING GROUP]
          , [TBL_BILLING INVOICE EXPORT].[EMPLOYER BILLING NUMBER]
          , [TBL_BILLING INVOICE EXPORT].[KEY_MM MONTHLY MINIMUM]
          , SUM( [TBL_BILLING INVOICE EXPORT].[BILLING AMOUNT] ) [SUMOFBILLING AMOUNT]
          , [TBL_BILLING INVOICE EXPORT].[BILLING CODE]
        FROM
            [TBL_BILLING INVOICE EXPORT]
        GROUP BY
            [TBL_BILLING INVOICE EXPORT].[EMPLOYER NAME]
          , [TBL_BILLING INVOICE EXPORT].[EMPLOYER KEY]
          , [TBL_BILLING INVOICE EXPORT].[BROKER CODE]
          , [TBL_BILLING INVOICE EXPORT].[BILLING GROUP]
          , [TBL_BILLING INVOICE EXPORT].[EMPLOYER BILLING NUMBER]
          , [TBL_BILLING INVOICE EXPORT].[KEY_MM MONTHLY MINIMUM]
          , [TBL_BILLING INVOICE EXPORT].[BILLING CODE]
          , [TBL_BILLING INVOICE EXPORT].[MONTHLY MIN BILLING FLG]
        HAVING
            ((([TBL_BILLING INVOICE EXPORT].[BILLING CODE]) = 'COBRA') AND
             (([TBL_BILLING INVOICE EXPORT].[MONTHLY MIN BILLING FLG]) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

