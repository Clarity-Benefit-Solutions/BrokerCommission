CREATE PROCEDURE dbo.app_log_activity(
                                    @user_id varchar(100),
                                    @ip_add varchar(50),
                                    @event_type varchar(100),
                                    @activity_details text,
                                    @error_source varchar(200) ) AS
BEGIN
    BEGIN TRY
        INSERT
            INTO app_activity_log (
                                  user_id,
                                  ip_add,
                                  event_type,
                                  activity_details,
                                  event_source
        )
        VALUES (
               @user_id,
               @ip_add,
               @event_type,
               @activity_details,
               @error_source
               );
    END TRY BEGIN CATCH
        INSERT
            INTO dbo.db_error_log(
                                 sql_state,
                                 err_no,
                                 err_source,
                                 err_msg
        )
        VALUES (
               ERROR_SEVERITY( ),
               '' + ERROR_NUMBER( ),
               ERROR_PROCEDURE( ),
               CAST( ERROR_LINE( ) AS nvarchar ) + ' - ' + ERROR_MESSAGE( )
               );
    END CATCH
END
go

