/**/
CREATE PROCEDURE __exec_wb_r_99_importprvmonthexcelexports AS
BEGIN
    EXEC dbo.util_exec_job_and_wait_till_complete N'WB_R_99_ImportPrvMonthExcelExports';
    --  SELECT 'Finished JOB: WB_R_2_ProcessImportEBExtractAndProcessAllAndExport'
END
go

