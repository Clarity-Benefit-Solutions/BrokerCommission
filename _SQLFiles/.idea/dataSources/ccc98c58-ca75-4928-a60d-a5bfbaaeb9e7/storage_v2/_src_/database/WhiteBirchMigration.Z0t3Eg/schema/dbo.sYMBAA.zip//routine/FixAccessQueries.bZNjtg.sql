CREATE FUNCTION [dbo].[FixAccessQueries](
    @string nvarchar(max) )
    /* some conversions from Access SQL to SQL Server */
    RETURNS nvarchar(max)
    BEGIN
        DECLARE @value nvarchar(max) = ''
        SET @value = @string;
        SET @value = REPLACE( @value , '"' , '''' );
        SET @value = REPLACE( @value , 'Mid' , 'Substring' );
        SET @value = REPLACE( @value , 'Trim' , 'dbo.Trim' );
        SET @value = REPLACE( @value , 'StripSpChars' , 'dbo.StripSpChars' );
        SET @value = REPLACE( @value , 'ORDER BY' , '-- ORDER BY' );
        SET @value = REPLACE( @value , '= Yes' , '= 1' );
        SET @value = REPLACE( @value , '= No' , '= 0' );
        SET @value = REPLACE( @value , '''Yes''' , '''1''' );
        SET @value = REPLACE( @value , '''No''' , '''0''' );
        SET @value = REPLACE( @value , '&' , '+' );
        RETURN @value;
    END
go

