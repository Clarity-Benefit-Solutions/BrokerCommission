CREATE PROCEDURE dbo.[QRY_APPEND LINKED COBRA CLIENT LIST TO LOCAL COBRA CLIENT LIST] AS
    /* inserts all [TBL_CLLIENT LIST GENERATED] records into  [TBL_STAGING COBRA CLIENT LIST]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_STAGING COBRA CLIENT LIST] (
                                                 clientgroupname,
                                                 clientname,
                                                 billingstartdate,
                                                 ein,
                                                 clientdivisionname,
                                                 clientid,
                                                 clientdivisionid,
                                                 active,
                                                 clientalternate,
                                                 deactivationdate,
                                                 divisionname
        )
        SELECT
            [TBL_CLLIENT LIST GENERATED].clientgroupname
          , [TBL_CLLIENT LIST GENERATED].clientname
          , [TBL_CLLIENT LIST GENERATED].billingstartdate
          , [TBL_CLLIENT LIST GENERATED].ein
          , [TBL_CLLIENT LIST GENERATED].clientdivisionname
          , [TBL_CLLIENT LIST GENERATED].clientid
          , [TBL_CLLIENT LIST GENERATED].clientdivisionid
          , [TBL_CLLIENT LIST GENERATED].active
          , [TBL_CLLIENT LIST GENERATED].clientalternate
          , [TBL_CLLIENT LIST GENERATED].deactivationdate
          , [TBL_CLLIENT LIST GENERATED].divisionname
        FROM
            [TBL_CLLIENT LIST GENERATED];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

