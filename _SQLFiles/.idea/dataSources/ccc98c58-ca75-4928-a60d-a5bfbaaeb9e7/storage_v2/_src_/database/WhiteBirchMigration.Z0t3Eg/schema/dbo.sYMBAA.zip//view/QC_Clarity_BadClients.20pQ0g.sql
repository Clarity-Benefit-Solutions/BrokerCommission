CREATE VIEW [dbo].[QC_Clarity_BadClients]
    AS
        /* misnomer - join export with Clarity_QB_customers on EmployerName  on all clients*/
        SELECT DISTINCT
            [tbl_Billing Invoice Export All QuickBooks].[Employer Name]
          , [tbl_Billing Invoice Export All QuickBooks].[Employer Key]
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
                LEFT JOIN clarity_qb_customers
                          ON [tbl_Billing Invoice Export All QuickBooks].[Employer Name] = clarity_qb_customers.name
        WHERE
            (((clarity_qb_customers.name) IS NULL))
go

