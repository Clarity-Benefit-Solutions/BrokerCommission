CREATE VIEW [dbo].[qry_Report Rate COBRA]
    AS
        /* get COBRA fields from EmplCtl records EXCEPT for billing group 'EMB''*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].process
          , [tbl_Employer Control].[QB Client Type]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[Employer Effective Date]
          , [tbl_Employer Control].[Employer Term Date]
          , [tbl_Employer Control].[BROKER CODE]
          , [tbl_Employer Control].[COBRA BASE_FEE BILLING CODE]
          , [tbl_Employer Control].[COBRA BASE_FEE FLG]
          , [tbl_Employer Control].[COBRA BASE_FEE Amount]
          , [tbl_Employer Control].[COBRA_Plan Name]
          , [tbl_Employer Control].[COBRA_BILLING CODE]
          , [tbl_Employer Control].[COBRA_PEPM TYPE]
          , [tbl_Employer Control].[COBRA_PEPM Count]
          , [tbl_Employer Control].[COBRA_PEPM FLG]
          , [tbl_Employer Control].[COBRA_PEPM AMOUNT]
          , [tbl_Employer Control].[COBRA_KEY MM MONTHLY MINUMUM]
          , [tbl_Employer Control].[COBRA_MONTHLY MINIMUM FLG]
          , [tbl_Employer Control].[COBRA_MONTHLY MINIMUM AMOUNT]
          , [tbl_Employer Control].[COBRA_NOTICE BILLING CODE]
          , [tbl_Employer Control].[COBRA_PER NOTICE FLG]
          , [tbl_Employer Control].[COBRA_PER NOTICE FLG AMOUNT]
        FROM
            [tbl_Employer Control]
        WHERE
            (((
                /* sumeet: EMBMERGE*/
                /*   [BILLING GROUP]) NOT LIKE  '%EMB%' */
                [BEN_BEN ADMIN FLG] <> 1
                /* sumeet END*/
                )))
go

