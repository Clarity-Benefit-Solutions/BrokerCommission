CREATE PROCEDURE [dbo].[_process_update_min_conv_table] AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        BEGIN
            /* sumeet: embmerge to check if employerkey match to [TBL_MONTHLY MINIMUM CONVERSION INVOICE] on EmployeerName is fine*/
            EXEC [dbo].[qry_Update Min Conv tbl frm min Conv Invoice thb];
            EXEC [dbo].[qry_Update Min Monthly Invoice Min Greater Than PEPM];
            EXEC [dbo].[qry_Update Min Remove flag in Export tbl PEPM LessThan Min];
            EXEC [dbo].[qry_Update Min Remove flag in Export tbl PEPM Greater Min];
            EXEC [dbo].[qry_Truncate Monthly Min Billing Export delete flag Yes];
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

