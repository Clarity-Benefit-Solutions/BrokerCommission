CREATE VIEW _audit_missing_platform_clients
    AS
        SELECT DISTINCT
            platform
          , [Employer Name]
          , [Employer Key]
          , [Employer Active Flag]
        FROM
            dbo._audit_platform_clients
        WHERE
                ISNULL( [Employer Key] , '' ) NOT IN (
                                                         SELECT
                                                             ISNULL( [tbl_Employer Control].[Employer Key] , '' )
                                                         FROM
                                                             dbo.[tbl_Employer Control]
                                                     )
          AND   _audit_platform_clients.[Employer name] NOT LIKE 'unknown'
          AND   _audit_platform_clients.[Employer name] NOT LIKE 'Test%'
          AND   _audit_platform_clients.[Employer name] NOT LIKE '% Test %'
          AND   _audit_platform_clients.[Employer name] NOT LIKE '% Test'
go

