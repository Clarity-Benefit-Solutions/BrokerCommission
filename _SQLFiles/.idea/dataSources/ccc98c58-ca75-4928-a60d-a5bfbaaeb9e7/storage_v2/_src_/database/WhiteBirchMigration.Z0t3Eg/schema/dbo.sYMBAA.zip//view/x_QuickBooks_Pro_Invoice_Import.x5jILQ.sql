CREATE VIEW [x_QuickBooks Pro Invoice Import]
    AS
        SELECT *
        FROM
            [x_QuickBooks Pro Invoice Import All]
go

