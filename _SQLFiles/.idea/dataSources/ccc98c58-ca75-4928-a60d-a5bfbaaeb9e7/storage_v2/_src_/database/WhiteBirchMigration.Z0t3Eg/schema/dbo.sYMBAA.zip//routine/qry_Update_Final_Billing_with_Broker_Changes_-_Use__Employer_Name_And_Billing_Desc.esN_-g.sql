CREATE PROCEDURE dbo.[qry_Update Final Billing with Broker Changes - Use  Employer Name And Billing Desc] AS
    /* OLD - update InvExp set employer fields fields from join to AccTypeBillCodes and BrokerLib  on [Broker Code] and [Billing Code]
   where [Paid By Broker Flg]) = 1 */

BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_BILLING INVOICE EXPORT]
        SET
            [TBL_BILLING INVOICE EXPORT].[EMPLOYER NAME]       = [TBL_BROKER LIBRARY].[BROKER NAME]
          , [TBL_BILLING INVOICE EXPORT].[EMPLOYER KEY]        = [TBL_BROKER LIBRARY].[BROKER CODE]
          , [TBL_BILLING INVOICE EXPORT].[BILLING CODE QB]     = [TBL_BILLING INVOICE EXPORT].[EMPLOYER KEY] +
                                                                 [TBL_BILLING INVOICE EXPORT].[BILLING CODE]
          , [TBL_BILLING INVOICE EXPORT].[BILLING DESCRIPTION] =
                    LEFT( [TBL_BILLING INVOICE EXPORT].[EMPLOYER NAME] , 25 ) + '  ' +
                    [TBL_BILLING INVOICE EXPORT].[BILLING CODE]
          , [TBL_BILLING INVOICE EXPORT].[INVOICE NUMBER]      =
                    LEFT( [TBL_BILLING INVOICE EXPORT].[INVOICE NUMBER] , 6 ) + [TBL_BROKER LIBRARY].[BROKER CODE]
        FROM
            [TBL_BILLING INVOICE EXPORT]
                INNER JOIN [TBL_BROKER LIBRARY]
                           ON [TBL_BILLING INVOICE EXPORT].[BROKER CODE] = [TBL_BROKER LIBRARY].[BROKER CODE]
        WHERE
            ((([TBL_BILLING INVOICE EXPORT].[PAID BY BROKER FLG]) = 1));
        --
        /* sumeet - added 2021-07-10 update process table also*/
        
        UPDATE [tbl_Process Table]
        SET
            [EMPLOYER NAME]  = [TBL_BROKER LIBRARY].[BROKER NAME]
          , [EMPLOYER KEY]   = [TBL_BROKER LIBRARY].[BROKER CODE]
            /*   , [BILLING CODE QB]     = [TBL_BILLING INVOICE EXPORT].[EMPLOYER KEY] +
                                                                      [TBL_BILLING INVOICE EXPORT].[BILLING CODE]
               , [BILLING DESCRIPTION] =
                         LEFT( [TBL_BILLING INVOICE EXPORT].[EMPLOYER NAME] , 25 ) + '  ' +
                         [TBL_BILLING INVOICE EXPORT].[BILLING CODE]*/
          , [INVOICE NUMBER] =
                    LEFT( [tbl_Process Table].[INVOICE NUMBER] , 6 ) + [TBL_BROKER LIBRARY].[BROKER CODE]
        FROM
            [tbl_Process Table]
                INNER JOIN [TBL_BROKER LIBRARY]
                           ON [tbl_Process Table].[BROKER CODE] = [TBL_BROKER LIBRARY].[BROKER CODE]
        WHERE
            ((([tbl_Process Table].[PAID BY BROKER FLG]) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

