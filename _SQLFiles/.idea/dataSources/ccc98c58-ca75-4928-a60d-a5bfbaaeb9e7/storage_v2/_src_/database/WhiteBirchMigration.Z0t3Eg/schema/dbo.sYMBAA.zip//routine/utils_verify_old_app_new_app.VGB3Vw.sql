CREATE PROCEDURE utils_verify_old_app_new_app(
    @employerName nvarchar(255) ) AS
BEGIN
    
    SELECT
        'OLD APP'
      , *
    FROM
        dbo.[_ExportedInvoices-App-LastMonth-qb]
    WHERE
        ([ORIGINAL EMPLOYER NAME] LIKE @employerName OR [Employer Name] LIKE @employerName)
    ORDER BY
        [Employer Name]
      , [ORIGINAL EMPLOYER NAME]
      , [BILLING CODE]
      , [BILLING CODE QB]
    
    /**/
    SELECT
        'NEW APP'
      , *
    FROM
        dbo.[tbl_Billing Invoice Export All QuickBooks]
    WHERE
        ([Original Employer Name] LIKE @employerName OR [Employer Name] LIKE @employerName)
    ORDER BY
        [Employer Name]
      , [ORIGINAL EMPLOYER NAME]
      , [BILLING CODE]
      , [BILLING CODE QB]
    
    /* mismatch*/
    SELECT
        'MISMATCH'
      , t.TableName
      , t.[ORIGINAL EMPLOYER NAME]
      , t.[Billing Unit Count]
      , t.[Billing Amount]
      , t.[Billing Code QB]
      , t.[Billing Group Process]
      , t.[EMPLOYER NAME]
      , t.[Billing Code]
      , t.[Billing Description]
      , t.[Billing Group Process]
    FROM
        dbo.vw_utils_compare_qb_inv_old_new_app_mismatches_dtl t
    WHERE
        ([ORIGINAL EMPLOYER NAME] LIKE @employerName OR [Employer Name] LIKE @employerName)
    
    ORDER BY
        t.[ORIGINAL EMPLOYER NAME]
      , t.[Billing Code]
      , t.TableName;
    
    /* process*/
    SELECT
        'PROCESS'
      , *
    FROM
        dbo.[tbl_Process Table All Backup] b
    WHERE
        ([ORIGINAL EMPLOYER NAME] LIKE @employerName OR [Employer Name] LIKE @employerName)
        --       AND [BILLING CODE] = 'COBRA'
    ORDER BY
        [Employer Name]
      , [ORIGINAL EMPLOYER NAME]
      , [BILLING CODE]
        --   , [QB Billing Code]
      , [First Name]
      , [Last Name]
      , UniqueKeyParticipant;

END
go

