CREATE PROCEDURE dbo.[QRY_UPDATE BILLING INVOICE EXPORT WITH GL ACCOUNTS] AS
    /* update InvExp set [GL RECEIVABLE ACCOUNT] and [GL EXPENSE ACCOUNT] from [TBL_ACCOUNTING GL ACCOUNTS] */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_BILLING INVOICE EXPORT]
        SET
            [TBL_BILLING INVOICE EXPORT].[GL RECEIVABLE ACCOUNT] = (
                                                                       SELECT
                                                                           [Receiveable Account]
                                                                       FROM
                                                                           [TBL_ACCOUNTING GL ACCOUNTS]
                                                                   )
          , [TBL_BILLING INVOICE EXPORT].[GL EXPENSE ACCOUNT]    = (
                                                                       SELECT
                                                                           [Expense Account]
                                                                       FROM
                                                                           [TBL_ACCOUNTING GL ACCOUNTS]
                                                                   );
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

