CREATE VIEW [dbo].[x_QuickBooks Pro Invoice ImportFIX3]
    AS
        /* union of importfix 1 and 2
        */
        
        SELECT *
        FROM
            [x_QuickBooks Pro Invoice ImportFIX1]
        
        UNION
        SELECT *
        FROM
            [x_QuickBooks Pro Invoice ImportFIX2]
go

