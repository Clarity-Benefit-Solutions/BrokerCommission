CREATE PROCEDURE dbo.[QRY_FIX BILLING INVOICE EXPORT REMOVE DUPLICATED CODES] AS
    /* inseerts all records into a temp table (TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS NON UNIQUE) , deletes all records, and inserts only unique records back into invexpqb*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' SKIPPING' , 'WARN';
        /* do not delete */
      /*  DELETE
        FROM
            dbo.[tbl_Billing Invoice Export All QuickBooks]
        WHERE
            toDelete = 1;*/
        
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( ' ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END ;
go

