CREATE VIEW [dbo].[QC_Name_correction]
    AS
        /* join all clients with QC_Clarity_BadClients  */
        
        SELECT DISTINCT
            [tbl_Billing Invoice Export All QuickBooks].[Employer Name]
          , qc_clarity_badclients.[Employer Key]
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
                INNER JOIN qc_clarity_badclients ON [tbl_Billing Invoice Export All QuickBooks].[Employer Name] =
                                                    qc_clarity_badclients.[Employer Name]
go

