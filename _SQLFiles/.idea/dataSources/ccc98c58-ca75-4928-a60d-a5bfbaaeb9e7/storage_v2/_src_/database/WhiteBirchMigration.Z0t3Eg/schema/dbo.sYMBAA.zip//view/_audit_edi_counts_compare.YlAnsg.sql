CREATE VIEW _audit_edi_counts_compare
    AS
        SELECT
            new.[ClientName] [new.ClientName]
          , new.[Alternate ER ID] [new.Alternate ER ID]
          , ISNULL( new.[NPM Count] , 0 ) [new.NPM Count]
          , ISNULL( old.[NPM Count] , 0 ) [old.NPM Count]
          , ISNULL( new.[TE Count] , 0 ) [new.TE Count]
          , ISNULL( old.[TE Count] , 0 ) [old.TE Count]
          , ISNULL( new.[TP Count] , 0 ) [new.TP Count]
          , ISNULL( old.[TP Count] , 0 ) [old.TP Count]
          , ISNULL( new.[Final Billable Counts] , 0 ) [new.Final Billable Counts]
          , ISNULL( old.[Final Billable Counts] , 0 ) [old.Final Billable Counts]
          , ISNULL( ISNULL( new.[Final Billable Counts] , 0 ) -
                    ISNULL( old.[Final Billable Counts] , 0 ) ,
                    0 ) diffinfinalbillcounts
          , new.[Suppress] [new.Suppress]
          , old.[Suppress] [old.Suppress]
        FROM
            whitebirchmigration..[tbl_Final EDI Billing Group Counts] AS new
                FULL OUTER JOIN whitebirchmigration_org..[tbl_Final EDI Billing Group Counts] AS old
                                ON new.[ClientName] = old.[ClientName] AND
                                   new.[Alternate ER ID] = old.[Alternate ER ID]
        WHERE
            /* (new.[Final Billable Counts] = old.[Final Billable Counts]
            and new.[NPM Count] <> old.[NPM Count])
        */
            1 = 1
go

