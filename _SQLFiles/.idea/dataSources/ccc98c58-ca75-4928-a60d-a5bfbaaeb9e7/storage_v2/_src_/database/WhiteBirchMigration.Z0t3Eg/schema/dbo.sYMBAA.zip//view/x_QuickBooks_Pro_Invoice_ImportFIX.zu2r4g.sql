CREATE VIEW [dbo].[x_QuickBooks Pro Invoice ImportFIX]
    AS
        /* select some employers from ImportFix  */
        SELECT
            [x_QuickBooks Pro Invoice ImportFIX3].*
        FROM
            [x_QuickBooks Pro Invoice ImportFIX3]
        WHERE
            ((([x_QuickBooks Pro Invoice ImportFIX3].[employer name]) LIKE '%Metropolitan Arts & Antiques Pavilion%' OR
              ([x_QuickBooks Pro Invoice ImportFIX3].[employer name]) LIKE '%OutboundEngine%'))
go

