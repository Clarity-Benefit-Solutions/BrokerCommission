CREATE PROCEDURE dbo.[qry_Append QB TE Count To TE Table] AS

BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        -- ALTER PROCEDURE [qry_Append QB TE Count To TE Table] AS
        INSERT
            INTO [tbl_QB TE Count] (
                                   [Alternate ER ID],
                                   status,
                                   [TE  Count]
        )
        SELECT
            [tbl_QBACADETAILREPORT Staging].[Alternate ER ID]
          , [tbl_QBACADETAILREPORT Staging].status
          , COUNT( [tbl_QBACADETAILREPORT Staging].ssn ) countofssn
        FROM
            [tbl_QBACADETAILREPORT Staging]
                INNER JOIN [tbl_Final EDI Billing Group Counts] ON [tbl_QBACADETAILREPORT Staging].[Alternate ER ID] =
                                                                   [tbl_Final EDI Billing Group Counts].[Alternate ER ID]
        GROUP BY
            [tbl_QBACADETAILREPORT Staging].[Alternate ER ID]
          , [tbl_QBACADETAILREPORT Staging].status
        HAVING
            ((([tbl_QBACADETAILREPORT Staging].status) = 'TE'));;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

