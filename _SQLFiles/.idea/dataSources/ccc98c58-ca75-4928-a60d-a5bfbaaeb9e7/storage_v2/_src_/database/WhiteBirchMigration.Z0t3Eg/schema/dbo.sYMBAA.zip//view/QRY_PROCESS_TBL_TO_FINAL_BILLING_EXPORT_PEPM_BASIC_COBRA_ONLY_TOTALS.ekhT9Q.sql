CREATE VIEW [QRY_PROCESS TBL TO FINAL BILLING EXPORT PEPM BASIC COBRA ONLY TOTALS]
    AS
        SELECT
            [EMPLOYER NAME]
          , [SYSTEM EMPLOYER CODE]
          , [BILLING GROUP]
          , [EMPLOYER KEY]
          , [BROKER CODE]
          , [EMPLOYER BILLING NUMBER]
          , [BROKER NAME]
          , 'PPPM' [BILLING CODE]
          , [KEY_MM MONTHLY MINIMUM]
          , [MONTHLY MINIMUM AMOUNT]
          , [MONTHLY MINIMUM FLG]
          , [PEPM AMOUNT]
          , SUM( ([PEPM AMOUNT]) ) [BILLING AMOUNT]
          , SUM(
                    ([PEPM AMOUNT]) ) [CALCULATED BILLING AMOUNT]
            /*embmerge3*/
          , SUM( [PEPM COUNT] )
                countofuniquekeyparticipant
            --             /*embmerge3 END*/
          , [PAID BY BROKER FLG]
        FROM
            [qry_Process tbl To Final Billing Export PEPM BASIC COBRA ONLY Counts]
        GROUP BY
            [EMPLOYER NAME]
          , [SYSTEM EMPLOYER CODE]
          , [BILLING GROUP]
          , [EMPLOYER KEY]
          , [BROKER CODE]
          , [EMPLOYER BILLING NUMBER]
          , [BROKER NAME]
          , [KEY_MM MONTHLY MINIMUM]
          , [MONTHLY MINIMUM AMOUNT]
          , [MONTHLY MINIMUM FLG]
          , [PEPM AMOUNT]
          , [PEPM COUNT]
          , [PAID BY BROKER FLG]
go

