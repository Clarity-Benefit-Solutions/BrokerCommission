CREATE PROCEDURE [dbo].[_process_billing_all_non_bnd](
                                                    @bappendpppmbenadmin int = 0,
                                                    @b_isforpppm int =0,
                                                    @b_isforbenadmin int =0 ) AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        BEGIN
            
            IF @b_isforpppm = 1 AND @b_isforbenadmin = 0
                BEGIN
                    EXEC [dbo].[qry_Append Process tbl To Final Billing Export PEPM Only]
                END
            ELSE
                IF @b_isforbenadmin = 1
                    BEGIN
                        EXEC [dbo].[qry_Append Process tbl To Final Billing Export EMB];
                    END
                ELSE
                    BEGIN
                        /*embmerge3*/
                        /*  if @b_isforpppm = 2
                              begin
                                  EXEC dbo.[QRY_APPEND PROCESS TBL TO FINAL BILLING EXPORT PEPM BASIC COBRA ONLY];
                              end*/
                        EXEC [dbo].[qry_Append Process tbl To Final Billing Export];
                    END;
            /*     */
            /* sumeet - 2021-03-07 */
            IF @b_isforbenadmin = 0
                BEGIN
                    EXEC [dbo].[qry_Append Process tbl To Final Billing COBRA Notice New];
                    EXEC [dbo].[qry_Append Process tbl To Final Billing COBRA PEPM];
                    EXEC [dbo].[qry_Append Process tbl To Final Billing Export Base-COBRABase];
                    EXEC [dbo].[qry_Append Process tbl To Final Billing Export Debit Card];
                    EXEC [dbo].[qry_Append Process tbl To Final Billing Export ACHCreditNew];
                    /*     */
                    EXEC [dbo].[qry_Append Process tbl To Final Billing Export PlanSetup];
                    EXEC [dbo].[qry_Append Process tbl To Final Billing Export Enavigator];
                    EXEC [dbo].[qry_Append Process tbl To Final Billing Export PLNDOC];
                    EXEC [dbo].[qry_Append Process tbl To Final Billing Export RENEW];
                    /*     */
                    EXEC [dbo].[qry_Append Process tbl To Final Billing Export SPM];
                    /*     */
                    EXEC [dbo].[qry_Append Min conversion records to QB Export Qualify yes];
                    /*     */
                    EXEC [dbo].[qry_Append Invoice PEPM HSA To Min conversion Invoice tbl];
                    EXEC [dbo].[qry_Append Invoice PEPM MED To Min conversion Invoice tbl];
                    EXEC [dbo].[qry_Update Monthly Minimum Converstion tbl greater min];
                    EXEC [dbo].[qry_Append Invoice PEPM HRA To Min conversion Invoice tbl];
                    EXEC [dbo].[qry_Append Invoice PEPM PKGTRN To Min conversion Invoice tbl];
                    /*     */
                    EXEC [dbo].[qry_Append Invoice PEPM COBRA To Min conversion Invoice tbl];
                END
            
            /* sumeet: 2021-03-07 invoice updates MUSTAYS happen - else invoices arte skipped when checking for valid invoicenumber*/
            EXEC [dbo].[QRY_UPDATE BILLING INVOICE EXPORT WITH INVOICE DETAIL];
            EXEC [dbo].[qry_Update Billing Invoice Export with Invoice Number];
            EXEC [dbo].[qry_Update Billing Invoice Export With Biiling Code Description];
            EXEC [dbo].[QRY_UPDATE BILLING INVOICE EXPORT WITH GL ACCOUNTS];
            /*     */
            
            /*     */
            IF @bappendpppmbenadmin = 1
                BEGIN
                    EXEC [dbo].[qry_Append Invoice PEPM BENADMIN To Min conversion Invoice tbl];
                END
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

