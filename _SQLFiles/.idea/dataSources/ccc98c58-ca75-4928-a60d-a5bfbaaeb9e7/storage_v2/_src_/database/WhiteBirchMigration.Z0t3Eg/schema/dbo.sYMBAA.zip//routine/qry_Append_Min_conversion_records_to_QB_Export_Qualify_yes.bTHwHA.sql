CREATE PROCEDURE dbo.[QRY_APPEND MIN CONVERSION RECORDS TO QB EXPORT QUALIFY YES] AS
    /* inserts all [TBL_MONTHLY MINIMUM CONVERSION] records into  [TBL_BILLING INVOICE EXPORT]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT] (
                                              [EMPLOYER NAME],
                                              [EMPLOYER KEY],
                                              [SYSTEM EMPLOYER KEY],
                                              [BILLING GROUP],
                                              [BROKER CODE],
                                              [EMPLOYER BILLING NUMBER],
                                              [BILLING CODE],
                                              [KEY_MM MONTHLY MINIMUM],
                                              [BILLING CODE QB],
                                              [BILLING DESCRIPTION],
                                              [MONTHLY MIN BILLING FLG],
                                              [BILLING AMOUNT],
                                              [BILLING UNIT COUNT],
                                              [BILLING UNIT RATE],
                                              [PAID BY BROKER FLG]
        )
        SELECT
            [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER NAME]
          , [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER KEY]
          , [TBL_MONTHLY MINIMUM CONVERSION].[SYSTEM EMPLOYER CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING GROUP]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BROKER CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER BILLING NUMBER]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[KEY_MM MONTHLY MINIMUM]
          , [TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MIN BILLING CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING DESCRIPTION]
          , 1 [MONTHLY MIN BILLING FLG]
          , [TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MINIMUM AMOUNT]
          , '1' [BILLING UNIT COUNT]
          , ([TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MINIMUM AMOUNT]) [BILLING UNIT RATE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[PAID BY BROKER FLG]
        FROM
            [TBL_MONTHLY MINIMUM CONVERSION]
        GROUP BY
            [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER NAME]
          , [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER KEY]
          , [TBL_MONTHLY MINIMUM CONVERSION].[SYSTEM EMPLOYER CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING GROUP]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BROKER CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER BILLING NUMBER]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[KEY_MM MONTHLY MINIMUM]
          , [TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MIN BILLING CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING DESCRIPTION]
          , [TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MINIMUM AMOUNT]
          , ([TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MINIMUM AMOUNT])
          , [TBL_MONTHLY MINIMUM CONVERSION].[PAID BY BROKER FLG]
          , [TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MIN QUALIFIED];
        
        /* sumeet - added 2021-08-14 add MM also to process table*/
        INSERT
            INTO dbo.[tbl_Process Table] (
                                         [EMPLOYER NAME],
                                         [EMPLOYER KEY],
            -- [EMPLOYER KEY],
                                         [BILLING GROUP],
                                         [BROKER CODE],
                                         [EMPLOYER BILLING NUMBER],
                                         [BILLING CODE],
                                         [KEY_MM MONTHLY MINIMUM],
            --  [BILLING CODE QB],
            -- [BILLING DESCRIPTION],
                                         [MONTHLY MINIMUM FLG],
                                         [PEPM AMOUNT],
                                         [PEPM COUNT],
            --                                               [BILLING UNIT RATE],
                                         [PAID BY BROKER FLG]
        )
        SELECT
            [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER NAME]
          , [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER KEY]
            --           , [TBL_MONTHLY MINIMUM CONVERSION].[SYSTEM EMPLOYER CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING GROUP]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BROKER CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER BILLING NUMBER]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[KEY_MM MONTHLY MINIMUM]
            --           , [TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MIN BILLING CODE]
            --           , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING DESCRIPTION]
          , 1 [MONTHLY MIN BILLING FLG]
          , [TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MINIMUM AMOUNT]
          , '1' [BILLING UNIT COUNT]
            --           , ([TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MINIMUM AMOUNT]) [BILLING UNIT RATE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[PAID BY BROKER FLG]
        FROM
            [TBL_MONTHLY MINIMUM CONVERSION]
        GROUP BY
            [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER NAME]
          , [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER KEY]
          , [TBL_MONTHLY MINIMUM CONVERSION].[SYSTEM EMPLOYER CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING GROUP]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BROKER CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[EMPLOYER BILLING NUMBER]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[KEY_MM MONTHLY MINIMUM]
          , [TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MIN BILLING CODE]
          , [TBL_MONTHLY MINIMUM CONVERSION].[BILLING DESCRIPTION]
          , [TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MINIMUM AMOUNT]
          , ([TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MINIMUM AMOUNT])
          , [TBL_MONTHLY MINIMUM CONVERSION].[PAID BY BROKER FLG]
          , [TBL_MONTHLY MINIMUM CONVERSION].[MONTHLY MIN QUALIFIED];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

