CREATE VIEW [dbo].[Find Staging EC Extract Without Matching tbl_Employer Control]
    AS
        /* select orphaned ECImport recs without matching EmployerCtl entry EmployerKey*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Staging EC Extract].recordtype
          , [tbl_Staging EC Extract].[Employer Id]
        FROM
            [tbl_Staging EC Extract]
                LEFT JOIN [tbl_Employer Control]
                          ON [tbl_Staging EC Extract].[Employer Id] = [tbl_Employer Control].[Employer Key]
        GROUP BY
            [tbl_Employer Control].[Billing Group]
          , [tbl_Staging EC Extract].recordtype
          , [tbl_Staging EC Extract].[Employer Id]
          , [tbl_Staging EC Extract].[Billable Account]
          , [tbl_Employer Control].[Employer Key]
        HAVING
            ((([tbl_Staging EC Extract].[Billable Account]) = 'billable') AND
             (([tbl_Employer Control].[Employer Key]) IS NULL))
go

