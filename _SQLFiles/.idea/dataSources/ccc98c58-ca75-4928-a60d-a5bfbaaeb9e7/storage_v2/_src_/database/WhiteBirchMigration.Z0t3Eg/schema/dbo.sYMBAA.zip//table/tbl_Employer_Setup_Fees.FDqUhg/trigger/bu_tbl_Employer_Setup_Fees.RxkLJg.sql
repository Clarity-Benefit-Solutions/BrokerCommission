CREATE TRIGGER dbo.[bu tbl_Employer Setup Fees]
    ON [tbl_Employer Setup Fees]
    AFTER UPDATE
    AS
BEGIN
    UPDATE [tbl_Employer Setup Fees]
    SET
        [Updated At] = GETDATE( )
    WHERE
            id IN (
                      SELECT DISTINCT
                          ID
                      FROM
                          Inserted
                  );
END
go

