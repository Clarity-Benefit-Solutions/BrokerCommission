CREATE VIEW [QRY_BILLING INVOICE EXPORT REMOVE PEPM MM DUPLICATES]
    AS
        SELECT *
        FROM
            dbo.[tbl_Billing Invoice Export] q2
        WHERE
                CONCAT( [Employer Name] , [Employer Key] , [Billing Code] , q2.[Billing Description]
                    , q2.PROCESSED_GROUP ) IN (
                                                  SELECT
                                                      UK
                                                  FROM
                                                      (
                                                          SELECT
                                                              ROW_NUMBER( )
                                                                      OVER (PARTITION BY [Employer Name] ORDER BY SUM( [Billing Amount] ) DESC) rn
                                                            , [Employer Name]
                                                            , [Billing Code]
                                                            , SUM( [Billing Amount] ) BillingAmount
                                                            , [Employer Key]
                                                            , q2.[Billing Description]
                                                            , q2.PROCESSED_GROUP
                                                            , CONCAT( [Employer Name] , [Employer Key] ,
                                                                      [Billing Code] ,
                                                                      q2.[Billing Description]
                                                                  , q2.PROCESSED_GROUP ) uk
                                
                                                          FROM
                                                              dbo.[tbl_Billing Invoice Export] q2
                                                          WHERE
                                                              [Billing Code] IN ('COBRA', 'COBRA MIN')
                                                          GROUP BY
                                                              [Employer Name]
                                                            , [Employer Key]
                                                            , [Billing Code]
                                                            , q2.[Billing Description]
                                                            , q2.PROCESSED_GROUP
                                                      ) T
                                                  WHERE
                                                      RN > 1
                                              )
go

