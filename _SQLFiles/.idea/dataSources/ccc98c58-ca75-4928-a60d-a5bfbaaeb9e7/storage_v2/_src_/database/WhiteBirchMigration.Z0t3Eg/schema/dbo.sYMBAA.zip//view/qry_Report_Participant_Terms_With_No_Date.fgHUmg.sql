CREATE VIEW [dbo].[qry_Report Participant Terms With No Date]
    AS
        /* list EmplCtl employees who are terminated but there is no termination date and AcType = 'HSA' and are marked for Process*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Staging Accounts].[Employer Code]
          , [tbl_Staging Accounts].[Employee Number]
          , [tbl_Staging Accounts].[Participant Last Name]
          , [tbl_Staging Accounts].[Participant First Name]
          , [tbl_Staging Accounts].[Termination Date txt]
          , [tbl_Staging Accounts].[Participant Term Date txt]
          , [tbl_Staging Accounts].[Participant Status]
        FROM
            [tbl_Staging Accounts]
                INNER JOIN [tbl_Employer Control]
                           ON [tbl_Staging Accounts].[Employer Code] = [tbl_Employer Control].[Employer Key]
        WHERE
            ((([tbl_Staging Accounts].[Account Type]) <> 'HSA'))
        GROUP BY
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Staging Accounts].[Employer Code]
          , [tbl_Staging Accounts].[Employee Number]
          , [tbl_Staging Accounts].[Participant Last Name]
          , [tbl_Staging Accounts].[Participant First Name]
          , [tbl_Staging Accounts].[Termination Date txt]
          , [tbl_Staging Accounts].[Participant Term Date txt]
          , [tbl_Staging Accounts].[Participant Status]
          , [tbl_Employer Control].process
        HAVING
            ((([tbl_Staging Accounts].[Participant Term Date txt]) IS NULL) AND
             (([tbl_Staging Accounts].[Participant Status]) = 'TERMINATED') AND (([tbl_Employer Control].process) = 1))
go

