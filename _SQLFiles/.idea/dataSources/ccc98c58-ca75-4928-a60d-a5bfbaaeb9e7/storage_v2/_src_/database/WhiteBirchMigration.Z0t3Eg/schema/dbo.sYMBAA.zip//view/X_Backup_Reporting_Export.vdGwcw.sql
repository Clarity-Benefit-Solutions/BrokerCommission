CREATE VIEW [dbo].[X_Backup Reporting Export] AS
    /* Liat all backup reporting records */
    SELECT
        [Billing Group]
      , [Employer Key]
      , [Employer Name]
      , [Division]
      , [Backup Invoice Number]
      , [BILLING CODE]
      , [Billing Description]
      , [Last Name]
      , [First Name]
      , [Participant Status]
      , [Participant Term Date]
      , [PEPM]
      , [PEPM Amount]
      , [ORIGINAL EMPLOYER NAME]
    FROM
        [X_Backup Reporting Export_csv]
go

