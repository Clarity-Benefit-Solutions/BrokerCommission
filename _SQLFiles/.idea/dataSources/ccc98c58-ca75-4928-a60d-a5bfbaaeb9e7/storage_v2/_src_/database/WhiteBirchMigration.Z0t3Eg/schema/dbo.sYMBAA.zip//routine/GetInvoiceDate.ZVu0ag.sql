CREATE FUNCTION dbo.GetInvoiceDate( ) RETURNS date AS
    /* simulate missing Access fn */
BEGIN
    DECLARE @datecastvalue date = NULL;
    
    SELECT TOP 1
        @datecastvalue = [Invoice Date]
    FROM
        [tbl_Invoice Date Table];
    
    RETURN @datecastvalue;

END
go

