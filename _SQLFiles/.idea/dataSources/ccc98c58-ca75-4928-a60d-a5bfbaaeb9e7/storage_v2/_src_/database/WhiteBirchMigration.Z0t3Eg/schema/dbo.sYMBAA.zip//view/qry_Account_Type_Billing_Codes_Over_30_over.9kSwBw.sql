CREATE VIEW [dbo].[qry_Account Type Billing Codes Over 30 over]
    AS
        /* 10 characters of [QB Billing Item Code] after character 30 from BillingCodesMSt   */
        SELECT
            [tbl_Account Type Billing Codes].[Account Type]
          , [tbl_Account Type Billing Codes].[Billing Code]
          , [tbl_Account Type Billing Codes].[QB Billing Item Code]
          , [tbl_Account Type Billing Codes].[Billing Code Description]
          , [tbl_Account Type Billing Codes].[QB CO]
          , [tbl_Account Type Billing Codes].added
          , SUBSTRING( [tbl_Account Type Billing Codes].[QB Billing Item Code] , 30 , 10 ) [30 Plus]
        FROM
            [tbl_Account Type Billing Codes]
go

