CREATE FUNCTION dbo.IsInCurrentBillingPeriod(
    @val date ) RETURNS bit AS
    BEGIN
        DECLARE @BillingPeriod date;
        DECLARE @BillingStart date;
        DECLARE @BillingEnd date;
        
        SELECT
            @BillingPeriod = [Billing Date Month]
        FROM
            [tbl_Invoice Date Table];
        
        SELECT
            @BillingStart = DATEADD( DD , 1 , EOMONTH( @BillingPeriod , -1 ) )
          , @BillingEnd = EOMONTH( @BillingPeriod );
        
        IF @val IS NOT NULL AND @val >= @BillingStart AND @val <= @BillingEnd
            BEGIN
                RETURN 1
            END
        
        RETURN 0;
    END
go

