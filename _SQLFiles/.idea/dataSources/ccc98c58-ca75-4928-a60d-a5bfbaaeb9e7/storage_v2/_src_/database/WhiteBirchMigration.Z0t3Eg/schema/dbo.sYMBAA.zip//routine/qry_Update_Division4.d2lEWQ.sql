CREATE PROCEDURE dbo.[QRY_UPDATE DIVISION4] AS
    /* update Process set [Employer Name] =  EmpCtl.[Employer Name] joined on [Division Billing Key]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_PROCESS TABLE]
        SET
            [TBL_PROCESS TABLE].[EMPLOYER NAME] = [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
        FROM
            [TBL_PROCESS TABLE]
                INNER JOIN [TBL_EMPLOYER CONTROL] ON [TBL_PROCESS TABLE].[DIVISION BILLING KEY] =
                                                     [TBL_EMPLOYER CONTROL].[DIVISION BILLING KEY];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

