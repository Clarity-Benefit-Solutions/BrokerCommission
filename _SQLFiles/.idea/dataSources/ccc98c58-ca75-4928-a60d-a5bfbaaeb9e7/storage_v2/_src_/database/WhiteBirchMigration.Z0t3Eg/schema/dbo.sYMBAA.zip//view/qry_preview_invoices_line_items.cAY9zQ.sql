CREATE VIEW qry_preview_invoices_line_items
    AS
        SELECT
            [Employer Name]
          , [Employer Key]
          , [Invoice Number]
          , [Billing Code QB]
          , [Billing Description]
          , [Billing Unit Count]
          , [Billing Unit Rate]
          , [Billing Amount]
        FROM
            whitebirchmigration..[x_QuickBooks Pro Invoice Import All]
go

