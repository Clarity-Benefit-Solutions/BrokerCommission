CREATE PROCEDURE dbo.[QRY_UPDATE STAGING ACCOUNTS WITH TERM RUNOUT DAYS] AS
    /* update StagingAccts set [Plan Term Runout] = Edi5Staging.[Term Runout Date]joined on bencode and plan date fields */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_STAGING ACCOUNTS]
        SET
            [TBL_STAGING ACCOUNTS].[PLAN TERM RUNOUT] = ([TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].[TERM RUNOUT DATE])
        FROM
            [TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT]
                INNER JOIN [TBL_STAGING ACCOUNTS] ON ([TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].[ACCOUNT TYPE CODE] =
                                                      [TBL_STAGING ACCOUNTS].[EC ACCOUNT TYPE]) AND
                                                     ([TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].[PLAN END DATE] =
                                                      [TBL_STAGING ACCOUNTS].[PLAN END DATE TXT]) AND
                                                     ([TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].[PY START DATE] =
                                                      [TBL_STAGING ACCOUNTS].[PLAN START DATE TXT]) AND
                                                     ([TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].bencode =
                                                      [TBL_STAGING ACCOUNTS].[EMPLOYER CODE]);
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

