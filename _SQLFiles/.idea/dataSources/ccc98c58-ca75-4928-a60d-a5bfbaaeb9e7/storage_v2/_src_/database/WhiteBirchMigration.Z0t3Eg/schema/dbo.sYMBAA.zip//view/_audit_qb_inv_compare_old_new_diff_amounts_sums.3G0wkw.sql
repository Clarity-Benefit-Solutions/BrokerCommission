CREATE VIEW _audit_qb_inv_compare_old_new_diff_amounts_sums AS
    SELECT
        [Billing Group Process]
      , RecordID
      , PROCESSED_GROUP
      , [Employer Name]
      , [Employer Key]
      , [old_Billing Description]
      , [new_Billing Description]
      , [Billing Code QB]
      , SUM( [new_Billing Amount] ) - SUM( [old_Billing Amount] ) DiffInAmount
      , SUM( [new_Billing Amount] ) [new_Billing Amount]
      , SUM( [old_Billing Amount] ) [old_Billing Amount]
      , SUM( dbo.CMoney( [new_Billing Unit Count] ) ) [new_Billing Unit Count]
      , SUM( dbo.CMoney( [old_Billing Unit Count] ) ) [old_Billing Unit Count]
    FROM
        _audit_qb_inv_compare_old_new_diff_amounts
    GROUP BY
        [Billing Group Process]
      , [Employer Name]
      , [Employer Key]
      , [old_Billing Description]
      , [new_Billing Description]
      , [Billing Code QB]
      , RecordID
      , PROCESSED_GROUP
go

