CREATE VIEW [dbo].[CLARITY_BillableClientPlansfromEC]
    AS
        /* all EC import billable clients   */
        SELECT DISTINCT
            [tbl_Staging EC Extract].[Billable Account]
          , LTRIM( RTRIM( LEFT( [Employer Id] , 10 ) ) ) bencode
          , [tbl_Staging EC Extract].[Account Type Code]
          , [tbl_Staging EC Extract].[Plan Id]
          , (CAST( LEFT( [tbl_Staging EC Extract].[Plan Start Date] , 4 ) + '/' +
                   SUBSTRING( [tbl_Staging EC Extract].[Plan Start Date] , 5 , 2 ) + '/' +
                   RIGHT( [tbl_Staging EC Extract].[Plan Start Date] , 2 ) AS datetime )) plan_start
          , (CAST( LEFT( [tbl_Staging EC Extract].[Plan end Date] , 4 ) + '/' +
                   SUBSTRING( [tbl_Staging EC Extract].[Plan end Date] , 5 , 2 ) + '/' +
                   RIGHT( [tbl_Staging EC Extract].[Plan end Date] , 2 ) AS datetime )) plan_end
        FROM
            [tbl_Staging EC Extract]
        WHERE
            ((([tbl_Staging EC Extract].[Billable Account]) = 'billable'))
go

exec sp_addextendedproperty 'MS_SSMA_SOURCE' , N'ClarityAuditSystemv4.[CLARITY_BillableClientPlansfromEC]' , 'SCHEMA' ,
     'dbo' , 'VIEW' , 'CLARITY_BillableClientPlansfromEC'
go

