CREATE PROCEDURE dbo.[QRY_UPDATE MIN REMOVE FLAG IN EXPORT TBL PEPM GREATER MIN] AS
    /* update InvExp.[Monthly Min To Delete] = 1 from MonthlyMinConvInv
       where Monthly Min Greater]) = 0 and
            Billing Code QB]) = 'Monthly Minimum Fee' OR [Billing Code QB]) = 'COBRA Monthly Minimum Fee')
   */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        
        /* sumeet: this seems to be not needed - it just deletes the PEPM actual data*/
        --
        /* this is the problem for not billing min/pepm fees!! it updates too many records*/
        UPDATE i
        SET
            i.[MONTHLY MIN TO DELETE] = 1
        FROM
            [TBL_MONTHLY MINIMUM CONVERSION INVOICE] m
                INNER JOIN [TBL_BILLING INVOICE EXPORT] i ON m.[EMPLOYER KEY] =
                                                             i.[EMPLOYER KEY] and i.[Billing Code] = m.[BILLING CODE]
        WHERE
            /* embmerge3*/ /* its not really deleting the min fee is pepm was more! - will require a final filtering perhaps?*/
              m.[MONTHLY MIN GREATER] = 0
          AND (i.[BILLING CODE QB] = 'Monthly Minimum Fee' or
               i.[BILLING CODE QB] = 'COBRA Monthly Minimum Fee')
          and i.[Billing Amount] <=
              i.[Calculated Billing Amount]
        /* ((([TBL_MONTHLY MINIMUM CONVERSION INVOICE].[MONTHLY MIN GREATER]) = 0) AND
        (([TBL_BILLING INVOICE EXPORT].[BILLING CODE QB]) = 'Monthly Minimum Fee' OR
         ([TBL_BILLING INVOICE EXPORT].[BILLING CODE QB]) = 'COBRA Monthly Minimum Fee'))*/;
        
        /* embmerge3 END*/
        
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

