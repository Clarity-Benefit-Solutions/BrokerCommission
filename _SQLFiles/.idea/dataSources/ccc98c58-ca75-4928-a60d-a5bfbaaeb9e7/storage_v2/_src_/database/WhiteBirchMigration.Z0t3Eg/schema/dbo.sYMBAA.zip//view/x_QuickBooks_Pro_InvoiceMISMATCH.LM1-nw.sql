CREATE VIEW [dbo].[x_QuickBooks Pro InvoiceMISMATCH]
    AS
        /* liat all invexp records that are marked for monthlyexclude*/
        SELECT DISTINCT
            [tbl_Billing Invoice Export All QuickBooks].[Employer Name]
          , monthlyexclude.[Employer Name] em2
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
                RIGHT JOIN monthlyexclude
                           ON [tbl_Billing Invoice Export All QuickBooks].[Employer Name] =
                              monthlyexclude.[Employer Name]
        WHERE
            ((([tbl_Billing Invoice Export All QuickBooks].[Employer Name]) IS NOT NULL))
go

