--WARNING! ERRORS ENCOUNTERED DURING SQL PARSING!
--WARNING! ERRORS ENCOUNTERED DURING SQL PARSING!
    CREATE FUNCTION [dbo].alphanumeric(
    @string nvarchar(max) ) RETURNS nvarchar(max)
    BEGIN
        RETURN REPLACE( dbo.[StripSpChars]( @string ) , ' ' , '' );
    END
go

