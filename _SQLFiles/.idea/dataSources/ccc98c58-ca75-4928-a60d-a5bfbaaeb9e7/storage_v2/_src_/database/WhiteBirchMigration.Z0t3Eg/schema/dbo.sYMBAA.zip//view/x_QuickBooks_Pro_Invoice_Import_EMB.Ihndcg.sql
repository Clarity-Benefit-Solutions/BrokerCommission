CREATE VIEW [dbo].[x_QuickBooks Pro Invoice Import_EMB]
    AS
        /* Liat all InvExp records for EMB import
           i.e.
           [Employer Name]) <> 'Wall Financial-Able Medical Transportation' AND
              [Employer Name]) <> 'AFLAC - Odyssey Logistics & Technology Corp') AND
             [Billing Code QB]) <> 'Alegeus ACH Error Credit') AND
             [Billing Group]) LIKE EMB%'*/
        SELECT
            [tbl_Billing Invoice Export All QuickBooks].[Employer Name]
          , [tbl_Billing Invoice Export All QuickBooks].[Employer Key]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Code QB]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Description]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Unit Count]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Unit Rate]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Amount]
          , [tbl_Billing Invoice Export All QuickBooks].[Invoice Number]
          , [tbl_Billing Invoice Export All QuickBooks].[Invoice Date]
          , [tbl_Billing Invoice Export All QuickBooks].[Invoice Due Date]
          , [tbl_Billing Invoice Export All QuickBooks].terms
          , [tbl_Billing Invoice Export All QuickBooks].[Customer Message]
          , [tbl_Billing Invoice Export All QuickBooks].[Billing Period]
          , [tbl_Billing Invoice Export All QuickBooks].[GL Receivable Account]
          , [tbl_Billing Invoice Export All QuickBooks].[GL Expense Account]
          , [tbl_Billing Invoice Export All QuickBooks].[To Email]
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
        WHERE
            ((([tbl_Billing Invoice Export All QuickBooks].[Employer Name]) <>
              'Wall Financial-Able Medical Transportation' AND
              ([tbl_Billing Invoice Export All QuickBooks].[Employer Name]) <>
              'AFLAC - Odyssey Logistics & Technology Corp') AND
             (([tbl_Billing Invoice Export All QuickBooks].[Billing Code QB]) <> 'Alegeus ACH Error Credit')
                AND /* sumeet: EMBMERGE*/
                /*   [BILLING GROUP]) NOT LIKE  '%EMB%' */ processed_group NOT LIKE '%BEN ADMIN%'
                /* sumeet END*/
                )
go

