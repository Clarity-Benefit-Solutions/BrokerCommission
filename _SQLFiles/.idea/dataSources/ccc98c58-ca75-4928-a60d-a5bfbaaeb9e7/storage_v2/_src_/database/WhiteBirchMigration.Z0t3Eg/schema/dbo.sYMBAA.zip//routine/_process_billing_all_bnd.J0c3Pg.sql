CREATE PROCEDURE [dbo].[_process_billing_all_bnd] AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        BEGIN
            
            EXEC dbo.[qry_Append Process tbl To Final Billing Export Bundle];
            EXEC dbo.[qry_Append Process tbl To Final Billing Export Bundle NonQual];
            EXEC dbo.[qry_Append Process tbl To Final Billing Export Bundle NonQual2];
            EXEC dbo.[qry_Append Process tbl To Final Billing Export Bundle NonBND];
            EXEC dbo.[qry_Append Process tbl To Final Billing Export ACHCreditNew];
            EXEC dbo.[qry_Append Process tbl To Final Billing Export PlanSetup];
            EXEC dbo.[qry_Append Process tbl To Final Billing Export Enavigator];
            EXEC dbo.[qry_Append Process tbl To Final Billing Export PLNDOC];
            EXEC dbo.[qry_Append Process tbl To Final Billing Export RENEW];
            EXEC dbo.[qry_Append Process tbl To Final Billing Export SPM];
            EXEC dbo.[qry_Append Min conversion records to QB Export Qualify yes];
            EXEC dbo.[qry_Update Billing Invoice Export with Invoice Detail];
            EXEC dbo.[qry_Update Billing Invoice Export with Invoice Number];
            EXEC dbo.[qry_Update Billing Invoice Export With Biiling Code Description];
            EXEC dbo.[qry_Update Billing Invoice Export with GL Accounts];
            EXEC dbo.[qry_Append Invoice PEPM HSA To Min conversion Invoice tbl];
            EXEC dbo.[qry_Append Invoice PEPM MED To Min conversion Invoice tbl];
            EXEC dbo.[qry_Append Invoice PEPM HRA To Min conversion Invoice tbl];
            EXEC dbo.[qry_Append Invoice PEPM PKGTRN To Min conversion Invoice tbl];
            EXEC dbo.[qry_Append Invoice PEPM COBRA To Min conversion Invoice tbl];
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

