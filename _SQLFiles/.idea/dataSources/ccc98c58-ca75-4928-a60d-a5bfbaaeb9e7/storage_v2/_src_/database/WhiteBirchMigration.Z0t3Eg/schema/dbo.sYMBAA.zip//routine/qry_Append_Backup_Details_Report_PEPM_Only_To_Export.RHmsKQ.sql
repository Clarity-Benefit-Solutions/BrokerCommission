CREATE PROCEDURE dbo.[QRY_APPEND BACKUP DETAILS REPORT PEPM ONLY TO EXPORT] AS
    /* inserts all Process rows NOT matching 'bundle' to BackupReporting */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BACKUP REPORTING EXPORT TABLE] (
                                                     RowId,
                                                     [EMPLOYER KEY],
                                                     [EMPLOYER NAME],
                                                     [BACKUP INVOICE NUMBER],
                                                     [BILLING CODE],
                                                     [BILLING DESCRIPTION],
                                                     [LAST NAME],
                                                     [FIRST NAME],
                                                     [PARTICIPANT STATUS],
                                                     [PARTICIPANT TERM DATE],
                                                     [PEPM FLG],
            
                                                     pepm,
                                                     [PEPM AMOUNT],
                                                     [BILLING GROUP],
                                                     division,
                                                     [ORIGINAL EMPLOYER NAME],
                                                     [BND_BILLING CODE],
                                                     [ACTUAL_BILLING CODE],
                                                     [Billing Group Process],
                                                     UniqueKeyParticipant
        )
        SELECT
            COUNT( * )
          , [EMPLOYER KEY]
          , [EMPLOYER NAME]
          , [BACKUP INVOICE NUMBER]
          , ([QB BILLING CODE]) [BILLING CODE]
          , ([QB BILLING CODE DESCRIPTION]) [BILLING DESCRIPTION]
          , [LAST NAME]
          , [FIRST NAME]
          , [PARTICIPANT STATUS]
          , [PARTICIPANT TERM DATE]
          , [PEPM FLG]
          , CASE
                WHEN [PEPM FLG] = 1 THEN SUM( CASE
                                                  WHEN [PEPM COUNT] > 0 THEN [PEPM COUNT]
                                                  ELSE 1
                                              END )
                ELSE MAX( [PEPM COUNT] )
            END units
          , CASE
                WHEN [PEPM FLG] = 1 THEN SUM( CASE
                                                  WHEN [PEPM COUNT] > 0 THEN [PEPM COUNT]
                                                  ELSE 1
                                              END * [PEPM AMOUNT] )
                ELSE MAX( [PEPM AMOUNT] )
            END amount
            --           , [PEPM COUNT]
            --           , [PEPM AMOUNT]
          , [BILLING GROUP]
          , MAX( division )
          , [ORIGINAL EMPLOYER NAME]
          , [BND_BILLING CODE]
          , [BILLING CODE]
          , [Billing Group Process]
          , UniqueKeyParticipant
        FROM
            [TBL_PROCESS TABLE ALL BACKUP]
        WHERE
              ((([BILLING GROUP PROCESS]) <> 'Bundle'))
        GROUP BY
            [EMPLOYER KEY]
          , [EMPLOYER NAME]
          , [BACKUP INVOICE NUMBER]
          , ([QB BILLING CODE])
          , ([QB BILLING CODE DESCRIPTION])
          , [LAST NAME]
          , [FIRST NAME]
          , [PARTICIPANT STATUS]
          , [PARTICIPANT TERM DATE]
            --           , [PEPM COUNT]
            --           , [PEPM AMOUNT]
          , [BILLING GROUP]
          , uniquekeyparticipant
            --           ,  division
          , [ORIGINAL EMPLOYER NAME]
          , [PEPM FLG]
          , [BND_BILLING CODE]
          , [BILLING CODE]
          , [Billing Group Process];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        INSERT
            INTO dbo.db_error_log(
                                 sql_state,
                                 err_no,
                                 err_source,
                                 err_msg
        )
        VALUES (
               ERROR_SEVERITY( ),
               '' + ERROR_NUMBER( ),
               ERROR_PROCEDURE( ),
               CAST( ERROR_LINE( ) AS nvarchar ) + ' - ' + ERROR_MESSAGE( )
               );
    END CATCH;
END;
go

