CREATE VIEW [dbo].[X_Backup Reporting Export_csv]
AS
    /* Liat all backup reporting records for export to csv*/
    SELECT
        [Billing Group]
      , [Employer Key]
      , [Employer Name]
      , division
      , [Backup Invoice Number] [Invoice Number]
      , [Backup Invoice Number]
      , [BILLING CODE]
      , [Billing Description]
      , [Last Name]
      , [First Name]
      , [Participant Status]
      , [Participant Term Date]
      , pepm
      , pepm pepm_count
      , [PEPM Amount]
      , [PEPM Amount] pepm_amount
      , [ORIGINAL EMPLOYER NAME]
    FROM
        [tbl_Backup Reporting Export Table]
    WHERE
        ISNULL( ToDelete , 0 ) <> 1
go

