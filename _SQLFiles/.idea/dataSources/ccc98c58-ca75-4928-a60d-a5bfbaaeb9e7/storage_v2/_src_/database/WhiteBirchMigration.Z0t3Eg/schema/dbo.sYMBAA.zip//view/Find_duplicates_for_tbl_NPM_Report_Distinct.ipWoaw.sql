CREATE VIEW [Find duplicates for tbl_NPM Report Distinct]
    AS
        SELECT
            [tbl_NPM Report Distinct].[NPM UniqueKey]
          , [tbl_NPM Report Distinct].clientname
          , [tbl_NPM Report Distinct].include
          , [tbl_NPM Report Distinct].divisionname
          , [tbl_NPM Report Distinct].fullname
          , [tbl_NPM Report Distinct].ssn
          , [tbl_NPM Report Distinct].coveragelevel
          , [tbl_NPM Report Distinct].address
          , [tbl_NPM Report Distinct].address2
          , [tbl_NPM Report Distinct].city
          , [tbl_NPM Report Distinct].stateorprovince
          , [tbl_NPM Report Distinct].postalcode
          , [tbl_NPM Report Distinct].country
          , [tbl_NPM Report Distinct].pdfgenerateddatetime
          , [tbl_NPM Report Distinct].individualidentifier
          , [tbl_NPM Report Distinct].type
          , [tbl_NPM Report Distinct].memberid
          , [tbl_NPM Report Distinct].[Is Paylocity]
          , [tbl_NPM Report Distinct].[Alternate ER ID]
        FROM
            [tbl_NPM Report Distinct]
        WHERE
            ((([tbl_NPM Report Distinct].[NPM UniqueKey]) IN (
                                                                 SELECT
                                                                     [NPM UniqueKey]
                                                                 FROM
                                                                     [tbl_NPM Report Distinct] AS tmp
                                                                 GROUP BY
                                                                     [NPM UniqueKey]
                                                                 HAVING
                                                                     COUNT( * ) > 1
                                                             )))
go

exec sp_addextendedproperty 'MS_SSMA_SOURCE' ,
     N'Admin_1COBRA_EDI_Counter_vc0825.[Find duplicates for tbl_NPM Report Distinct]' , 'SCHEMA' , 'dbo' , 'VIEW' ,
     'Find duplicates for tbl_NPM Report Distinct'
go

