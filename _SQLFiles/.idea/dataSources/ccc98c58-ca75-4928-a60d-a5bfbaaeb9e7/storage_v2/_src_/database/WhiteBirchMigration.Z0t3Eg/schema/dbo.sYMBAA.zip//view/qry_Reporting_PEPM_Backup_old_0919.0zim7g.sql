CREATE VIEW [dbo].[qry_Reporting PEPM Backup old 0919]
    AS
        /* list all ProcessBackupRecords */
        SELECT DISTINCT
            [tbl_Process Table All Backup].[Billing Group]
          , [tbl_Process Table All Backup].[Employer Key]
          , [tbl_Process Table All Backup].[Employer Name]
          , [tbl_Process Table All Backup].[BILLING CODE]
          , ([tbl_Process Table All Backup].[Plan Name]) [Billing Description]
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].division
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , [tbl_Process Table All Backup].[PEPM COUNT]
          , [tbl_Process Table All Backup].[PEPM AMOUNT]
          , [tbl_Process Table All Backup].uniquekeyparticipant
        FROM
            [tbl_Process Table All Backup]
go

