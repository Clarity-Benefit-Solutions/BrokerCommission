CREATE VIEW [QRY_BILLING INVOICE EXPORT QUICK BOOKS GET MM PEPM Totals]
AS
    SELECT
        [Employer Name]
      , [Original Employer Name]
        --           , [Billing Code]
        --           , [Billing Code QB]
        --           , [Billing Description]
        --           , [Billing Amount]
      , dbo.get_cobra_mm_amount( [Employer Name] , [Original Employer Name] ) COBRA_MM
      , dbo.get_cobra_pepm_amount( [Employer Name] , [Original Employer Name] ) COBRA_PEPM
      , dbo.get_benadm_mm_amount( [Employer Name] , [Original Employer Name] ) BENADMIN_MM
      , dbo.get_benadm_pepm_amount( [Employer Name] , [Original Employer Name] ) BENADMIN_PEPM
      , dbo.get_en_mm_amount( [Employer Name] , [Original Employer Name] ) EN_MM
      , dbo.get_en_pepm_amount( [Employer Name] , [Original Employer Name] ) EN_PEPM
      , dbo.get_alegeus_mm_amount( [Employer Name] , [Original Employer Name] , 'FSA' ) FSA_MM
      , dbo.get_alegeus_pepm_amount( [Employer Name] , [Original Employer Name] , 'FSA' ) FSA_PEPM
      , dbo.get_alegeus_mm_amount( [Employer Name] , [Original Employer Name] , 'HRA' ) HRA_MM
      , dbo.get_alegeus_pepm_amount( [Employer Name] , [Original Employer Name] , 'HRA' ) HRA_PEPM
      , dbo.get_alegeus_mm_amount( [Employer Name] , [Original Employer Name] , 'HSA' ) HSA_MM
      , dbo.get_alegeus_pepm_amount( [Employer Name] , [Original Employer Name] , 'HSA' ) HSA_PEPM
      , dbo.get_alegeus_mm_amount( [Employer Name] , [Original Employer Name] , 'TRN' ) TRN_MM
      , dbo.get_alegeus_pepm_amount( [Employer Name] , [Original Employer Name] , 'PKGTRN' ) TRN_PEPM
    FROM
        dbo.[tbl_Billing Invoice Export All QuickBooks]
  /*  WHERE
        ([Billing Code] IN ('COBRA MIN',
                            'COBRA',
                            'BENADMIN MIN',
                            'BENADMBE', 'BENADMNBE',
                            'ENBENADMIN',
                            'ENPEPM')
            OR (/* for broker billing,the billing codes are appended after employer key*/
                   [Original Employer Name] <> [Employer Name] and  [Billing Code] IN ('%COBRA MIN',
                                        '%COBRA',
                                        '%BENADMIN MIN',
                                        '%BENADMBE', '%BENADMNBE',
                                        '%ENBENADMIN',
                                        '%ENPEPM')  )
            OR [Billing Code] LIKE '% Monthly Min'
            OR [Billing Code] IN ('FSA', 'MED', 'HRA', 'HSA', 'TRN')
            )*/
    GROUP BY
        [Employer Name]
      , [Original Employer Name]
go

