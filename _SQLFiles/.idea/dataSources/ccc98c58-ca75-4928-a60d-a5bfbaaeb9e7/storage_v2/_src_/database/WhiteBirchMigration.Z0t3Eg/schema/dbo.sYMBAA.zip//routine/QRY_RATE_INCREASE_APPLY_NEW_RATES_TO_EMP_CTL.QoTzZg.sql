CREATE PROCEDURE dbo.[QRY_RATE INCREASE APPLY NEW RATES TO EMP CTL] AS
BEGIN
    
    DECLARE @msg1 nvarchar(max)
    DECLARE @rowno int = 0
    DECLARE @continue int = 0
    DECLARE @sql1 nvarchar(4000)
    DECLARE @sql2 nvarchar(4000)
    /**/
    DECLARE @EmployerName nvarchar(255);
    DECLARE @BenCode nvarchar(255);
    DECLARE @RecordID int;
    DECLARE @ACA_ACAADMINPEPMAMOUNT nvarchar(255);
    DECLARE @BASE_FEEAmount nvarchar(255);
    DECLARE @BEN_BENADMINPEPMAMOUNT nvarchar(255);
    DECLARE @BEN_BENADMIN_MONTHLYMINIMUMAMOUNT nvarchar(255);
    DECLARE @BND_BUNDLERATEAMOUNT nvarchar(255);
    DECLARE @COBRABASE_FEEAmount nvarchar(255);
    DECLARE @COBRA_MONTHLYMINIMUMAMOUNT nvarchar(255);
    DECLARE @COBRA_PEPMAMOUNT nvarchar(255);
    DECLARE @COBRA_PERNOTICEFLGAMOUNT nvarchar(255);
    DECLARE @DCF_NEWCARDAMOUNT nvarchar(255);
    DECLARE @DCF_RPLACECARDAMOUNT nvarchar(255);
    DECLARE @FLT_FLATRATEAMOUNT nvarchar(255);
    DECLARE @FSA_MONTHLYMINIMUMAMOUNT nvarchar(255);
    DECLARE @FSA_PEPMAMOUNT nvarchar(255);
    DECLARE @HRA_MONTHLYMINIMUMAMOUNT nvarchar(255);
    DECLARE @HRA_PEPMAMOUNT nvarchar(255);
    DECLARE @HSA_MONTHLYMINIMUMAMOUNT nvarchar(255);
    DECLARE @HSA_PEPMAMOUNT nvarchar(255);
    DECLARE @LPF_MONTHLYMINIMUMAMOUNT nvarchar(255);
    DECLARE @LPF_PEPMAMOUNT nvarchar(255);
    DECLARE @NONBEN_NONBENADMINPEPMAMOUNT nvarchar(255);
    DECLARE @PLD_PLANDOCUMENTAMOUNT nvarchar(255);
    DECLARE @REN_ANNUALRENEWALAMOUNT nvarchar(255);
    DECLARE @SPM_MONTHLYMINIMUMAMOUNT nvarchar(255);
    DECLARE @SPM_PEPMAMOUNT nvarchar(255);
    DECLARE @TRN_MONTHLYMINIMUMAMOUNT nvarchar(255);
    DECLARE @TRN_PEPMAMOUNT nvarchar(255);
    
    SET @continue = 1
    
    DECLARE db_cursor CURSOR FOR
        SELECT /*TOP 3*/
            EmployerName
          , BenCode
          , RecordID
          , [ACA_ACAADMIN PEPM AMOUNT]
          , [BASE_FEE Amount]
          , [BEN_BEN ADMIN PEPM AMOUNT]
          , [BEN_BEN ADMIN_MONTHLY MINIMUM AMOUNT]
          , [BND_BUNDLE RATE AMOUNT]
          , [COBRA BASE_FEE Amount]
          , [COBRA_MONTHLY MINIMUM AMOUNT]
          , [COBRA_PEPM AMOUNT]
          , [COBRA_PER NOTICE FLG AMOUNT]
          , [DCF_NEW CARD AMOUNT]
          , [DCF_RPLACE CARD AMOUNT]
          , [FLT_FLAT RATE AMOUNT]
          , [FSA_MONTHLY MINIMUM AMOUNT]
          , [FSA_PEPM AMOUNT]
          , [HRA_MONTHLY MINIMUM AMOUNT]
          , [HRA_PEPM AMOUNT]
          , [HSA_MONTHLY MINIMUM AMOUNT]
          , [HSA_PEPM AMOUNT]
          , [LPF_MONTHLY MINIMUM AMOUNT]
          , [LPF_PEPM AMOUNT]
          , [NONBEN_NONBEN ADMIN PEPM AMOUNT]
          , [PLD_PLAN DOCUMENT AMOUNT]
          , [REN_ANNUAL RENEWAL AMOUNT]
          , [SPM_MONTHLY MINIMUM AMOUNT]
          , [SPM_PEPM AMOUNT]
          , [TRN_MONTHLY MINIMUM AMOUNT]
          , [TRN_PEPM AMOUNT]
        FROM
            dbo.[tbl_Employer Control Rate Increase Pct]
        WHERE
              1 = 1
--           AND RecordID IN (2717)
        ORDER BY
            [EmployerName];
    
    EXEC db_log_message 'QRY_RATE INCREASE APPLY NEW RATES TO EMP CTL' ,
         ' OPENING CURSOR' ,
         'INFO';
    
    /**/
    OPEN db_cursor
    /**/
    
    WHILE @continue = 1 BEGIN
        FETCH NEXT FROM db_cursor INTO
            @EmployerName,
            @BenCode,
            @RecordID,
            @ACA_ACAADMINPEPMAMOUNT,
            @BASE_FEEAmount,
            @BEN_BENADMINPEPMAMOUNT,
            @BEN_BENADMIN_MONTHLYMINIMUMAMOUNT,
            @BND_BUNDLERATEAMOUNT,
            @COBRABASE_FEEAmount,
            @COBRA_MONTHLYMINIMUMAMOUNT,
            @COBRA_PEPMAMOUNT,
            @COBRA_PERNOTICEFLGAMOUNT,
            @DCF_NEWCARDAMOUNT,
            @DCF_RPLACECARDAMOUNT,
            @FLT_FLATRATEAMOUNT,
            @FSA_MONTHLYMINIMUMAMOUNT,
            @FSA_PEPMAMOUNT,
            @HRA_MONTHLYMINIMUMAMOUNT,
            @HRA_PEPMAMOUNT,
            @HSA_MONTHLYMINIMUMAMOUNT,
            @HSA_PEPMAMOUNT,
            @LPF_MONTHLYMINIMUMAMOUNT,
            @LPF_PEPMAMOUNT,
            @NONBEN_NONBENADMINPEPMAMOUNT,
            @PLD_PLANDOCUMENTAMOUNT,
            @REN_ANNUALRENEWALAMOUNT,
            @SPM_MONTHLYMINIMUMAMOUNT,
            @SPM_PEPMAMOUNT,
            @TRN_MONTHLYMINIMUMAMOUNT,
            @TRN_PEPMAMOUNT;
        /**/
        IF @@FETCH_STATUS <> 0
            BEGIN
                SET @continue = 0
                BREAK
            END
        /**/
        
        SET @rowno = @rowno + 1;
        --         BEGIN TRY
        SET @msg1 = CONCAT( '#RowNo ' , @rowno , 'Processing Emp: ' , @EmployerName ,
                            ', BenCode: ' , @BenCode ,
                            ', RecordID: ' , @RecordID );
        EXEC db_log_message
             'QRY_RATE INCREASE APPLY NEW RATES TO EMP CTL' , @msg1 , 'INFO';
        
        BEGIN
            SET @sql1 = CONCAT( '
                UPDATE dbo.[tbl_Employer Control]
                SET
                    [ACA_ACAADMIN PEPM AMOUNT]= dbo.rate_increase_calc_new_rate( [ACA_ACAADMIN PEPM AMOUNT] ,
                                                                                 ' , CHAR( 39 ) ,
                                @ACA_ACAADMINPEPMAMOUNT , CHAR( 39 ) , ' ),
                    [BASE_FEE Amount]= dbo.rate_increase_calc_new_rate( [BASE_FEE Amount] , ' , CHAR( 39 ) ,
                                @BASE_FEEAmount , CHAR( 39 ) , ' ),
                    [BEN_BEN ADMIN PEPM AMOUNT]= dbo.rate_increase_calc_new_rate( [BEN_BEN ADMIN PEPM AMOUNT] ,
                                                                                  ' , CHAR( 39 ) ,
                                @BEN_BENADMINPEPMAMOUNT , CHAR( 39 ) , ' ),
                    [BEN_BEN ADMIN_MONTHLY MINIMUM AMOUNT]= dbo.rate_increase_calc_new_rate(
                            [BEN_BEN ADMIN_MONTHLY MINIMUM AMOUNT] , ' , CHAR( 39 ) ,
                                @BEN_BENADMIN_MONTHLYMINIMUMAMOUNT , CHAR( 39 ) , ' ),
                    [BND_BUNDLE RATE AMOUNT]= dbo.rate_increase_calc_new_rate( [BND_BUNDLE RATE AMOUNT] ,
                                                                               ' , CHAR( 39 ) , @BND_BUNDLERATEAMOUNT ,
                                CHAR( 39 ) , ' ),
                    [COBRA BASE_FEE Amount]= dbo.rate_increase_calc_new_rate( [COBRA BASE_FEE Amount] ,
                                                                              ' , CHAR( 39 ) , @COBRABASE_FEEAmount ,
                                CHAR( 39 ) , ' ),
                    [COBRA_MONTHLY MINIMUM AMOUNT]= dbo.rate_increase_calc_new_rate( [COBRA_MONTHLY MINIMUM AMOUNT] ,
                                                                                     ' , CHAR( 39 ) ,
                                @COBRA_MONTHLYMINIMUMAMOUNT , CHAR( 39 ) , ' ),
                    [COBRA_PEPM AMOUNT]= dbo.rate_increase_calc_new_rate( [COBRA_PEPM AMOUNT] , ' , CHAR( 39 ) ,
                                @COBRA_PEPMAMOUNT , CHAR( 39 ) , ' ),
                    [COBRA_PER NOTICE FLG AMOUNT]= dbo.rate_increase_calc_new_rate( [COBRA_PER NOTICE FLG AMOUNT] ,
                                                                                    ' , CHAR( 39 ) ,
                                @COBRA_PERNOTICEFLGAMOUNT , CHAR( 39 ) , ' ),
                    [DCF_NEW CARD AMOUNT]= dbo.rate_increase_calc_new_rate( [DCF_NEW CARD AMOUNT] ,
                                                                            ' , CHAR( 39 ) , @DCF_NEWCARDAMOUNT ,
                                CHAR( 39 ) , ' ),
                    [DCF_RPLACE CARD AMOUNT]= dbo.rate_increase_calc_new_rate( [DCF_RPLACE CARD AMOUNT] ,
                                                                               ' , CHAR( 39 ) , @DCF_RPLACECARDAMOUNT ,
                                CHAR( 39 ) , ' ),
                    [FLT_FLAT RATE AMOUNT]= dbo.rate_increase_calc_new_rate( [FLT_FLAT RATE AMOUNT] ,
                                                                             ' , CHAR( 39 ) , @FLT_FLATRATEAMOUNT ,
                                CHAR( 39 ) , ' ),
                    [FSA_MONTHLY MINIMUM AMOUNT]= dbo.rate_increase_calc_new_rate( [FSA_MONTHLY MINIMUM AMOUNT] ,
                                                                                   ' , CHAR( 39 ) ,
                                @FSA_MONTHLYMINIMUMAMOUNT , CHAR( 39 ) , ' ),
                    [FSA_PEPM AMOUNT]= dbo.rate_increase_calc_new_rate( [FSA_PEPM AMOUNT] , ' , CHAR( 39 ) ,
                                @FSA_PEPMAMOUNT , CHAR( 39 ) , ' ),
                    [HRA_MONTHLY MINIMUM AMOUNT]= dbo.rate_increase_calc_new_rate( [HRA_MONTHLY MINIMUM AMOUNT] ,
                                                                                   ' , CHAR( 39 ) ,
                                @HRA_MONTHLYMINIMUMAMOUNT , CHAR( 39 ) , ' ),
                    [HRA_PEPM AMOUNT]= dbo.rate_increase_calc_new_rate( [HRA_PEPM AMOUNT] , ' , CHAR( 39 ) ,
                                @HRA_PEPMAMOUNT , CHAR( 39 ) , ' ),
                    [HSA_MONTHLY MINIMUM AMOUNT]= dbo.rate_increase_calc_new_rate( [HSA_MONTHLY MINIMUM AMOUNT] ,
                                                                                   ' , CHAR( 39 ) ,
                                @HSA_MONTHLYMINIMUMAMOUNT , CHAR( 39 ) , ' ),
                    [HSA_PEPM AMOUNT]= dbo.rate_increase_calc_new_rate( [HSA_PEPM AMOUNT] , ' , CHAR( 39 ) ,
                                @HSA_PEPMAMOUNT , CHAR( 39 ) , ' ),
                    [LPF_MONTHLY MINIMUM AMOUNT]= dbo.rate_increase_calc_new_rate( [LPF_MONTHLY MINIMUM AMOUNT] ,
                                                                                   ' , CHAR( 39 ) ,
                                @LPF_MONTHLYMINIMUMAMOUNT , CHAR( 39 ) , ' ),
                    [LPF_PEPM AMOUNT]= dbo.rate_increase_calc_new_rate( [LPF_PEPM AMOUNT] , ' , CHAR( 39 ) ,
                                @LPF_PEPMAMOUNT , CHAR( 39 ) , ' )'
                , 'WHERE
                      RecordID = ' , @RecordID , ';' );
            
            SET @sql2 = CONCAT( 'UPDATE dbo.[tbl_Employer Control]
                SET ' ,
                                '   [NONBEN_NONBEN ADMIN PEPM AMOUNT] = dbo.rate_increase_calc_new_rate(
                                       [NONBEN_NONBEN ADMIN PEPM AMOUNT] , ' , CHAR( 39 ) ,
                                @NONBEN_NONBENADMINPEPMAMOUNT , CHAR( 39 ) , ' ) ,
                            [PLD_PLAN DOCUMENT AMOUNT] = dbo.rate_increase_calc_new_rate( [PLD_PLAN DOCUMENT AMOUNT] ,
                                                                                          ' , CHAR( 39 ) ,
                                @PLD_PLANDOCUMENTAMOUNT , CHAR( 39 ) , ' ) ,
                            [REN_ANNUAL RENEWAL AMOUNT] = dbo.rate_increase_calc_new_rate( [REN_ANNUAL RENEWAL AMOUNT] ,
                                                                                           ' ,
                                CHAR( 39 ) , @REN_ANNUALRENEWALAMOUNT , CHAR( 39 ) , ' ) ,
                            [SPM_MONTHLY MINIMUM AMOUNT] = dbo.rate_increase_calc_new_rate(
                                    [SPM_MONTHLY MINIMUM AMOUNT] ,
                                    ' , CHAR( 39 ) , @SPM_MONTHLYMINIMUMAMOUNT , CHAR( 39 ) , ' ) ,
                            [SPM_PEPM AMOUNT] = dbo.rate_increase_calc_new_rate( [SPM_PEPM AMOUNT] ,
                                                                                 ' , CHAR( 39 ) , @SPM_PEPMAMOUNT ,
                                CHAR( 39 ) , ' ) ,
                            [TRN_MONTHLY MINIMUM AMOUNT] = dbo.rate_increase_calc_new_rate(
                                    [TRN_MONTHLY MINIMUM AMOUNT] ,
                                    ' , CHAR( 39 ) , @TRN_MONTHLYMINIMUMAMOUNT , CHAR( 39 ) , ' ) ,
                            [TRN_PEPM AMOUNT] = dbo.rate_increase_calc_new_rate( [TRN_PEPM AMOUNT] ,
                                                                                 ' , CHAR( 39 ) , @TRN_PEPMAMOUNT ,
                                CHAR( 39 ) , ' )
                            WHERE
                            RecordID = ' , @RecordID , ';
                        ' );
            
            EXEC db_log_message
                 ' -- ' , @sql1 , 'INFO' , 0 , 0;
            EXECUTE sp_executesql @sql1;
            /**/
            EXEC db_log_message
                 ' -- ' , @sql2 , 'INFO' , 0 , 0;
            EXECUTE sp_executesql @sql2;
        END
        --         END TRY
        --         BEGIN CATCH
        --             SET @msg1 = CONCAT( @rowno , ' - ' , 'ERROR: ' , ERROR_MESSAGE( ) , ' FOR RECORD ' , @msg1 );
        --             EXEC db_log_error 50001 , 'QRY_RATE INCREASE APPLY NEW RATES TO EMP CTL' , @msg1 ,
        --                  'ERROR';
        --         END CATCH
        
        /**/
    END
    /* while*/
    
    /**/
    CLOSE db_cursor
    DEALLOCATE db_cursor
    
    /* show deletes [TBL_PROCESS TABLE ALL BACKUP]*/
    
    /**/
    
    SET @msg1 = CONCAT( '**LOG** ' , 'QRY_RATE INCREASE APPLY NEW RATES TO EMP CTL' ,
                        ' FINISHED ROW COUNT: ' , @rowno );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT

END
go

