CREATE PROCEDURE [dbo].[_imp_bs_employees_from_portal] AS
BEGIN
    DECLARE @msg1 nvarchar(max)
    
    DECLARE @iterator int = 0
    DECLARE @batch int = 200
    IF OBJECT_ID( 'dbo.bs_employees' , 'U' ) IS NOT NULL
        DROP TABLE dbo.bs_employees;
    
    SELECT *
    INTO dbo.bs_employees
    FROM
        OPENQUERY( portal_prod , 'SELECT * from bs.bs_employees;' )
    
    -- COMMIT;
    DECLARE @rows varchar(10);
    SELECT
        @rows = COUNT( * )
    FROM
        dbo.bs_employees;
    
    SET @msg1 = CONCAT( '**LOG** ' , 'imp_bs_employees_from_portal' , ' FINISHED INSERTED ' + @rows + ' ROWS' );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT

END;
go

