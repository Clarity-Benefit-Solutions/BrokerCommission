CREATE VIEW [dbo].[x_QuickBooks Pro Invoice Import_PCORI]
    AS
        /*   missing table PCORI2020 - seems to join all exports on bencode*/
        
        SELECT DISTINCT
            [tbl_Billing Invoice Export All QuickBooks].[Employer Name]
          , [tbl_Billing Invoice Export All QuickBooks].[Employer Key]
          , 'PCORI FEE' [Billing Code QB]
          , 'PCORI Fee Preparation' [Billing Description]
          , pcori2020.qty [Billing Unit Count]
          , pcori2020.fee_amount [Billing Unit Rate]
          , pcori2020.fee_amount [Billing Amount]
          , [tbl_Billing Invoice Export All QuickBooks].[Invoice Number]
          , '8/1/2020' [Invoice Date]
          , [tbl_Billing Invoice Export All QuickBooks].[Invoice Due Date]
          , [tbl_Billing Invoice Export All QuickBooks].terms
          , [tbl_Billing Invoice Export All QuickBooks].[Customer Message]
          , pcori2020.date_month [Billing Period]
          , [tbl_Billing Invoice Export All QuickBooks].[GL Receivable Account]
          , [tbl_Billing Invoice Export All QuickBooks].[GL Expense Account]
          , [tbl_Billing Invoice Export All QuickBooks].[To Email]
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
                INNER JOIN pcori2020 ON [tbl_Billing Invoice Export All QuickBooks].[Employer Key] = pcori2020.bencode
        WHERE
            /* sumeet: EMBMERGE*/
            /*   [BILLING GROUP]) NOT LIKE  '%EMB%' */
            processed_group NOT LIKE '%BEN ADMIN%'
go

