CREATE  PROCEDURE [dbo].[_process_3_post_import_2] AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        BEGIN/*clear procedure cache - very important when debugging!*/
            DBCC FREEPROCCACHE
            
            EXEC [dbo].[qry_Truncate Staging EB Records Remove EA];
            EXEC [dbo].[qry_Append EC extract To Staging Accounts];
            EXEC [dbo].[qry_Update Staging Accounts with EB Term Date status];
            EXEC [dbo].[qry_Update Staging Accounts formatting term date];
            EXEC [dbo].[qry_Update Staging Accounts with Employee status Conv];
            EXEC [dbo].[qry_Update Staging Accounts with Account status Conv];
            EXEC [dbo].[qry_Update Staging Accounts with Effect date formatted];
            EXEC [dbo].[QRY_UPDATE STAGING ACCOUNTS UPDATE FUTURE DATE FIELD];
            EXEC [dbo].[qry_Update Staging Account Type conversion];
            EXEC [dbo].[qry_Update Staging Accounts with UniqueKeys];
            EXEC [dbo].[qry_Update Staging accounts with Term runout days];
            EXEC [dbo].[qry_Update EC accounts with calc termrunoutdate];
            EXEC [dbo].[QRY_UPDATE STAGING ACCOUNTS WITH TERM BILLABLE];
            EXEC [dbo].[qry_Update Staging Account Division with EB Division];
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

