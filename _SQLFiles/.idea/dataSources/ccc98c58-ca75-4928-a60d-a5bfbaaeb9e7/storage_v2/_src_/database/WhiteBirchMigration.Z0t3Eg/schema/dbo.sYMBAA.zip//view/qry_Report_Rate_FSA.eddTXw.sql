CREATE VIEW [dbo].[qry_Report Rate FSA]
    AS
        /* get FSA fields from EmplCtl records EXCEPT for billing group 'EMB' and FSA_PEPM_FLG=1*/
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].process
          , [tbl_Employer Control].[QB Client Type]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[Employer Effective Date]
          , [tbl_Employer Control].[Employer Term Date]
          , [tbl_Employer Control].[BROKER CODE]
          , [tbl_Employer Control].[BASE_FEE BILLING CODE]
          , [tbl_Employer Control].[BASE_FEE FLG]
          , [tbl_Employer Control].[BASE_FEE Amount]
          , [tbl_Employer Control].[FSA_Account Type]
          , [tbl_Employer Control].[FSA_Plan Name]
          , [tbl_Employer Control].[FSA_BILLING CODE]
          , [tbl_Employer Control].[FSA_PEPM FLG]
          , [tbl_Employer Control].[FSA_PEPM AMOUNT]
          , [tbl_Employer Control].[FSA_MONTHLY MINIMUM FLG]
          , [tbl_Employer Control].[FSA_MONTHLY MINIMUM AMOUNT]
          , [tbl_Employer Control].[FSA_FLAT RATE FLG]
          , [tbl_Employer Control].[FSA_FLAT RATE AMOUNT]
          , [tbl_Employer Control].[FSA_PAID BY BROKER FLG]
          , [tbl_Employer Control].[FSA_PAID BY BROKER PERCENT]
          , [tbl_Employer Control].[FSA_PAID BY EMPLOYER FLG]
          , [tbl_Employer Control].[FSA_PAID BY EMPLOYER PERCENT]
          , [tbl_Employer Control].[DCF_Account Type]
          , [tbl_Employer Control].[DCF_Plan Name]
          , [tbl_Employer Control].[DCF_NEW CARD BILLING CODE]
          , [tbl_Employer Control].[DCF_NEW CARD FLG]
          , [tbl_Employer Control].[DCF_NEW CARD AMOUNT]
          , [tbl_Employer Control].[DCF_NEW RPLACE CARD BILLING CODE]
          , [tbl_Employer Control].[DCF_REPLACE CARD FLG]
          , [tbl_Employer Control].[DCF_RPLACE CARD AMOUNT]
          , [tbl_Employer Control].[DCF_PAID BY BROKER FLG]
          , [tbl_Employer Control].[DCF_PAID BY BROKER PERCENT]
          , [tbl_Employer Control].[DCF_PAID BY EMPLOYER FLG]
          , [tbl_Employer Control].[DCF_PAID BY EMPLOYER PERCENT]
        FROM
            [tbl_Employer Control]
        WHERE
            
            /* sumeet: EMBMERGE*/
            /*       [tbl_Employer Control].[Billing Group]) NOT LIKE '%EMB%') */
              [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN FLG] <> 1
            /* sumeet END*/
          AND [tbl_Employer Control].[FSA_PEPM FLG] = 1
go

