CREATE VIEW _audit_process_tbl_emp_recs
    AS
        SELECT *
        FROM
            dbo.[tbl_Employer Control]
        WHERE
                CONCAT( [Employer Name] , '-' , [Employer Key] ) IN (
                                                                        SELECT DISTINCT
                                                                            CONCAT( [Employer Name] , '-' , [Employer Key] )
                                                                        FROM
                                                                            dbo.[tbl_Process Table]
                                                                    )
go

