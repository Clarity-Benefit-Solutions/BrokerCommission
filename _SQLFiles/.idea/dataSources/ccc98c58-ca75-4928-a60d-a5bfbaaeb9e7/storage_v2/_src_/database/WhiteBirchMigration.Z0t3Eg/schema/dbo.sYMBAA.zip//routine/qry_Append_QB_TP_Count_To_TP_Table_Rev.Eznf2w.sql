CREATE PROCEDURE dbo.[	qry_Append QB TP Count To TP Table Rev	] AS

BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        -- ALTER  PROCEDURE [	qry_Append QB TP Count To TP Table Rev	] AS
        INSERT
            INTO [tbl_QB TP Count] (
                                   [Alternate ER ID],
                                   status,
                                   countofssn
        )
        SELECT
            [qry_QBDetail TP Unique Records].[Alternate ER ID]
          , [qry_QBDetail TP Unique Records].status
          , COUNT( [qry_QBDetail TP Unique Records].ssn ) countofssn
        FROM
            [qry_QBDetail TP Unique Records]
                INNER JOIN [tbl_Final EDI Billing Group Counts] ON [qry_QBDetail TP Unique Records].[Alternate ER ID] =
                                                                   [tbl_Final EDI Billing Group Counts].[Alternate ER ID]
        GROUP BY
            [qry_QBDetail TP Unique Records].[Alternate ER ID]
          , [qry_QBDetail TP Unique Records].status
        HAVING
            ((([qry_QBDetail TP Unique Records].status) = 'TP'));;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = ERROR_NUMBER( ), @errmessage varchar(max) = ERROR_MESSAGE( ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

