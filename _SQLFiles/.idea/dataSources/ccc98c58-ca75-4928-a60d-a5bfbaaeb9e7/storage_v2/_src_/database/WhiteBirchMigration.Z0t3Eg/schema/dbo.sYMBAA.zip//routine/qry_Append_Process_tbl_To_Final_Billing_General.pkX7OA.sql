CREATE PROCEDURE dbo.[QRY_APPEND PROCESS TBL TO FINAL BILLING GENERAL] AS
    /* inserts all Process records matching [GENERAL BILLING FLG]) = 1 into InvExp */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT] (
                                              [BILLING GROUP],
                                              [SYSTEM EMPLOYER KEY],
                                              [EMPLOYER NAME],
                                              [EMPLOYER KEY],
                                              [EMPLOYER BILLING NUMBER],
                                              [BROKER CODE],
                                              [KEY_MM MONTHLY MINIMUM],
                                              [BROKER NAME],
                                              [BILLING CODE],
                                              [BILLING UNIT COUNT],
                                              [BILLING UNIT RATE],
                                              [CALCULATED BILLING AMOUNT],
                                              [BILLING AMOUNT],
                                              [PAID BY BROKER FLG]
        )
        SELECT
            [TBL_PROCESS TABLE].[BILLING GROUP]
          , [TBL_PROCESS TABLE].[SYSTEM EMPLOYER CODE]
          , [TBL_PROCESS TABLE].[EMPLOYER NAME]
          , [TBL_PROCESS TABLE].[EMPLOYER KEY]
          , [TBL_PROCESS TABLE].[EMPLOYER BILLING NUMBER]
          , [TBL_PROCESS TABLE].[BROKER CODE]
          , [TBL_PROCESS TABLE].[GENERAL KEY_MM]
          , [TBL_PROCESS TABLE].[BROKER NAME]
          , [TBL_PROCESS TABLE].[GENERAL BILLING CODE]
          , [TBL_PROCESS TABLE].[GENERAL BILLING COUNT]
          , [TBL_PROCESS TABLE].[GENERAL BILLING AMOUNT]
          , ([TBL_PROCESS TABLE].[GENERAL BILLING COUNT] *
             [TBL_PROCESS TABLE].[GENERAL BILLING AMOUNT]) [CALCULATED BILLING AMOUNT]
          , ([TBL_PROCESS TABLE].[GENERAL BILLING COUNT] *
             [TBL_PROCESS TABLE].[GENERAL BILLING AMOUNT]) [BILLING AMOUNT]
          , [TBL_PROCESS TABLE].[PAID BY BROKER FLG]
        FROM
            [TBL_PROCESS TABLE]
        GROUP BY
            [TBL_PROCESS TABLE].[BILLING GROUP]
          , [TBL_PROCESS TABLE].[SYSTEM EMPLOYER CODE]
          , [TBL_PROCESS TABLE].[EMPLOYER NAME]
          , [TBL_PROCESS TABLE].[EMPLOYER KEY]
          , [TBL_PROCESS TABLE].[EMPLOYER BILLING NUMBER]
          , [TBL_PROCESS TABLE].[BROKER CODE]
          , [TBL_PROCESS TABLE].[GENERAL KEY_MM]
          , [TBL_PROCESS TABLE].[BROKER NAME]
          , [TBL_PROCESS TABLE].[GENERAL BILLING CODE]
          , [TBL_PROCESS TABLE].[GENERAL BILLING COUNT]
          , [TBL_PROCESS TABLE].[GENERAL BILLING AMOUNT]
          , [TBL_PROCESS TABLE].[GENERAL BILLING COUNT] * [TBL_PROCESS TABLE].[GENERAL BILLING AMOUNT]
          , [TBL_PROCESS TABLE].[GENERAL BILLING FLG]
          , [TBL_PROCESS TABLE].[PAID BY BROKER FLG]
        HAVING
            ((([TBL_PROCESS TABLE].[GENERAL BILLING FLG]) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

