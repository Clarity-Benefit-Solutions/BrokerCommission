CREATE PROCEDURE dbo.[QRY_APPEND PROCESS TBL TO FINAL BILLING COBRA NOTICE] AS
    /* inserts all Process records matching [BILLING CODE]) = 'COBRA NOTICE' into InvExp */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT] (
                                              [BILLING GROUP],
                                              [EMPLOYER NAME],
                                              [EMPLOYER KEY],
                                              [EMPLOYER BILLING NUMBER],
                                              [BROKER CODE],
                                              [BROKER NAME],
                                              [BILLING CODE],
                                              [KEY_MM MONTHLY MINIMUM],
                                              [BILLING UNIT RATE],
                                              [CALCULATED BILLING AMOUNT],
                                              [BILLING UNIT COUNT],
                                              [BILLING AMOUNT],
                                              [PAID BY BROKER FLG]
        )
        SELECT
            [TBL_PROCESS TABLE].[BILLING GROUP]
          , [TBL_PROCESS TABLE].[EMPLOYER NAME]
          , [TBL_PROCESS TABLE].[EMPLOYER KEY]
          , [TBL_PROCESS TABLE].[EMPLOYER BILLING NUMBER]
          , [TBL_PROCESS TABLE].[BROKER CODE]
          , [TBL_PROCESS TABLE].[BROKER NAME]
          , [TBL_PROCESS TABLE].[BILLING CODE]
          , [TBL_PROCESS TABLE].[KEY_MM MONTHLY MINIMUM]
          , [TBL_PROCESS TABLE].[COBRA_PER NOTICE AMOUNT]
          , SUM( [TBL_PROCESS TABLE].[COBRA_NOTICE BILL AMOUNT] ) [SUMOFCOBRA_NOTICE BILL AMOUNT]
          , SUM( [TBL_PROCESS TABLE].[COBRA_NOTICE COUNT] ) [SUMOFCOBRA_NOTICE COUNT]
          , SUM( ([TBL_PROCESS TABLE].[COBRA_NOTICE BILL AMOUNT]) ) [BILLING AMOUNT]
          , [TBL_PROCESS TABLE].[PAID BY BROKER FLG]
        FROM
            [TBL_PROCESS TABLE]
        GROUP BY
            [TBL_PROCESS TABLE].[BILLING GROUP]
          , [TBL_PROCESS TABLE].[EMPLOYER NAME]
          , [TBL_PROCESS TABLE].[EMPLOYER KEY]
          , [TBL_PROCESS TABLE].[EMPLOYER BILLING NUMBER]
          , [TBL_PROCESS TABLE].[BROKER CODE]
          , [TBL_PROCESS TABLE].[BROKER NAME]
          , [TBL_PROCESS TABLE].[BILLING CODE]
          , [TBL_PROCESS TABLE].[KEY_MM MONTHLY MINIMUM]
          , [TBL_PROCESS TABLE].[COBRA_PER NOTICE AMOUNT]
          , [TBL_PROCESS TABLE].[PAID BY BROKER FLG]
        HAVING
            ((([TBL_PROCESS TABLE].[BILLING CODE]) = 'COBRA NOTICE'));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

