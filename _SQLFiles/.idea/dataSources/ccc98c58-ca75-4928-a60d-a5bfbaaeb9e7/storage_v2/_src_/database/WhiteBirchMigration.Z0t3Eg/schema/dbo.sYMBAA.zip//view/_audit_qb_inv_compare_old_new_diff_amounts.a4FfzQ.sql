/* QB inv diff amounts*/
    CREATE VIEW _audit_qb_inv_compare_old_new_diff_amounts AS
    SELECT *
    FROM
        [_audit_qb_inv_compare_old_new_vw]
    WHERE
        diffinamount <> 0
go

