CREATE PROCEDURE dbo.[QRY_APPEND LINKED EDI_3 FINAL COUNTS TO LOCAL EDI_6 TABLE] AS
    /* inserts all [TBL_STAGING EDI_3 SOURCE DATA] records into  [TBL_STAGING EDI_3 SOURCE DATA]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_STAGING EDI_3 SOURCE DATA] (
                                                 client,
                                                 bencode,
                                                 [NPM COUNT],
                                                 [TE COUNT],
                                                 [TP COUNT],
                                                 new_qty
        )
        SELECT
            [TBL_FINAL EDI BILLING GROUP COUNTS].clientname
          , [TBL_FINAL EDI BILLING GROUP COUNTS].[ALTERNATE ER ID]
          , [TBL_FINAL EDI BILLING GROUP COUNTS].[NPM COUNT]
          , [TBL_FINAL EDI BILLING GROUP COUNTS].[TE COUNT]
          , [TBL_FINAL EDI BILLING GROUP COUNTS].[TP COUNT]
          , [TBL_FINAL EDI BILLING GROUP COUNTS].[FINAL BILLABLE COUNTS]
        FROM
            [TBL_FINAL EDI BILLING GROUP COUNTS]
        WHERE
            ((dbo.isblank( [TBL_FINAL EDI BILLING GROUP COUNTS].suppress ) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

