CREATE PROCEDURE dbo.[QRY_RATE INCREASE VERIFY RATES INCREASE IN EMP CTL] AS
BEGIN
    
    DECLARE @valueList nvarchar(max)
    DECLARE @pos int
    DECLARE @len int
    DECLARE @value nvarchar(255)
    
    /**/
    DECLARE @continue int
    DECLARE @rowNo int
    DECLARE @EmployerName nvarchar(255);
    DECLARE @BenCode nvarchar(255);
    DECLARE @RecordID int;
    
    DECLARE @RateType nvarchar(255);
    DECLARE @OldAmount money;
    DECLARE @PctIncrease money;
    DECLARE @NewAmount money;
    
    DECLARE @SQL nvarchar(max);
    DECLARE @msg1 nvarchar(max);
    
    DECLARE @oldrate money;
    DECLARE @newrate money;
    DECLARE @pctrate nvarchar(255);
    
    DECLARE db_cursor CURSOR FOR
        SELECT /*TOP 50*/
            RecordID
          , [Employer Name]
          , [Employer Key]
        FROM
            dbo.[tbl_Employer Control]
        WHERE
            1 = 1
--           AND RecordID IN (2717)
        ORDER BY
            [Employer Name];
    
    SET @valueList =
            '[ACA_ACAADMIN PEPM AMOUNT],[BASE_FEE Amount],[BEN_BEN ADMIN PEPM AMOUNT],[BEN_BEN ADMIN_MONTHLY MINIMUM AMOUNT],[BND_BUNDLE RATE AMOUNT],[COBRA BASE_FEE Amount],[COBRA_MONTHLY MINIMUM AMOUNT],[COBRA_PEPM AMOUNT],[COBRA_PER NOTICE FLG AMOUNT],[DCF_NEW CARD AMOUNT],[DCF_RPLACE CARD AMOUNT],[FLT_FLAT RATE AMOUNT],[FSA_MONTHLY MINIMUM AMOUNT],[FSA_PEPM AMOUNT],[HRA_MONTHLY MINIMUM AMOUNT],[HRA_PEPM AMOUNT],[HSA_MONTHLY MINIMUM AMOUNT],[HSA_PEPM AMOUNT],[LPF_MONTHLY MINIMUM AMOUNT],[LPF_PEPM AMOUNT],[NONBEN_NONBEN ADMIN PEPM AMOUNT],[PLD_PLAN DOCUMENT AMOUNT],[REN_ANNUAL RENEWAL AMOUNT],[TRN_MONTHLY MINIMUM AMOUNT],[TRN_PEPM AMOUNT],[SPM_MONTHLY MINIMUM AMOUNT],[SPM_PEPM AMOUNT],';
    
    SET @pos = 0
    SET @len = 0
    
    SET @continue = 1
    
    EXEC db_log_message 'QRY_RATE INCREASE VERIFY RATES INCREASE IN EMP CTL' ,
         ' OPENING CURSOR' ,
         'INFO';
    
    /**/
    OPEN db_cursor
    /**/
    
    TRUNCATE TABLE dbo.[tbl_Employer Control Rate Verify Increase Pct];
    
    WHILE @continue = 1 BEGIN
        FETCH NEXT FROM db_cursor INTO
            @RecordID, @EmployerName, @BenCode;
        
        /**/
        IF @@FETCH_STATUS <> 0
            BEGIN
                SET @continue = 0
                BREAK
            END
        /**/
        
        SET @rowno = @rowno + 1;
        BEGIN TRY
            SET @msg1 = CONCAT( '#RowNo ' , @rowno , 'Processing Emp: ' , @EmployerName ,
                                ', BenCode: ' , @BenCode ,
                                ', RecordID: ' , @RecordID );
            
            EXEC db_log_message
                 'QRY_RATE INCREASE VERIFY RATES INCREASE IN EMP CTL' , @msg1 , 'INFO';
            
            BEGIN
                SET @pos = 0;
                WHILE CHARINDEX( ',' , @valueList , @pos + 1 ) > 0
                    BEGIN
                        SET @len = CHARINDEX( ',' , @valueList , @pos + 1 ) - @pos
                        SET @value = SUBSTRING( @valueList , @pos , @len )
                        SET @pos = CHARINDEX( ',' , @valueList , @pos + @len ) + 1
                        
                        /**/
                        SET @RateType = @value;
                        
                        /* get rates*/
                        EXEC dbo.rate_increase_get_rate @RecordID , @RateType , 'PCT' , @pctrate OUTPUT;
                        EXEC dbo.rate_increase_get_rate @RecordID , @RateType , 'OLD' , @oldrate OUTPUT;
                        EXEC dbo.rate_increase_get_rate @RecordID , @RateType , 'NEW' , @newrate OUTPUT;
                        
                        SET @msg1 = CONCAT( ' -- ' , @rowno , ' RateType: ' , @RateType ,
                                            ', OldRate: ' , @oldrate ,
                                            ', pctRate: ' , @pctrate ,
                                            ', newRate: ' , @newrate );
                        
--                         EXEC db_log_message
--                              'QRY_RATE INCREASE VERIFY RATES INCREASE IN EMP CTL' , @msg1 , 'INFO' , 0 , 0;
                        
                        /**/
                        INSERT INTO dbo.[tbl_Employer Control Rate Verify Increase Pct] (
                                                                                        EmployerName,
                                                                                        BenCode,
                                                                                        RecordID,
                                                                                        RateType,
                                                                                        OldAmount,
                                                                                        PctIncrease,
                                                                                        NewAmount
                        
                        )
                        VALUES (
                               @EmployerName,
                               @BenCode,
                               @RecordID,
                               @RateType,
                               @oldrate,
                               @pctrate,
                               @newrate
                               );
                    END
            END
        END TRY
        BEGIN CATCH
            SET @msg1 = CONCAT( @rowno , ' - ' , 'ERROR: ' , ERROR_MESSAGE( ) , ' FOR RECORD ' , @msg1 );
            EXEC db_log_error 50001 , 'QRY_RATE INCREASE VERIFY RATES INCREASE IN EMP CTL' , @msg1 ,
                 'ERROR';
        END CATCH
        
        /**/
    END
    /* while*/
    
    /**/
    CLOSE db_cursor
    DEALLOCATE db_cursor
    
    /* show deletes [TBL_PROCESS TABLE ALL BACKUP]*/
    
    /**/
    
    SET @msg1 = CONCAT( '**LOG** ' , 'QRY_RATE INCREASE VERIFY RATES INCREASE IN EMP CTL' ,
                        ' FINISHED ROW COUNT: ' , @rowno );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT
    
--     /**/
--     SELECT *
--     FROM
--         dbo.[tbl_Employer Control Rate Verify Increase Pct]
--     ORDER BY
--         EmployerName
--       , RateType;

END
go

