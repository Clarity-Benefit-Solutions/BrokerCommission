CREATE VIEW [dbo].[qry_Process tbl To Final Billing Export PEPM Only Counts]
    AS
        /* select ProcessTable recs for PEPM process + HSA/MED/HRA/LPF/PKGTRN */
        SELECT
            [tbl_Process Table].[Employer Name]
          , [tbl_Process Table].[System Employer Code]
          , [tbl_Process Table].[Billing Group]
          , [tbl_Process Table].[Employer Key]
          , [tbl_Process Table].[Broker Code]
          , [tbl_Process Table].[Employer Billing Number]
          , [tbl_Process Table].[Broker Name]
          , 'PEPM' [PEPM BILLING CODE]
          , [tbl_Process Table].[Key_MM Monthly Minimum]
          , [tbl_Process Table].[MONTHLY MINIMUM AMOUNT]
          , [tbl_Process Table].[MONTHLY MINIMUM FLG]
          , [tbl_Process Table].[PEPM AMOUNT]
          , ([tbl_Process Table].[PEPM AMOUNT]) [Billing Amount]
          , ([tbl_Process Table].[PEPM AMOUNT]) [Calculated Billing Amount]
          , [tbl_Process Table].uniquekeyparticipant
          , [tbl_Process Table].[PAID BY BROKER FLG]
          , [PEPM COUNT]
        FROM
            [tbl_Process Table]
        WHERE
            ((([tbl_Process Table].[PEPM FLG]) = 1) AND
                /* embmerge3*/
                /* as soon as we allow COBRA, total amounts go down!*/
                /*        (([tbl_Process Table].[BILLING CODE]) = 'COBRA') OR
                */ (([tbl_Process Table].[BILLING CODE]) = 'HSA' OR ([tbl_Process Table].[BILLING CODE]) = 'MED' OR
                    ([tbl_Process Table].[BILLING CODE]) = 'HRA' OR ([tbl_Process Table].[BILLING CODE]) = 'LPF' OR
                    ([tbl_Process Table].[BILLING CODE]) = 'PKGTRN'))
        GROUP BY
            [tbl_Process Table].[Employer Name]
          , [tbl_Process Table].[System Employer Code]
          , [tbl_Process Table].[Billing Group]
          , [tbl_Process Table].[Employer Key]
          , [tbl_Process Table].[Broker Code]
          , [tbl_Process Table].[Employer Billing Number]
          , [tbl_Process Table].[Broker Name]
          , [tbl_Process Table].[Key_MM Monthly Minimum]
          , [tbl_Process Table].[MONTHLY MINIMUM AMOUNT]
          , [tbl_Process Table].[MONTHLY MINIMUM FLG]
          , [tbl_Process Table].[PEPM AMOUNT]
          , ([tbl_Process Table].[PEPM AMOUNT])
          , [tbl_Process Table].uniquekeyparticipant
          , [tbl_Process Table].[PAID BY BROKER FLG]
          , ([tbl_Process Table].[PEPM AMOUNT])
          , [PEPM COUNT]
go

