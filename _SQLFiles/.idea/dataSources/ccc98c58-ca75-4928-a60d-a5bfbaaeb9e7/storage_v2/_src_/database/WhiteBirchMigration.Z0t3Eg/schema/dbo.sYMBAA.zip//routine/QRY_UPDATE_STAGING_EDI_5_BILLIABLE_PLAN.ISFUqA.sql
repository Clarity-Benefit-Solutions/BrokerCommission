CREATE PROCEDURE dbo.[QRY_UPDATE STAGING EDI_5_BILLIABLE PLAN] AS
    /* update Edi5PlanDocRpt set [BILLABLE RUNOUT] = 'Billable' if [Runout Date dt]) > InvDt.[Billing Runout Date]
   ** marks cretain records as billable based on RunOutDate
   */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT]
        SET
            [TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].[BILLABLE RUNOUT] = 'Billable'
        FROM
            [TBL_INVOICE DATE TABLE]
        WHERE
            ((([TBL_STAGING_EDI_5 PLAN DOCUMENT REPORT].[RUNOUT DATE DT]) >
              ([TBL_INVOICE DATE TABLE].[BILLING RUNOUT DATE])));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

