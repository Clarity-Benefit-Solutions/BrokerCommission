/*totals by employer*/
    CREATE VIEW dbo.vw_utils_compare_qb_inv_old_new_app_mismatches_dtl
    AS
        SELECT
            t.TableName
          , t.[ORIGINAL EMPLOYER NAME]
          , t.[Employer Name]
          , t.[BILLING CODE]
          , SUM( t.[Billing Unit Count] ) [Billing Unit Count]
          , SUM( t.[Billing Amount] ) [Billing Amount]
          , t.[Billing Code QB]
          , t.[Billing Description]
          , t.[Billing Group Process]
        FROM
            vw_utils_compare_qb_inv_old_new_app t
        WHERE
                CONCAT( t.[ORIGINAL EMPLOYER NAME] , '-' , t.[EMPLOYER NAME] , '-' , t.[Billing Code QB] ) IN (
                                                                                                                  SELECT
                                                                                                                      CONCAT(
                                                                                                                              t.[ORIGINAL EMPLOYER NAME] ,
                                                                                                                              '-' ,
                                                                                                                              t.[EMPLOYER NAME] ,
                                                                                                                              '-' ,
                                                                                                                              t.[Billing Code QB] )
                                                                                                                  FROM
                                                                                                                      dbo.vw_utils_compare_qb_inv_old_new_app_fn_dtl
                                                                                                                  WHERE
                                                                                                                      1 = 1
                                                                                                                    AND
                                                                                                                      OldAppAmount <>
                                                                                                                      NewAppAmount
                                                                                                              )
        GROUP BY
            t.TableName
          , t.[ORIGINAL EMPLOYER NAME]
          , t.[Employer Name]
          , t.[BILLING CODE]
          , t.[Billing Code QB]
          , t.[Billing Description]
          , t.[Billing Group Process]
go

