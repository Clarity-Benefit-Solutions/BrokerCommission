CREATE VIEW [dbo].[X_BACKUP Details Report Bundle old 0919]
    AS
        /* Liat all backup process records for with retunring [BND_BILLING CODE]  for bundle billing and [BILLING CODE] for others*/
        SELECT
            IIF( [tbl_Process Table All Backup].[BND_BUNDLE BILL QUAL] = 'Bundle' ,
                 [tbl_Process Table All Backup].[BND_BILLING CODE] ,
                 [tbl_Process Table All Backup].[BILLING CODE] ) [BUNDLE BILLING CODE]
          , IIF( [tbl_Process Table All Backup].[BND_BUNDLE BILL QUAL] = 'Bundle' ,
                 [tbl_Process Table All Backup].[BND_BILLING CODE] ,
                 [tbl_Process Table All Backup].[BILLING CODE] ) [Billing Description]
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , [tbl_Process Table All Backup].[PEPM COUNT]
          , [tbl_Process Table All Backup].[PEPM AMOUNT]
          , [tbl_Process Table All Backup].[BND_BUNDLE RATE AMOUNT]
          , [tbl_Process Table All Backup].uniquekeyparticipant
        FROM
            [tbl_Process Table All Backup]
        GROUP BY
            IIF( [tbl_Process Table All Backup].[BND_BUNDLE BILL QUAL] = 'Bundle' ,
                 [tbl_Process Table All Backup].[BND_BILLING CODE] , [tbl_Process Table All Backup].[BILLING CODE] )
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , [tbl_Process Table All Backup].[PEPM COUNT]
          , [tbl_Process Table All Backup].[PEPM AMOUNT]
          , [tbl_Process Table All Backup].[BND_BUNDLE RATE AMOUNT]
          , [tbl_Process Table All Backup].uniquekeyparticipant
go

