CREATE VIEW [dbo].[qry_BACKUP Details Report Bundle 3 NonQualified old 0919]
    AS
        /* list backup records for bundle*/
        SELECT DISTINCT
            [tbl_Process Table All Backup].[Employer Key]
          , [tbl_Process Table All Backup].[Employer Name]
          , ([tbl_Process Table All Backup].[BILLING CODE]) [BILLING CODE]
          , ([tbl_Process Table All Backup].[Plan Name]) [Billing Description]
          , [tbl_Process Table All Backup].[Last Name]
          , [tbl_Process Table All Backup].[First Name]
          , [tbl_Process Table All Backup].[Participant Status]
          , [tbl_Process Table All Backup].[Participant Term Date]
          , IIF( [tbl_Process Table All Backup].[PEPM COUNT] = 0 , '1' ,
                 [tbl_Process Table All Backup].[PEPM COUNT] ) pepm
          , ([tbl_Process Table All Backup].[PEPM AMOUNT]) [PEPM AMOUNT]
        FROM
            [tbl_Process Table All Backup]
        WHERE
            ((([tbl_Process Table All Backup].[BND_BUNDLE BILL QUAL]) IS NULL) AND
             (([tbl_Process Table All Backup].[Billing Group]) LIKE '%Bundle%'))
go

