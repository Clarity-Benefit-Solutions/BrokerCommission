CREATE PROCEDURE dbo.[UPDATE_MISSPELLED_CLIENTS] AS
    /* update InvExpQB set [EMPLOYER NAME] = [MISPELLEDCLIENTS].[QB_NAME] joined on wb_name = [EMPLOYER NAME]*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER NAME]
        SET
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER NAME] = [MISPELLEDCLIENTS].[QB_NAME]
        FROM
            mispelledclients
                INNER JOIN [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
                           ON mispelledclients.wb_name = [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS].[EMPLOYER NAME];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

