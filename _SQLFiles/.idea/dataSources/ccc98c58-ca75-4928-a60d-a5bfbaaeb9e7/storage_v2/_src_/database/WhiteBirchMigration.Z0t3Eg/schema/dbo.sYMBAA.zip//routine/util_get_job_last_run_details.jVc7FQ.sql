CREATE PROCEDURE [dbo].[util_get_job_last_run_details](
                                                     @job_name nvarchar(500),
                                                     @job_start_date_time datetime ) AS
BEGIN
    BEGIN TRY
        DECLARE @msg nvarchar(max);
        
        --         SET @msg = 'Called [dbo].[util_get_job_last_run_details] ' + @job_name + ', ' +
        --                   /* FORMAT(*/ @job_start_date_time /*,  'yyyy-MM-dd hh:mm:ss' )*/
        --         SELECT
        --             @msg;
        --
        SELECT *
        FROM
            dbo.qry_util_get_job_run_details
        WHERE
              job_name = @job_name
          AND job_start_execution_date >= @job_start_date_time
          AND (job_step_log_date_created IS NULL OR job_step_log_date_created >= @job_start_date_time)
    
    END TRY BEGIN CATCH
        DECLARE @errno varchar(500) = ERROR_NUMBER( )
        DECLARE @errmsg varchar(2000) = ERROR_MESSAGE( )
        DECLARE @errstate varchar(200) = ERROR_STATE( )
        
        EXEC dbo.db_throw_error 50001 , @job_name , @errmsg;
    
    END CATCH
END
go

