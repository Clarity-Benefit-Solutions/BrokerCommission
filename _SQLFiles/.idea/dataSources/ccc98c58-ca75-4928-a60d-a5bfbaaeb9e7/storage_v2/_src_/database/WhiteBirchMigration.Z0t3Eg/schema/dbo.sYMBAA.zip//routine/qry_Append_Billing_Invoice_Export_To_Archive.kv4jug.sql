CREATE PROCEDURE dbo.[QRY_APPEND BILLING INVOICE EXPORT TO ARCHIVE] AS
    /* inserts all  InvExpQB into InvExpArchive*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        /* sumeet - first delete records for this period*/
        DELETE
        FROM
            [TBL_BILLING INVOICE EXPORT ARCHIVE]
        WHERE
                [Billing Period] = (
                                       SELECT TOP 1
                                           [Billing Period]
                                       FROM
                                           [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS]
                                   );
        
        /* now insert*/
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT ARCHIVE] (
                                                      [BILLING GROUP],
                                                      [EMPLOYER NAME],
                                                      [EMPLOYER KEY],
                                                      [SYSTEM EMPLOYER KEY],
                                                      [BROKER CODE],
                                                      [BROKER NAME],
                                                      [BILLING CODE],
                                                      [BILLING CODE QB],
                                                      [BILLING DESCRIPTION],
                                                      [BILLING UNIT COUNT],
                                                      [BILLING UNIT RATE],
                                                      [BILLING AMOUNT],
                                                      [INVOICE NUMBER],
                                                      [INVOICE DATE],
                                                      [INVOICE DUE DATE],
                                                      terms,
                                                      [CUSTOMER MESSAGE],
                                                      [BILLING PERIOD],
                                                      [BILL TO],
                                                      [KEY_MM MONTHLY MINIMUM],
                                                      [MONTHLY MIN BILLING FLG],
                                                      [MONTHLY MIN BILLING AMOUNT],
                                                      [CALCULATED BILLING AMOUNT],
                                                      [EMPLOYER BILLING NUMBER],
                                                      [GL RECEIVABLE ACCOUNT],
                                                      [GL EXPENSE ACCOUNT],
                                                      [TO PRINT],
                                                      [TO EMAIL],
                                                      [Monthly Min To Delete],
                                                      [Original Employer Name],
                                                      [Billing Group Process],
                                                      RecordID,
                                                      PROCESSED_GROUP,
                                                      ToDelete,
                                                      DeleteReason
        
        )
        SELECT
            [BILLING GROUP]
          , [EMPLOYER NAME]
          , [EMPLOYER KEY]
          , [SYSTEM EMPLOYER KEY]
          , [BROKER CODE]
          , [BROKER NAME]
          , [BILLING CODE]
          , [BILLING CODE QB]
          , [BILLING DESCRIPTION]
          , [BILLING UNIT COUNT]
          , [BILLING UNIT RATE]
          , [BILLING AMOUNT]
          , [INVOICE NUMBER]
          , [INVOICE DATE]
          , [INVOICE DUE DATE]
          , terms
          , [CUSTOMER MESSAGE]
          , [BILLING PERIOD]
          , [BILL TO]
          , [KEY_MM MONTHLY MINIMUM]
          , [MONTHLY MIN BILLING FLG]
          , [MONTHLY MIN BILLING AMOUNT]
          , [CALCULATED BILLING AMOUNT]
          , [EMPLOYER BILLING NUMBER]
          , [GL RECEIVABLE ACCOUNT]
          , [GL EXPENSE ACCOUNT]
          , [TO PRINT]
          , [TO EMAIL]
          , [Monthly Min To Delete]
          , [Original Employer Name]
          , [Billing Group Process]
          , RecordID
          , PROCESSED_GROUP
          , ToDelete
          , DeleteReason
        FROM
            [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

