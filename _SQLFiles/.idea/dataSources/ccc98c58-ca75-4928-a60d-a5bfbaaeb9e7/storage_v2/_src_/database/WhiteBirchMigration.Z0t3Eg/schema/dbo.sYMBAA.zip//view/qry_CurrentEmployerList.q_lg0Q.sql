CREATE VIEW [dbo].[qry_CurrentEmployerList]
    AS
        /* select distinct EmployerName from EmployerControl*/
        SELECT DISTINCT
            [tbl_Employer Control].[Employer Name]
        FROM
            [tbl_Employer Control]
go

