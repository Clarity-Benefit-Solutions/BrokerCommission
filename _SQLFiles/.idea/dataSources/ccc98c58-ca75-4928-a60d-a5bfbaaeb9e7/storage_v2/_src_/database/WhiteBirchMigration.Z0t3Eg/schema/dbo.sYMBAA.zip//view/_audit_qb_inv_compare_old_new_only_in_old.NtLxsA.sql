/* QB inv only in old*/
    CREATE VIEW _audit_qb_inv_compare_old_new_only_in_old AS
    SELECT *
    FROM
        [_audit_qb_inv_compare_old_new_vw]
    WHERE
        [new_Employer Name] IS NULL
go

