CREATE VIEW _qry_if_billing_setup_fees AS
    SELECT
        CASE
            WHEN dbo.IsNotBlank( [Employer Name] ) = 1 THEN [Employer Name]
            ELSE 'Missing Employer Record in Finance App'
        END [Employer Name]
      , employerid [Employer Key]
      , '' PlanType
      , dbo.GetCurrentBillingPeriod( 0 ) [Billing Period]
      , NULL [Billing Month]
      , BillingCode [Billing Code]
      , BillingDescription [QB Billing Code]
      , 0 [PAID BY BROKER FLG]
      , CAST( BillingAmount AS money ) [Setup Fee Amount]
      , CAST( UnitRate AS money ) Rate
      , CAST( Units AS money ) Quantity
    
    FROM
        dbo.incentfit_billing
            LEFT JOIN dbo.[tbl_Employer Control]
                      ON incentfit_billing.employerid = [tbl_Employer Control].[Employer Key] AND
                         dbo.IsNotBlank( [tbl_Employer Control].[Billing Group Process] ) = 1
go

