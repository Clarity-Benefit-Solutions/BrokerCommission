CREATE VIEW _audit_platform_clients
    AS
        SELECT DISTINCT
            'Salesforce' platform
          , clientcode [Employer Key]
          , clientname [Employer Name]
          , CASE
                WHEN clientstatus IS NULL OR clientstatus = '' THEN 1
                ELSE 0
            END [Employer Active Flag]
        FROM
            dbo.sf_accounts
        UNION
        
        SELECT DISTINCT
            'bswift' platform
          , eeclientbencode
          , 'Unknown'
          , 1 active
        FROM
            dbo.bs_employees
        
        UNION
        SELECT DISTINCT
            'COBRAPoint' platform
          , clientalternate
          , clientname
          , 1
        FROM
            dbo.cp_clients
        UNION
        SELECT DISTINCT
            'Enav' platform
          , companyidentifier
          , 'Unknown'
          , 1 active
        FROM
            dbo.en_employees
        
        UNION
        SELECT DISTINCT
            'Alegeus' platform
          , employer_id
          , employer_name
          , 1
        FROM
            dbo.wc_employers
go

