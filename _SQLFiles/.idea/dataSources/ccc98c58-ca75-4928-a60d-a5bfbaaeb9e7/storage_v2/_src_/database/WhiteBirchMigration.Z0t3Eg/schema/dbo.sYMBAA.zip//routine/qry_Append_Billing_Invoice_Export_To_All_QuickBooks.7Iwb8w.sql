CREATE PROCEDURE dbo.[QRY_APPEND BILLING INVOICE EXPORT TO ALL QUICKBOOKS] AS
    /* inserts all  InvExp Rows into InvExpQB*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT ALL QUICKBOOKS] (
                                                               [Billing Group]
                                                             , [Employer Name]
                                                             , [Employer Key]
                                                             , [System Employer Key]
                                                             , [Broker Code]
                                                             , [Broker Name]
                                                             , [Billing Code]
                                                             , [Billing Code QB]
                                                             , [Billing Description]
                                                             , [Billing Unit Count]
                                                             , [Billing Unit Rate]
                                                             , [Billing Amount]
                                                             , [Invoice Number]
                                                             , [Invoice Date]
                                                             , [Invoice Due Date]
                                                             , terms
                                                             , [Customer Message]
                                                             , [Billing Period]
                                                             , [Bill To]
                                                             , [PAID BY BROKER FLG]
                                                             , [KEY_MM Monthly Minimum]
                                                             , [Monthly Min Billing Flg]
                                                             , [Monthly Min To Delete]
                                                             , [Monthly Min Billing Amount]
                                                             , [Calculated Billing Amount]
                                                             , [Employer Billing Number]
                                                             , [GL Receivable Account]
                                                             , [GL Expense Account]
                                                             , [To Print]
                                                             , [To Email]
                                                             , [Original Employer Name]
                                                             , processed_group
                                                             , [Billing Group Process]
                                                             , RecordID
                                                             , ToDelete
                                                             , DeleteReason
        )
        
        SELECT
            [Billing Group]
          , [Employer Name]
          , [Employer Key]
          , [System Employer Key]
          , [Broker Code]
          , [Broker Name]
          , [Billing Code]
          , [Billing Code QB]
          , [Billing Description]
          , [Billing Unit Count]
          , [Billing Unit Rate]
          , [Billing Amount]
          , [Invoice Number]
          , [Invoice Date]
          , [Invoice Due Date]
          , terms
          , [Customer Message]
          , [Billing Period]
          , [Bill To]
          , [PAID BY BROKER FLG]
          , [KEY_MM Monthly Minimum]
          , [Monthly Min Billing Flg]
          , [Monthly Min To Delete]
          , [Monthly Min Billing Amount]
          , [Calculated Billing Amount]
          , [Employer Billing Number]
          , [GL Receivable Account]
          , [GL Expense Account]
          , [To Print]
          , [To Email]
          , [Original Employer Name]
          , processed_group
          , [Billing Group Process]
          , RecordID
          , ToDelete
          , DeleteReason
        FROM
            [tbl_Billing Invoice Export]
        WHERE
            ISNULL( [Billing Code QB] , '' ) <> 'Alegeus ACH Error Credit';
        
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END ;
go

