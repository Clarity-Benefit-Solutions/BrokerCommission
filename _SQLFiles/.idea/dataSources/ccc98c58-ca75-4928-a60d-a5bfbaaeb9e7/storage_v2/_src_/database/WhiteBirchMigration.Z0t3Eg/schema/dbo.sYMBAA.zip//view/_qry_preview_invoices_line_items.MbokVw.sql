CREATE VIEW _qry_preview_invoices_line_items AS
    SELECT
        [Employer Name]
      , [Employer Key]
      , [Invoice Number]
      , [Billing Code QB]
      , [Billing Description]
      , [Billing Unit Count]
      , [Billing Unit Rate]
      , [Billing Amount]
    FROM
        dbo.[tbl_Billing Invoice Export All QuickBooks]
where isnull(ToDelete, 0) <> 1
go

