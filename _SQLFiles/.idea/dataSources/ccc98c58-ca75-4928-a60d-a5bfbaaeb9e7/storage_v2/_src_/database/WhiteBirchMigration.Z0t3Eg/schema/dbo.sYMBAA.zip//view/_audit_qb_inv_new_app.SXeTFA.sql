CREATE VIEW _audit_qb_inv_new_app AS
    SELECT *
    FROM
        dbo.[tbl_Billing Invoice Export All QuickBooks]
    WHERE
        ISNULL( ToDelete , 0 ) <> 1
go

