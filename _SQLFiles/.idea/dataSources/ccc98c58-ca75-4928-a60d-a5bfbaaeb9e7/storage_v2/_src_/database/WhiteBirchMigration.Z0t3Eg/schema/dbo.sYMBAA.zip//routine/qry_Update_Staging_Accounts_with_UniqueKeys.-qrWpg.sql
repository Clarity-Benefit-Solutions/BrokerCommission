CREATE PROCEDURE dbo.[QRY_UPDATE STAGING ACCOUNTS WITH UNIQUEKEYS] AS
    /* update StagingAccts set [UniqueKeyParticipant] and UniqueKeyParticipantAccounts from EmployerFields in same table */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_STAGING ACCOUNTS]
        SET
            [TBL_STAGING ACCOUNTS].uniquekeyparticipant         = ([TBL_STAGING ACCOUNTS].[EMPLOYER CODE] +
                                                                   [TBL_STAGING ACCOUNTS].[EMPLOYEE NUMBER])
          , [TBL_STAGING ACCOUNTS].uniquekeyparticipantaccounts = ([TBL_STAGING ACCOUNTS].[EMPLOYER CODE] +
                                                                   [TBL_STAGING ACCOUNTS].[EMPLOYEE NUMBER] +
                                                                   [TBL_STAGING ACCOUNTS].[ACCOUNT TYPE]);
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

