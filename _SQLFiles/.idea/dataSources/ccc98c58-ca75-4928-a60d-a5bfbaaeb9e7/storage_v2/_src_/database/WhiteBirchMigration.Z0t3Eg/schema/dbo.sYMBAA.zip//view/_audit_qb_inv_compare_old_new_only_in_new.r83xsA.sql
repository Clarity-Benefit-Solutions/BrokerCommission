/* QB inv only in new*/
    CREATE VIEW _audit_qb_inv_compare_old_new_only_in_new AS
    SELECT *
    FROM
        [_audit_qb_inv_compare_old_new_vw]
    WHERE
        [old_Employer Name] IS NULL
go

