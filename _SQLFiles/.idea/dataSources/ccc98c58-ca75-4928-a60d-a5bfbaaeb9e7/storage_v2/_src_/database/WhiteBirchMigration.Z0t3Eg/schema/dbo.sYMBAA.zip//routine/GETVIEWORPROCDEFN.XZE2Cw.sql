CREATE FUNCTION [DBO].[GETVIEWORPROCDEFN](
    @name nvarchar(200),
    @type nvarchar(10) ) RETURNS nvarchar(max)
    /* gets full ddl for view/proc*/
    BEGIN
        DECLARE @defn nvarchar(max)
        SELECT
            @defn = defn
        FROM
            (
                SELECT
                    p.[TYPE]
                  , p.[NAME]
                  , c.[DEFINITION] defn
                FROM
                    sys.objects p
                        JOIN sys.sql_modules c ON p.object_id = c.object_id
                WHERE
                    p.[NAME] = @name
            ) AS x;
        RETURN @defn;
    END
go

