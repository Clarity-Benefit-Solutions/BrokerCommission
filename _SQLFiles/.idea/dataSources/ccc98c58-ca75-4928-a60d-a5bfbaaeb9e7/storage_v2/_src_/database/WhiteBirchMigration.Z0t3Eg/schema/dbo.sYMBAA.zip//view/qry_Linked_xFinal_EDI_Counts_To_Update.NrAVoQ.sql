CREATE VIEW [	qry_Linked xFinal EDI Counts To Update	]
    AS
        SELECT
            [tbl_Final EDI Billing Group Counts].clientname
          , [tbl_Final EDI Billing Group Counts].[Alternate ER ID]
          , ([tbl_Final EDI Billing Group Counts].[Final Billable Counts]) newqty
          , [tbl_Final EDI Billing Group Counts].suppress
        FROM
            [tbl_Final EDI Billing Group Counts]
        WHERE
            ((([tbl_Final EDI Billing Group Counts].suppress) IS NULL))
go

