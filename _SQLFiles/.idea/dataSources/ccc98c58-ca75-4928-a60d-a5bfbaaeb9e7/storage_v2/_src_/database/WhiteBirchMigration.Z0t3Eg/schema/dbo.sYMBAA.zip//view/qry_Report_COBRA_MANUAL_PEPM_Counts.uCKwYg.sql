CREATE VIEW [dbo].[qry_Report COBRA MANUAL PEPM Counts]
    AS
        /* count EmplCtl records for CobraPEPM EDI billing   */
        SELECT
            [tbl_Employer Control].[Billing Group]
          , [tbl_Employer Control].[Employer Name]
          , [tbl_Employer Control].[Employer Key]
          , [tbl_Employer Control].[COBRA_BILLING CODE]
          , [tbl_Employer Control].[COBRA_PEPM TYPE]
          , [tbl_Employer Control].[COBRA_PEPM Count]
          , [tbl_Employer Control].[COBRA_PEPM FLG]
          , [tbl_Employer Control].[COBRA_PEPM AMOUNT]
        FROM
            [tbl_Employer Control]
        WHERE
            ((([tbl_Employer Control].[COBRA_PEPM TYPE]) = 'edi') AND (([tbl_Employer Control].[COBRA_PEPM FLG]) = 1))
go

