CREATE PROCEDURE dbo.[QRY_UPDATE EM EXTRACT FORMATTING DATE] AS
    /* update StagingEdi4 fix [alter Date Date] from exiting [Creation Date]  */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        UPDATE [TBL_STAGING EDI_4 SOURCE DATE]
        SET
            [TBL_STAGING EDI_4 SOURCE DATE].[CREATE DATE DATE] =
                    SUBSTRING( [TBL_STAGING EDI_4 SOURCE DATE].[CREATION DATE] , 5 , 2 ) + '/' +
                    RIGHT( [TBL_STAGING EDI_4 SOURCE DATE].[CREATION DATE] , 2 ) + '/' +
                    LEFT( [TBL_STAGING EDI_4 SOURCE DATE].[CREATION DATE] , 4 );
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

