CREATE PROCEDURE [dbo].[_process_append_all_to_monthly_min](
    @b_isnotforbundle int = 1 ) AS
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        BEGIN
            EXEC [dbo].[qry_Append Monthly Minimum COBRA To Min conversion tbl];
            EXEC [dbo].[qry_Append Monthly Minimum HRA To Min conversion tbl];
            EXEC [dbo].[qry_Append Monthly Minimum HSA To Min conversion tbl];
            EXEC [dbo].[qry_Append Monthly Minimum MED To Min conversion tbl];
            EXEC [dbo].[qry_Append Monthly Minimum TRNPKG To Min conversion tbl];
            IF @b_isnotforbundle = 1 or @b_isnotforbundle <> 1 /* embmerge3*/
                BEGIN
                    EXEC [dbo].[qry_Append Monthly Minimum BENADMIN To Min conversion tbl];
                END
        
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

