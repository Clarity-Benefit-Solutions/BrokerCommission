CREATE FUNCTION dbo.get_org_employer_name(
    @employerName nvarchar(255),
    @BillingDesc nvarchar(255) ) RETURNS nvarchar(255) AS
    BEGIN
        DECLARE @RetVal nvarchar(255);
        SET @RetVal = @employerName
        
        IF @BillingDesc LIKE '%COBRA MIN'
            BEGIN
                SET @RetVal = REPLACE( @BillingDesc , 'COBRA MIN' , '' )
            END
        ELSE
            IF @BillingDesc LIKE '%COBRA'
                BEGIN
                    SET @RetVal = REPLACE( @BillingDesc , 'COBRA' , '' )
                END
        
        RETURN @RetVal
    
    END
go

