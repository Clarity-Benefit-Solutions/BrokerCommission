CREATE VIEW [dbo].[x_QuickBooks Pro Invoice ImportFIX_falloutname]
    AS
        /* find null employer names  join by Client */
        
        SELECT DISTINCT
            insertonly_monthlyfix.*
        FROM
            insertonly_monthlyfix
                LEFT JOIN [x_QuickBooks Pro Invoice ImportFIX]
                          ON insertonly_monthlyfix.client = [x_QuickBooks Pro Invoice ImportFIX].[Employer Name]
        WHERE
            ((([x_QuickBooks Pro Invoice ImportFIX].[Employer Name]) IS NULL))
go

