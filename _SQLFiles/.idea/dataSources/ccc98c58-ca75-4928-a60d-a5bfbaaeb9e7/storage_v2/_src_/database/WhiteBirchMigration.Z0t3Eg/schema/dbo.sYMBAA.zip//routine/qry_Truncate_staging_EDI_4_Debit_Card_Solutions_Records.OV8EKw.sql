CREATE PROCEDURE dbo.[QRY_TRUNCATE STAGING EDI_4 DEBIT CARD SOLUTIONS RECORDS] AS
    /*  DELETE FROM [tbl_Staging EDI_4 Debit Card Summery] where [Admin Name]) = 'Solutions/BeneFlex'*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        DELETE
        FROM
            [TBL_STAGING EDI_4 DEBIT CARD SUMMERY]
        WHERE
            ((([TBL_STAGING EDI_4 DEBIT CARD SUMMERY].[ADMIN NAME]) = 'Solutions/BeneFlex'));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

