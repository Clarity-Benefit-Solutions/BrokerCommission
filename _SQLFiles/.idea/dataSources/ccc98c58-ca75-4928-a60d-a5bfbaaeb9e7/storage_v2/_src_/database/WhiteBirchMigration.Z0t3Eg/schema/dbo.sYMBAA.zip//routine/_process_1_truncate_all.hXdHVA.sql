CREATE  PROCEDURE dbo.[_process_1_truncate_all] AS

BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        
        BEGIN/*clear procedure cache - very important when debugging!*/
            DBCC FREEPROCCACHE
            
            /* log tables */
            TRUNCATE TABLE dbo.db_error_log;
            TRUNCATE TABLE dbo.db_message_log;
            
            /*--  truncate EDI Count staging tables*/
            EXEC dbo.[qry_Truncate Client List Generated Table];
            EXEC dbo.[qry_Truncate Client Master Broker List Table];
            EXEC dbo.[qry_Truncate QBACADetailReportStaging];
            EXEC dbo.[qry_Truncate NPN Report Staging];
            EXEC dbo.[qry_Truncate COBRA Letters];
            EXEC dbo.[qry_Truncate SPMBYACAREPORT];
            
            /*-- truncate EDI Count process tables*/
            EXEC dbo.[qry_Truncate NPM Report Distinct];
            EXEC dbo.[qry_Truncate QB TE];
            EXEC dbo.[qry_Truncate QB TP];
            EXEC dbo.[qry_Truncate tbl NPM Count];
            EXEC dbo.[qry_Truncate Final EDI Billable table];
            EXEC dbo.[qry_Truncate SPMBYACAREPORTING Distinct];
            
            /* edi 5*/
            EXEC [QRY_TRUNCATE STAGING_EDI_5 SOURCE DATA];
            EXEC [qry_Truncate Staging_EDI_5_NON PLN Records];
            /* ec */
            EXEC [QRY_TRUNCATE STAGING EC EXTRACT];
            /* EB*/
            EXEC [qry_Truncate Staging EB Extract];
            EXEC [qry_Truncate Staging EB Records Remove EA];
            
            /*EDI 4 - Alegeus Debit Cards*/
            EXEC [qry_Truncate Staging EDI_4 Debit Card Summary];
            EXEC [qry_Truncate staging EDI_4 Debit Card Solutions Records];
            EXEC [qry_Truncate staging EDI_4 Debit Card Header Records];
            /* Cobra */
            EXEC [qry_Truncate Staging COBRA Client List Table];
            EXEC [qry_Truncate Staging COBRA Letters Summary];
            /* EDI 2*/
            EXEC [qry_Truncate Staging EDI_2 Data Source];
            /* edi 6 */
            EXEC [qry_Truncate Staging EDI_6 Source Data];
            /* edi 3 - Paylocity Final Counts*/
            EXEC [qry_Truncate Staging EDI_3 Source Data];
            /* process tables*/
            EXEC [QRY_TRUNCATE TBL_STAGING ACCOUNTS];
            EXEC [QRY_TRUNCATE TBL_PROCESS TABLE];
            EXEC [QRY_TRUNCATE TBL_PROCESS TABLE ALL BACKUP];
            EXEC [QRY_TRUNCATE BILLING INVOICE EXPORT];
            EXEC [QRY_TRUNCATE TBL_BACKUP REPORTING EXPORT TABLE];
            EXEC [QRY_TRUNCATE BILLING INVOICE EXPORT ALL QUICKBOOKS];
            EXEC [QRY_TRUNCATE MONTHLY MINIMUM CONVERSION INVOICE TBL];
            EXEC [QRY_TRUNCATE MONTHLY MINIMUM CONVERSION TBL];
            
            /*sumeet -never truncxate - we need it to comp[are with prv period invoices */
            /*EXEC dbo.[QRY_TRUNCATE BILLING INVOICE EXPORT ARCHIVE]*/
        END;
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int =50001, @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW 500001, @errmessage, @errseverity;
    END CATCH;
END;
go

