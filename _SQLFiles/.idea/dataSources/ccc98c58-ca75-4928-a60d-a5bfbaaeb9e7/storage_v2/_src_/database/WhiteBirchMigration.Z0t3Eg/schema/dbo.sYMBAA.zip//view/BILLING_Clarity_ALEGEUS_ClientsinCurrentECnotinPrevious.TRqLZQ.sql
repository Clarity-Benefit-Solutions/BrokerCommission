CREATE VIEW [dbo].[BILLING_Clarity_ALEGEUS_ClientsinCurrentECnotinPrevious]
    AS
        /* all clients in current export but not in previous*/
        SELECT DISTINCT
            [Clarity_BillableClientsfromECwNameTBL].[Billing Group]
          , [Clarity_BillableClientsfromECwNameTBL].[Billable Account]
          , IIF( [Clarity_BillableClientsfromECwNameTBL].[employer Name] IS NULL , 'Not found in WB' ,
                 [Clarity_BillableClientsfromECwNameTBL].[employer Name] ) emp_name
          , [Clarity_BillableClientsfromECwNameTBL].[BENCODE]
          , [Clarity_BillableClientsfromECwNameTBL].[Notes]
          , 'In Current EC not in Previous' fallouttype
        FROM
            [Clarity_BillableClientsfromECwNameTBL]
                LEFT JOIN [Clarity_BillableClientsfromECPreviouswNameTBL]
                          ON [Clarity_BillableClientsfromECwNameTBL].[Employer Name] =
                             [Clarity_BillableClientsfromECPreviouswNameTBL].[Employer Name]
        WHERE
            ((([Clarity_BillableClientsfromECPreviouswNameTBL].[Employer Name]) IS NULL))
go

exec sp_addextendedproperty 'MS_SSMA_SOURCE' ,
     N'ClarityAuditSystemv4.[BILLING_Clarity_ALEGEUS_ClientsinCurrentECnotinPrevious]' , 'SCHEMA' , 'dbo' , 'VIEW' ,
     'BILLING_Clarity_ALEGEUS_ClientsinCurrentECnotinPrevious'
go

