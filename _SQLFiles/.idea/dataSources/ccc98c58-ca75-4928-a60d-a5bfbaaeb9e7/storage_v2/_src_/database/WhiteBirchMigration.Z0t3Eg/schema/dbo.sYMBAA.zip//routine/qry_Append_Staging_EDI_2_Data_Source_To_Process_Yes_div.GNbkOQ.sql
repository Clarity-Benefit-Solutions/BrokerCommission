CREATE PROCEDURE dbo.[QRY_APPEND STAGING EDI_2 DATA SOURCE TO PROCESS YES DIV] AS
    /* inserts EMPCTL records matching
       [BEN_BEN ADMIN FLG]) = 1) AND
       [Benefit Class Benefit Eligible]) = 'Y'
    into Process */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_PROCESS TABLE] (
                                     process,
                                     [EMPLOYER NAME],
                                     [BILLING GROUP],
                                     [EMPLOYER KEY],
                                     [SYSTEM EMPLOYER CODE],
                                     [EMPLOYER BILLING NUMBER],
                                     [BROKER CODE],
                                     [PARTICIPANT ID],
                                     [FIRST NAME],
                                     [LAST NAME],
                                     [ACCOUNT TYPE],
                                     [PLAN NAME],
                                     uniquekeyparticipant,
                                     uniquekeyaccount,
                                     uniquekeybillingaccount,
                                     [BILLING CODE],
                                     [PEPM FLG],
                                     [PEPM AMOUNT],
                                     [PAID BY BROKER FLG],
                                     [PAID BY BROKER PERCENT],
                                     [PAID BY EMPLOYER FLG],
                                     [PAID BY EMPLOYER PERCENT],
                                     [KEY_MM MONTHLY MINIMUM],
                                     [MONTHLY MINIMUM FLG],
                                     [MONTHLY MINIMUM AMOUNT]
        )
        SELECT
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_STAGING EDI_2 SOURCE DATA].[EMPLOYEE ID]
          , [TBL_STAGING EDI_2 SOURCE DATA].[FIRST NAME]
          , [TBL_STAGING EDI_2 SOURCE DATA].[LAST NAME]
          , 'BEN' [ACCOUNT TYPE]
          , '' [BEN_BEN PLAN ID]
          , [TBL_STAGING EDI_2 SOURCE DATA].participantuniquekey
          , ([TBL_STAGING EDI_2 SOURCE DATA].[PARTICIPANTUNIQUEKEY]) uniquekeyaccount
          , ([TBL_STAGING EDI_2 SOURCE DATA].[PARTICIPANTUNIQUEKEY]) uniquekeybillingaccount
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN FLG]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN PEPM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN_PAID BY BROKER FLG]
          , '' [COBRA_PAID BY BROKER PERCENT]
          , '' [COBRA_PAID BY EMPLOYER FLG]
          , '' [COBRA_PAID BY EMPLOYER PERCENT]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN_KEY MONTHLY MINIMUM]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN_MONTHLY MINIMUM FLG]
          , [TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN_MONTHLY MINIMUM AMOUNT]
        FROM
            [TBL_EMPLOYER CONTROL]
                INNER JOIN [TBL_STAGING EDI_2 SOURCE DATA] ON /* sumeet: EMBMERGE*/
            /*[TBL_EMPLOYER CONTROL].[EMPLOYER KEY] */ [TBL_STAGING EDI_2 SOURCE DATA].division IN
                                                       ([TBL_EMPLOYER CONTROL].[Employer Key Ben Admin],
                                                        [TBL_EMPLOYER CONTROL].[EMPLOYER KEY])
        WHERE
            ((([TBL_EMPLOYER CONTROL].process) = 1) AND (([TBL_EMPLOYER CONTROL].[BEN_BEN ADMIN FLG]) = 1) AND
             (([TBL_STAGING EDI_2 SOURCE DATA].[BENEFIT CLASS BENEFIT ELIGIBLE]) = 'Y'));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

