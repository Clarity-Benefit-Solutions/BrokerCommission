CREATE PROCEDURE dbo.[QRY_APPEND PROCESS TBL TO FINAL BILLING EXPORT PEPM ONLY] AS
    /* inserts all sum(amts) [QRY_PROCESS TBL TO FINAL BILLING EXPORT PEPM ONLY COUNTS] into InvExp */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT] (
                                              [EMPLOYER NAME],
                                              [SYSTEM EMPLOYER KEY],
                                              [BILLING GROUP],
                                              [EMPLOYER KEY],
                                              [BROKER CODE],
                                              [EMPLOYER BILLING NUMBER],
                                              [BROKER NAME],
                                              [BILLING CODE],
                                              [KEY_MM MONTHLY MINIMUM],
                                              [MONTHLY MIN BILLING AMOUNT],
                                              [MONTHLY MIN BILLING FLG],
                                              [BILLING UNIT RATE],
                                              [BILLING AMOUNT],
                                              [CALCULATED BILLING AMOUNT],
                                              [BILLING UNIT COUNT],
                                              [PAID BY BROKER FLG]
        )
        SELECT
            [EMPLOYER NAME]
          , [SYSTEM EMPLOYER CODE]
          , [BILLING GROUP]
          , [EMPLOYER KEY]
          , [BROKER CODE]
          , [EMPLOYER BILLING NUMBER]
          , [BROKER NAME]
          , [BILLING CODE]
          , [KEY_MM MONTHLY MINIMUM]
          , [MONTHLY MINIMUM AMOUNT]
          , [MONTHLY MINIMUM FLG]
          , [PEPM AMOUNT]
          , [BILLING AMOUNT]
          , [CALCULATED BILLING AMOUNT]
          , countofuniquekeyparticipant
          , [PAID BY BROKER FLG]
        FROM
            [QRY_PROCESS TBL TO FINAL BILLING EXPORT PEPM ONLY TOTALS];
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

