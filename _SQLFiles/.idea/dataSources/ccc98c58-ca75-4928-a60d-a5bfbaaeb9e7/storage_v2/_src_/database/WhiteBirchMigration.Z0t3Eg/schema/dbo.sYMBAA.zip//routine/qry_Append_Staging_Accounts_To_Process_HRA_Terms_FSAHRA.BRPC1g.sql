CREATE PROCEDURE dbo.[QRY_APPEND STAGING ACCOUNTS TO PROCESS HRA TERMS FSAHRA] AS
    /* inserts EMPCTL records matching
 Staging.[Participant Status]) = 'Terminated') AND
                [BND_BILLING CODE]) = 'FSAHRA') AND
                [BND_BUNDLE BILL FLG] = 1

into Process */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_PROCESS TABLE] (
                                     process,
                                     [EMPLOYER NAME],
                                     [EMPLOYER KEY],
                                     [BILLING GROUP],
                                     [SYSTEM EMPLOYER CODE],
                                     [EMPLOYER BILLING NUMBER],
                                     [BROKER CODE],
                                     [PARTICIPANT ID],
                                     division,
                                     [FIRST NAME],
                                     [LAST NAME],
                                     [ACCOUNT TYPE],
                                     [PLAN NAME],
                                     [PLAN START DATE],
                                     [PLAN END DATE],
                                     [PARTICIPANT STATUS],
                                     [PARTICIPANT TERM DATE],
                                     [ALLOW CLAIMS IMPORT],
                                     uniquekeyparticipant,
                                     uniquekeyaccount,
                                     uniquekeybillingaccount,
                                     [BILLING CODE],
                                     [PEPM FLG],
                                     [PEPM AMOUNT],
                                     [KEY_MM MONTHLY MINIMUM],
                                     [MONTHLY MINIMUM FLG],
                                     [MONTHLY MINIMUM AMOUNT],
                                     [FLAT RATE FLG],
                                     [FLAT RATE AMOUNT],
                                     [PAID BY BROKER FLG],
                                     [PAID BY BROKER PERCENT],
                                     [PAID BY EMPLOYER FLG],
                                     [PAID BY EMPLOYER PERCENT],
                                     [BND_BILLING CODE],
                                     [BND_BUNDLE BILL FLG],
                                     [BND_BUNDLE RATE AMOUNT]
        )
        SELECT
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_STAGING ACCOUNTS].[EMPLOYEE NUMBER]
          , [TBL_STAGING ACCOUNTS].[DIVISION IB RECORDS]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT FIRST NAME]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT LAST NAME]
          , [TBL_EMPLOYER CONTROL].[HRA_ACCOUNT TYPE]
          , [TBL_EMPLOYER CONTROL].[HRA_PLAN NAME]
          , [TBL_STAGING ACCOUNTS].[PLAN START DATE DT]
          , [TBL_STAGING ACCOUNTS].[PLAN END DATE DT]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT STATUS]
          , [TBL_STAGING ACCOUNTS].[TERMINATION DATE DT]
          , '' [ALLOW CLAIMS IMPORT]
          , [TBL_STAGING ACCOUNTS].uniquekeyparticipant
          , [TBL_STAGING ACCOUNTS].uniquekeyparticipantaccounts
          , ([TBL_STAGING ACCOUNTS].[EMPLOYER CODE] + [TBL_STAGING ACCOUNTS].[EMPLOYEE NUMBER] +
             [TBL_EMPLOYER CONTROL].[HRA_BILLING CODE]) uniquekeybillingaccount
          , [TBL_EMPLOYER CONTROL].[HRA_BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[HRA_PEPM FLG]
          , [TBL_EMPLOYER CONTROL].[HRA_PEPM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[KEY_MMHRA MONTHLY MINUMUM]
          , [TBL_EMPLOYER CONTROL].[HRA_MONTHLY MINIMUM FLG]
          , [TBL_EMPLOYER CONTROL].[HRA_MONTHLY MINIMUM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[HRA_FLAT RATE FLG]
          , [TBL_EMPLOYER CONTROL].[HRA_FLAT RATE AMOUNT]
          , [TBL_EMPLOYER CONTROL].[HRA_PAID BY BROKER FLG]
          , [TBL_EMPLOYER CONTROL].[HRA_PAID BY BROKER PERCENT]
          , [TBL_EMPLOYER CONTROL].[HRA_PAID BY EMPLOYER FLG]
          , [TBL_EMPLOYER CONTROL].[HRA_PAID BY EMPLOYER PERCENT]
          , [TBL_EMPLOYER CONTROL].[BND_BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[BND_BUNDLE BILL FLG]
          , [TBL_EMPLOYER CONTROL].[BND_BUNDLE RATE AMOUNT]
        FROM
            [TBL_EMPLOYER CONTROL]
                INNER JOIN [TBL_STAGING ACCOUNTS]
                           ON ([TBL_STAGING ACCOUNTS].[EMPLOYER CODE] = [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]) AND
                              ([TBL_EMPLOYER CONTROL].[HRA_ACCOUNT TYPE] = [TBL_STAGING ACCOUNTS].[ACCOUNT TYPE])
        WHERE
            ((([TBL_STAGING ACCOUNTS].[TERM BILLABLE ACCOUNTS]) = 'Billable') AND
             (([TBL_STAGING ACCOUNTS].[ACCOUNT STATUS]) <> 'Perminactive'))
        GROUP BY
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_STAGING ACCOUNTS].[EMPLOYEE NUMBER]
          , [TBL_STAGING ACCOUNTS].[DIVISION IB RECORDS]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT FIRST NAME]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT LAST NAME]
          , [TBL_EMPLOYER CONTROL].[HRA_ACCOUNT TYPE]
          , [TBL_EMPLOYER CONTROL].[HRA_PLAN NAME]
          , [TBL_STAGING ACCOUNTS].[PLAN START DATE DT]
          , [TBL_STAGING ACCOUNTS].[PLAN END DATE DT]
          , [TBL_STAGING ACCOUNTS].[PARTICIPANT STATUS]
          , [TBL_STAGING ACCOUNTS].[TERMINATION DATE DT]
          , [TBL_STAGING ACCOUNTS].uniquekeyparticipant
          , [TBL_STAGING ACCOUNTS].uniquekeyparticipantaccounts
          , ([TBL_STAGING ACCOUNTS].[EMPLOYER CODE] + [TBL_STAGING ACCOUNTS].[EMPLOYEE NUMBER] +
             [TBL_EMPLOYER CONTROL].[HRA_BILLING CODE])
          , [TBL_EMPLOYER CONTROL].[HRA_BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[HRA_PEPM FLG]
          , [TBL_EMPLOYER CONTROL].[HRA_PEPM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[KEY_MMHRA MONTHLY MINUMUM]
          , [TBL_EMPLOYER CONTROL].[HRA_MONTHLY MINIMUM FLG]
          , [TBL_EMPLOYER CONTROL].[HRA_MONTHLY MINIMUM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[HRA_FLAT RATE FLG]
          , [TBL_EMPLOYER CONTROL].[HRA_FLAT RATE AMOUNT]
          , [TBL_EMPLOYER CONTROL].[HRA_PAID BY BROKER FLG]
          , [TBL_EMPLOYER CONTROL].[HRA_PAID BY BROKER PERCENT]
          , [TBL_EMPLOYER CONTROL].[HRA_PAID BY EMPLOYER FLG]
          , [TBL_EMPLOYER CONTROL].[HRA_PAID BY EMPLOYER PERCENT]
          , [TBL_EMPLOYER CONTROL].[BND_BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[BND_BUNDLE BILL FLG]
          , [TBL_EMPLOYER CONTROL].[BND_BUNDLE RATE AMOUNT]
        HAVING
            ((([TBL_EMPLOYER CONTROL].process) = 1) AND
             (([TBL_STAGING ACCOUNTS].[PARTICIPANT STATUS]) = 'Terminated') AND
             (([TBL_EMPLOYER CONTROL].[BND_BILLING CODE]) = 'FSAHRA') AND
             (([TBL_EMPLOYER CONTROL].[BND_BUNDLE BILL FLG]) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

