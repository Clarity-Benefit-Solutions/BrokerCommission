CREATE VIEW [dbo].[vw_InsertOnly_MonthlyFix]
    AS
        /*
        select some employers from ImportFIx
        */
        SELECT
            [x_QuickBooks Pro Invoice ImportFIX3].*
        FROM
            [x_QuickBooks Pro Invoice ImportFIX3]
        WHERE
            ((([x_QuickBooks Pro Invoice ImportFIX3].[employer name]) LIKE '*Metropolitan Arts & Antiques Pavilion*' OR
              ([x_QuickBooks Pro Invoice ImportFIX3].[employer name]) LIKE '*OutboundEngine*'))
go

