CREATE PROCEDURE [dbo].[QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES FROM PROCESS AND BACKUP] AS
BEGIN
    
    DECLARE @msg1 nvarchar(max)
    DECLARE @rowno int = 0
    DECLARE @continue int = 0
    /**/
    
    DECLARE @employer_name nvarchar(500);
    DECLARE @org_employer_name nvarchar(500);
    DECLARE @billing_code nvarchar(500);
    DECLARE @billing_code_qb nvarchar(500);
    DECLARE @deleteReason nvarchar(500);
    DECLARE @toDelete int;
    
    SET @continue = 1
    
    DECLARE db_cursor CURSOR FOR
        SELECT
            [Employer Name]
          , [Original Employer Name]
          , [Billing Code]
          , [Billing Code QB]
          , ToDelete
          , DeleteReason
        FROM
            dbo.[tbl_Billing Invoice Export All QuickBooks]
        WHERE
            ToDelete = 1
        ORDER BY
            [Employer Name]
          , [Original Employer Name]
          , [Billing Code]
          , [Billing Code QB];
    
    EXEC db_log_message 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES FROM PROCESS AND BACKUP' ,
         ' OPENING CURSOR' ,
         'INFO';
    
    /**/
    OPEN db_cursor
    /**/
    
    WHILE @continue = 1 BEGIN
        FETCH NEXT FROM db_cursor INTO
            @employer_name, @org_employer_name, @billing_code, @billing_code_qb, @toDelete, @deleteReason
        /**/
        IF @@FETCH_STATUS <> 0
            BEGIN
                SET @continue = 0
                BREAK
            END
        /**/
        
        SET @rowno = @rowno + 1;
        BEGIN TRY
            SET @msg1 = CONCAT( '#RowNo ' , @rowno , 'Processing Emp: ' , @employer_name , ', Org Emp: ' ,
                                @org_employer_name , ', Billing Code: ' , @billing_code , ', Biling Code QB: ' ,
                                @billing_code_qb ,
                                ', ToDelete: ' , @toDelete
                )
            
            EXEC db_log_message
                 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES FROM PROCESS AND BACKUP' , @msg1 ,
                 'INFO';
            
            IF @toDelete = 1
                BEGIN
                    /* UPDATE [TBL_PROCESS TABLE ALL BACKUP] */
                    UPDATE [TBL_PROCESS TABLE ALL BACKUP]
                    SET
                        ToDelete    =1,
                        DeleteReason=@deleteReason
                    WHERE
                          [Employer Name] = @employer_name
                      AND ISNULL( [ORIGINAL EMPLOYER NAME] , [Employer Name] ) =
                          ISNULL( @org_employer_name , @employer_name )
                      AND ([BILLING CODE] = @billing_code OR [QB Billing Code] = @billing_code_qb);
                    
                    /* UPDATE [TBL_PROCESS TABLE ALL BACKUP] */
                    UPDATE [TBL_BACKUP REPORTING EXPORT TABLE]
                    SET
                        ToDelete    =1,
                        DeleteReason=@deleteReason
                    WHERE
                          [Employer Name] = @employer_name
                      AND ISNULL( [ORIGINAL EMPLOYER NAME] , [Employer Name] ) =
                          ISNULL( @org_employer_name , @employer_name )
                      AND (
                                  [BILLING CODE] = @billing_code OR [BILLING CODE] = @billing_code_qb
                                  OR [ACTUAL_BILLING CODE] = @billing_code OR [ACTUAL_BILLING CODE] = @billing_code_qb);
                END;
            
            /**/
        END TRY BEGIN CATCH
            SET @msg1 = CONCAT( @rowno , ' - ' , 'ERROR: ' , ERROR_MESSAGE( ) , ' FOR RECORD ' , @msg1 );
            EXEC db_log_error 50001 , 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' , @msg1 ,
                 'ERROR';
        END CATCH
        
        /**/
    END
    /* while*/
    
    /**/
    CLOSE db_cursor
    DEALLOCATE db_cursor
    
    /* show deletes [TBL_PROCESS TABLE ALL BACKUP]*/
    SELECT *
    FROM
        dbo.[TBL_PROCESS TABLE ALL BACKUP]
    WHERE
          ToDelete = 1
      AND DeleteReason LIKE '%REMDUPS%'
    ORDER BY
        [Employer Name]
      , [Original Employer Name]
      , [Billing Code]
      , [QB Billing Code];
    
    /* show deletes dbo.[TBL_BACKUP REPORTING EXPORT TABLE]*/
    SELECT *
    FROM
        dbo.[TBL_BACKUP REPORTING EXPORT TABLE]
    WHERE
          ToDelete = 1
      AND DeleteReason LIKE '%REMDUPS%'
    ORDER BY
        [Employer Name]
      , [Original Employer Name]
      , [Billing Code]
    /*, [QB Billing Code]*/;
    
    /**/
    
    SET @msg1 = CONCAT( '**LOG** ' , 'QRY_FIX BILLING INVOICE EXPORT QUICKBOOKS REMOVE DUPLICATED CODES' ,
                        ' FINISHED ROW COUNT: ' , @rowno );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT

END
go

