CREATE VIEW vw_utils_compare_qb_inv_old_new_app
    AS
        SELECT
            '1 OLD APP' TableName
          , t.[ORIGINAL EMPLOYER NAME]
          , t.[Employer Name]
          , t.[BILLING CODE]
          , t.[Billing Unit Count]
          , t.[Billing Amount]
          , t.[Billing Code QB]
          , t.[Billing Description]
          , t.[Billing Group Process]
          , t.ToDelete
          , t.[Employer Key]
          , t.RecordID
        FROM
            dbo.[_ExportedInvoices-App-LastMonth-qb] t
        WHERE
              1 = 1
          AND ISNULL( t.ToDelete , 0 ) <> 1
        UNION ALL
        /* inv by emp name*/
        SELECT
            '2 NEW APP' TableName
          , t.[ORIGINAL EMPLOYER NAME]
          , t.[Employer Name]
          , t.[BILLING CODE]
          , t.[Billing Unit Count]
          , t.[Billing Amount]
          , t.[Billing Code QB]
          , t.[Billing Description]
          , t.[Billing Group Process]
          , t.ToDelete
          , t.[Employer Key]
          , t.RecordID
        FROM
            dbo.[tbl_Billing Invoice Export All QuickBooks] t
        WHERE
              1 = 1
          AND ISNULL( t.ToDelete , 0 ) <> 1
go

