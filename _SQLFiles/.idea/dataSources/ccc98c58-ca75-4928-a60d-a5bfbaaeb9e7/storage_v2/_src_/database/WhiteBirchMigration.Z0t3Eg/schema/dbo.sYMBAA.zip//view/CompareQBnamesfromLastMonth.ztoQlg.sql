CREATE VIEW [dbo].[CompareQBnamesfromLastMonth]
    AS
        /* join export clients with QBClients on EmployerName   */
        SELECT DISTINCT
            [tbl_Billing Invoice Export All QuickBooks].[Billing Group]
          , [tbl_Billing Invoice Export All QuickBooks].[Employer Name]
          , [tbl_Billing Invoice Export All QuickBooks].[Employer Key]
          , clarity_qb_customers.name
        FROM
            [tbl_Billing Invoice Export All QuickBooks]
                LEFT JOIN clarity_qb_customers
                          ON [tbl_Billing Invoice Export All QuickBooks].[Employer Name] = clarity_qb_customers.name
        WHERE
            (((clarity_qb_customers.name) IS NULL))
go

