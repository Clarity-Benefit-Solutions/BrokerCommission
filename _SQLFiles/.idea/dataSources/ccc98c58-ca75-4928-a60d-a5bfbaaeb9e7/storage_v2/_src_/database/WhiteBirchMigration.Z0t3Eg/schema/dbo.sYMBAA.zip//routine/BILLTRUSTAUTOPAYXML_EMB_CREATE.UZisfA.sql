CREATE PROCEDURE dbo.[BILLTRUSTAUTOPAYXML_EMB_CREATE] AS
    /* invalid : bswift_qb_customers table is missing !!!*/
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        SELECT DISTINCT
            bswift_qb_customers.companyname c1
          , 'C' accountype
          , bswift_qb_customers.companyname c2
          , emb_bank_info.[BANK NAME]
          , emb_bank_info.[ROUTING NUMBER]
          , emb_bank_info.[ACCOUNT NUMBER]
          , 'N' autopay
          , '9999999' autopaythresh
          , IIF( LEN( [ACCOUNT NUMBER] ) > 5 AND LEN( [ROUTING NUMBER] ) > 5 AND [BANK NAME] <> 'Check Client' AND
                 [BANK NAME] <> 'Unknown' , 'Y' , 'N' ) designatedpayment
          , bswift_qb_customers.customfieldgroup_number acct_num
          , emb_bank_info.[EMAIL 1]
          , 'N' sendpaper
          , 'Y' emailnotify
          , 'Y' emailconfirm
          , 'Clarity1' [PASSWORD]
          , IIF( [ACCOUNT NUMBER] = 'Check Client' , 'N' , 'Y' ) managedaccount
        INTO billtrust_autopayxml_emb
        FROM
            bswift_qb_customers
                INNER JOIN emb_bank_info ON bswift_qb_customers.customfieldgroup_number = emb_bank_info.bencode
        WHERE
            (((bswift_qb_customers.isactive) <> 0));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

