CREATE PROCEDURE dbo.[QRY_APPEND PROCESS TBL TO FINAL BILLING EXPORT BASE-COBRABASE] AS
    /* inserts all Process records matching [TBL_PROCESS TABLE].[BILLING CODE]) in (COBRA BASE,BASE and [PEPM FLG]) = 1 into InvExp */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_BILLING INVOICE EXPORT] (
                                              [EMPLOYER NAME],
                                              [SYSTEM EMPLOYER KEY],
                                              [BILLING GROUP],
                                              [EMPLOYER KEY],
                                              [BROKER CODE],
                                              [EMPLOYER BILLING NUMBER],
                                              [BROKER NAME],
                                              [BILLING CODE],
                                              [KEY_MM MONTHLY MINIMUM],
                                              [MONTHLY MIN BILLING AMOUNT],
                                              [MONTHLY MIN BILLING FLG],
                                              [BILLING UNIT RATE],
                                              [BILLING UNIT COUNT],
                                              [BILLING AMOUNT],
                                              [CALCULATED BILLING AMOUNT],
                                              [PAID BY BROKER FLG]
        )
        SELECT
            [TBL_PROCESS TABLE].[EMPLOYER NAME]
          , [TBL_PROCESS TABLE].[SYSTEM EMPLOYER CODE]
          , [TBL_PROCESS TABLE].[BILLING GROUP]
          , [TBL_PROCESS TABLE].[EMPLOYER KEY]
          , [TBL_PROCESS TABLE].[BROKER CODE]
          , [TBL_PROCESS TABLE].[EMPLOYER BILLING NUMBER]
          , [TBL_PROCESS TABLE].[BROKER NAME]
          , [TBL_PROCESS TABLE].[BILLING CODE]
          , [TBL_PROCESS TABLE].[KEY_MM MONTHLY MINIMUM]
          , [TBL_PROCESS TABLE].[MONTHLY MINIMUM AMOUNT]
          , [TBL_PROCESS TABLE].[MONTHLY MINIMUM FLG]
          , [TBL_PROCESS TABLE].[PEPM AMOUNT]
          , SUM( [TBL_PROCESS TABLE].[PEPM COUNT] ) [SUMOFPEPM COUNT]
          , SUM( ([TBL_PROCESS TABLE].[PEPM COUNT] * [TBL_PROCESS TABLE].[PEPM AMOUNT]) ) [BILLING AMOUNT]
          , SUM( ([TBL_PROCESS TABLE].[PEPM COUNT] * [TBL_PROCESS TABLE].[PEPM AMOUNT]) ) [CALCULATED BILLING AMOUNT]
          , [TBL_PROCESS TABLE].[PAID BY BROKER FLG]
        FROM
            [TBL_PROCESS TABLE]
        GROUP BY
            [TBL_PROCESS TABLE].[EMPLOYER NAME]
          , [TBL_PROCESS TABLE].[SYSTEM EMPLOYER CODE]
          , [TBL_PROCESS TABLE].[BILLING GROUP]
          , [TBL_PROCESS TABLE].[EMPLOYER KEY]
          , [TBL_PROCESS TABLE].[BROKER CODE]
          , [TBL_PROCESS TABLE].[EMPLOYER BILLING NUMBER]
          , [TBL_PROCESS TABLE].[BROKER NAME]
          , [TBL_PROCESS TABLE].[BILLING CODE]
          , [TBL_PROCESS TABLE].[KEY_MM MONTHLY MINIMUM]
          , [TBL_PROCESS TABLE].[MONTHLY MINIMUM AMOUNT]
          , [TBL_PROCESS TABLE].[MONTHLY MINIMUM FLG]
          , [TBL_PROCESS TABLE].[PEPM AMOUNT]
          , [TBL_PROCESS TABLE].[PAID BY BROKER FLG]
          , [TBL_PROCESS TABLE].[PEPM FLG]
        HAVING
            ((([TBL_PROCESS TABLE].[BILLING CODE]) = 'BASE' OR ([TBL_PROCESS TABLE].[BILLING CODE]) = 'COBRA BASE') AND
             (([TBL_PROCESS TABLE].[PEPM FLG]) = 1));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    END CATCH;
END;
go

