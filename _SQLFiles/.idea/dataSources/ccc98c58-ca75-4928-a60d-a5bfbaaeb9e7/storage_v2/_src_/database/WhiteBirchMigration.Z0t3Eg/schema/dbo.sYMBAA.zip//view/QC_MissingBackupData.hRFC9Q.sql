CREATE VIEW [dbo].[QC_MissingBackupData]
    AS
        /* all invoices not in backup ? bnew invoices   */
        SELECT DISTINCT
            [x_QuickBooks Pro Invoice Import].[Employer Name]
          , [x_QuickBooks Pro Invoice Import].[Employer Key]
          , [x_QuickBooks Pro Invoice Import].[Invoice Number]
          , qc_backup_invoices.[Backup Invoice Number]
          , [x_QuickBooks Pro Invoice Import].[Billing Period]
        FROM
            qc_backup_invoices
                RIGHT JOIN [x_QuickBooks Pro Invoice Import] ON qc_backup_invoices.[Backup Invoice Number] =
                                                                [x_QuickBooks Pro Invoice Import].[Invoice Number]
        WHERE
            (((qc_backup_invoices.[Backup Invoice Number]) IS NULL))
go

