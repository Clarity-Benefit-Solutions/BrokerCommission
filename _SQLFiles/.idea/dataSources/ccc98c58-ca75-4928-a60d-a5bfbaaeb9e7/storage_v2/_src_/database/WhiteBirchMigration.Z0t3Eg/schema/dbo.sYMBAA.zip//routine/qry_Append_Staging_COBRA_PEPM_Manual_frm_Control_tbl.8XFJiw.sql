CREATE PROCEDURE dbo.[QRY_APPEND STAGING COBRA PEPM MANUAL FRM CONTROL TBL] AS
    /* inserts EMPCTL records matching
       [COBRA_PEPM FLG]) = 1 AND
       [COBRA_PEPM TYPE]) = 'Manual'
    into Process */
BEGIN
    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +
                                                QUOTENAME( OBJECT_NAME( @@PROCID ) );
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
        --
        INSERT
            INTO [TBL_PROCESS TABLE] (
                                     process,
                                     [BILLING GROUP],
                                     [EMPLOYER NAME],
                                     [EMPLOYER KEY],
                                     [EMPLOYER BILLING NUMBER],
                                     [SYSTEM EMPLOYER CODE],
                                     [BROKER CODE],
                                     [ACCOUNT TYPE],
                                     [PLAN NAME],
                                     [BILLING CODE],
                                     [KEY_MM MONTHLY MINIMUM],
                                     [PEPM COUNT],
                                     [PEPM AMOUNT],
                                     [PEPM FLG],
                                     [MONTHLY MINIMUM FLG],
                                     [MONTHLY MINIMUM AMOUNT],
                                     [PAID BY BROKER FLG],
                                     [PAID BY BROKER PERCENT],
                                     [PAID BY EMPLOYER FLG],
                                     [PAID BY EMPLOYER PERCENT]
        )
        SELECT
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , 'COBRA MANUAL' [ACCOUNT TYPE]
          , 'COBRA MANUAL' [PLAN NAME]
          , [TBL_EMPLOYER CONTROL].[COBRA_BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[COBRA_KEY MM MONTHLY MINUMUM]
          , SUM( [TBL_EMPLOYER CONTROL].[COBRA_PEPM COUNT] ) [SUMOFCOBRA_PEPM COUNT]
          , [TBL_EMPLOYER CONTROL].[COBRA_PEPM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[COBRA_PEPM FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_MONTHLY MINIMUM FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_MONTHLY MINIMUM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY BROKER FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY BROKER PERCENT]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY EMPLOYER FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY EMPLOYER PERCENT]
        FROM
            [TBL_EMPLOYER CONTROL]
        GROUP BY
            [TBL_EMPLOYER CONTROL].process
          , [TBL_EMPLOYER CONTROL].[BILLING GROUP]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER NAME]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER KEY]
          , [TBL_EMPLOYER CONTROL].[EMPLOYER BILLING NUMBER]
          , [TBL_EMPLOYER CONTROL].[SYSTEM EMPLOYER CODE]
          , [TBL_EMPLOYER CONTROL].[BROKER CODE]
          , [TBL_EMPLOYER CONTROL].[COBRA_BILLING CODE]
          , [TBL_EMPLOYER CONTROL].[COBRA_KEY MM MONTHLY MINUMUM]
          , [TBL_EMPLOYER CONTROL].[COBRA_PEPM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[COBRA_PEPM FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_MONTHLY MINIMUM FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_MONTHLY MINIMUM AMOUNT]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY BROKER FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY BROKER PERCENT]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY EMPLOYER FLG]
          , [TBL_EMPLOYER CONTROL].[COBRA_PAID BY EMPLOYER PERCENT]
          , [TBL_EMPLOYER CONTROL].[COBRA_PEPM TYPE]
        HAVING
            ((([TBL_EMPLOYER CONTROL].process) = 1) AND (([TBL_EMPLOYER CONTROL].[COBRA_PEPM FLG]) = 1) AND
             (([TBL_EMPLOYER CONTROL].[COBRA_PEPM TYPE]) = 'Manual'));
        --
        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

