-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Data_Processing_failure_alert]

AS
BEGIN
	EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'Email Alert System',
    --@recipients = 'dkaelin@claritybenefitsolutions.com;jwendt@claritybenefitsolutions.com;lbujnowski@claritybenefitsolutions.com;KBeacham@claritybenefitsolutions.com;dkasperan@claritybenefitsolutions.com',
	@recipients = 'dkaelin@claritybenefitsolutions.com',
    @body = 'Alegeus error log daily refresh failed!',
    @subject = 'Alegeus error log daily refresh failed' ;
END
go

